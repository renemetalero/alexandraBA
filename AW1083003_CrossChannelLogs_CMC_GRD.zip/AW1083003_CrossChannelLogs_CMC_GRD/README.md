

# api-logging-core

Librería Java 21 que estandariza el registro de logs, la trazabilidad y el seguimiento de ejecución en aplicaciones, proporcionando un formato uniforme para auditar el flujo de los métodos mediante Trace ID.

---

## Ýndice


| # | Sección |
|---|---|
| 1 | [¿Qué es?](#qué-es) |
| 2 | [Requisitos](#requisitos) |
| 3 | [Instalación](#instalación) |
| 4 | [Uso básico](#uso-básico) |
| 7 | [Componentes librería](#componentes-librería) |
| 9 | [Versión](#versión) |
| 10 | [Autor](#autor) |

## ¿Qué es?


`api-logging-core` es una librería diseñada para estandarizar la generación de logs en aplicaciones Java, facilitando la trazabilidad de ejecución mediante el uso de un identificador único por flujo (Trace ID).

Permite implementar un esquema uniforme de logging para:

- Registrar inicio y fin de métodos con su request/response.
- Capturar errores con detalle (stacktrace y ubicación).
- Mantener consistencia en el formato de logs.
- Propagar información de trazabilidad en todo el flujo de ejecución.

**Responsabilidades del desarrollador al usar la librería:**

- Definir la lógica de negocio del sistema.
- Invocar los métodos de logging en puntos clave.
- crear una clase component para hacer un bean de la libreria y mantener la inyeccion en todo el contexto de la aplicacion
- Generar y asignar un Trace ID por flujo (por ejemplo, por request).
- Manejar correctamente el ciclo de vida del contexto (limpiar al final).

**Lo que resuelve la librería automáticamente:**

- Formato estándar de logs.
- Inclusión del Trace ID en cada registro.
- Manejo estructurado de logs de error.
- Conversión de stack trace en información útil (clase/método/línea).
- Generación segura de identificadores de trazabilidad.

---


## Requisitos

- Java 21
- Gradle
- Log4j2

## Instalación

Agrega la dependencia en el `build.gradle` de tu proyecto:

```groovy
dependencies {
    implementation 'sv.ba:api-logging-core:1.0.0'
}
```

## Uso basico 
inicialización del logger y servicio, generación y seteo del Trace ID, logs de inicio/fin, logs personalizados, manejo de excepción y limpieza del contexto.

incluir las siguientes dependencias en el build gradle 
```java
implementation 'org.springframework.boot:spring-boot-starter-log4j2'
implementation 'org.apache.logging.log4j:log4j-api'
implementation 'org.apache.logging.log4j:log4j-core'
```
creacion de clase de configuracion para utilizar la libreria como un bean
```java

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import sv.ba.service.LogService;
import sv.ba.util.TraceContext;
import sv.ba.util.TraceIdGenerator;

@Configuration
public class LogConfig {

    @Bean
    public LogService logService() {
        return new LogService();
    }

    @Bean
    public OncePerRequestFilter traceFilter() {
        return new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain filterChain)
                    throws ServletException, IOException {

                try {
                    // Generar TraceId por request
                    String traceId = TraceIdGenerator.newTraceId();
                    TraceContext.setTraceId(traceId);

                    filterChain.doFilter(request, response);

                } finally {
                    // Limpiar el contexto
                    TraceContext.clear();
                }
            }
        };
    }
}
```

ejemplo de implementacion de libreria 
```java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.pruebaLib.logs.util.LogConfig;

@Service
public class PruebaService {

    @Autowired
    private logConfig logs;

    public static void main(String[] args) {

        String metodo = "consultaCuenta";
        String request = "{\"accountNumber\":\"123456\"}";

        try {
            // 3) Registrar inicio de método + request
            logs.inicioMetodo(metodo, request);

            // 4) Logs informativos personalizados (opcional)
            logs.insertLog(metodo, "Iniciando validaciones de entrada");
            logs.insertLog(metodo, "Consultando proveedor de datos");



            // 5) Registrar fin de método + response
            logs.finMetodo(metodo, response);

        } catch (Exception ex) {
            // 6) Registrar excepción con detalle (stacktrace + clase/método/línea)
            logs.errorExceptionLog(metodo, ex);

            // 7) Registrar un error controlado adicional (opcional)
            logs.insertErrorLog(metodo, "Ocurrió un error durante la ejecución");
        } finally {
            // 8) Limpiar el contexto para evitar contaminación entre hilos/flujos
            TraceContext.clear();
        }

    }
}
```

## Componentes-librería
===================================
| Componente | Paquete | Descripción |
|---|---|---|
| `ApiLog` | `sv.ba.api` | Contrato para la estandarización de logs |
| `LogService` | `sv.ba.service` | Implementación principal de logging estandarizado |
| `TraceContext` | `sv.ba.util` | Manejo del Trace ID usando `ThreadContext` de Log4j2 |
| `TraceIdGenerator` | `sv.ba.util` | Generador de Trace ID aleatorio (SecureRandom, hex) |

## Autor

**Angel Vladimir Melara**  
Desarrollador Java Externo  
avmelara@bancoagricola.com.sv
