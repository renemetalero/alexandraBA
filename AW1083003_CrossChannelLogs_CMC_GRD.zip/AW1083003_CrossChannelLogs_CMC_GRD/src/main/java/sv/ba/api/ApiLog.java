package sv.ba.api;

/**
 * Contrato para la estandarización de registro de logs en la aplicación.
 *
 * <p>
 * Define los métodos básicos para gestionar el ciclo de logging asociado
 * a la ejecución de operaciones, incluyendo inicio, fin, errores y trazas
 * personalizadas.
 *
 * <p>
 * Las implementaciones de esta interfaz deben garantizar un formato uniforme
 * de los logs, así como la integración con mecanismos de trazabilidad
 * (por ejemplo, Trace ID).
 *
 * <p>
 * Su objetivo principal es facilitar la observabilidad, auditoría y
 * monitoreo del flujo de ejecución en los diferentes componentes del sistema.
 *
 * @author Angel Vladimir Melara
 * @since 1.0.0
 */
public interface ApiLog {

    /**
     * Registra el inicio de un método junto con su request.
     *
     * @param metodo  nombre del método invocado.
     * @param request información de entrada asociada.
     */
    void inicioMetodo(String metodo, String request);

    /**
     * Registra el fin de un método junto con su response.
     *
     * @param metodo   nombre del método ejecutado.
     * @param response información de salida generada.
     */
    void finMetodo(String metodo, String response);

    /**
     * Registra una excepción ocurrida durante la ejecución de un método.
     *
     * @param metodo nombre del método donde ocurrió el error.
     * @param ex     excepción capturada.
     */
    void errorExceptionLog(String metodo, Exception ex);

    /**
     * Registra un log informativo asociado a un método.
     *
     * @param metodo nombre del método relacionado.
     * @param log    mensaje a registrar.
     */
    void insertLog(String metodo, String log);

    /**
     * Registra un log de error personalizado asociado a un método.
     *
     * @param metodo nombre del método relacionado.
     * @param log    mensaje de error a registrar.
     */
    void insertErrorLog(String metodo, String log);
}