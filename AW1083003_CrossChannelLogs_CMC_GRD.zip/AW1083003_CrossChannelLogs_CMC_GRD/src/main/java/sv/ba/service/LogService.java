package sv.ba.service;

import org.apache.logging.log4j.Logger;

import sv.ba.api.ApiLog;
import sv.ba.util.LoggerFactory;
import sv.ba.util.TraceContext;

/**
 * Implementación del servicio de logging estandarizado para la aplicación.
 *
 * <p>
 * Esta clase provee un conjunto de métodos para registrar eventos de ejecución
 * de métodos, incluyendo inicio, fin, errores, logs informativos y trazabilidad
 * mediante un identificador único de seguimiento (Trace ID).
 *
 * <p>
 * Utiliza {@link org.apache.logging.log4j.Logger} como motor de logging y
 * {@link TraceContext} para obtener el identificador de trazabilidad asociado
 * al flujo de ejecución actual.
 *
 * <p>
 * El formato de los logs generados sigue un estándar uniforme que incluye:
 * <ul>
 * <li>Trace ID</li>
 * <li>Nombre del método en mayúsculas</li>
 * <li>Tipo de evento (INICIO, RESPONSE, ERROR, etc.)</li>
 * </ul>
 *
 * <p>
 * Esta implementación permite mejorar la observabilidad, auditoría y debugging
 * de la aplicación, facilitando el rastreo de solicitudes a través de múltiples
 * componentes.
 *
 * @author Angel Vladimir Melara
 * @since 1.0.0
 * @see Logger
 * @see TraceContext
 * @see ApiLog
 */
public class LogService implements ApiLog {


    /**
     * Constructor que permite inyectar una instancia personalizada de {@link Logger}.
     *
     * @param logger instancia de logger a utilizar.
     */

    private Logger logger;

    public LogService() {
        this.logger = LoggerFactory.getLogger(LogService.class);
    }

    public LogService(Logger logger) {
        this.logger = logger;
    }

    /**
     * Obtiene el identificador de trazabilidad (Trace ID) desde el contexto actual.
     *
     * <p>
     * Si no existe un Trace ID o está vacío, se retorna el valor por defecto
     * {@code "00000"}.
     *
     * @return Trace ID actual o valor por defecto si no está presente.
     */
    private String traceId() {
        String t = TraceContext.getTraceId();
        return (t != null && !t.isBlank()) ? t : "00000";
    }

    /**
     * Registra el inicio de la ejecución de un método.
     *
     * <p>
     * Incluye el nombre del método y el contenido del request asociado.
     *
     * @param metodo  nombre del método invocado.
     * @param request contenido de entrada del método (request).
     */
    public void inicioMetodo(String metodo, String request) {
        if (logger.isInfoEnabled()) {
            String traceId = traceId();
            String metodoUpper = metodo != null ? metodo.toUpperCase() : "NULL";

            logger.info("--[{}]-------INICIO DEL METODO {} ----------------", traceId, metodoUpper);
            logger.info("--[{}]-------REQUEST {}: {}", traceId, metodoUpper, request);
        }
    }

    /**
     * Registra el fin de la ejecución de un método.
     *
     * <p>
     * Incluye el nombre del método y el contenido de la respuesta generada.
     *
     * @param metodo   nombre del método ejecutado.
     * @param response contenido de salida (response).
     */
    public void finMetodo(String metodo, String response) {
        if (logger.isInfoEnabled()) {
            String traceId = traceId();
            String metodoUpper = metodo != null ? metodo.toUpperCase() : "NULL";

            logger.info("--[{}]-------RESPONSE {}: {}", traceId, metodoUpper, response);
            logger.info("--[{}]-------FINAL DEL METODO {} ----------------", traceId, metodoUpper);
        }
    }

    /**
     * Registra una excepción ocurrida durante la ejecución de un método.
     *
     * <p>
     * Incluye:
     * <ul>
     * <li>Trace ID</li>
     * <li>Nombre del método</li>
     * <li>Stack trace completo</li>
     * </ul>
     *
     * <p>
     * Además, recorre cada elemento del stack trace para registrar de forma
     * detallada la clase, método y línea donde ocurrió el error.
     *
     * @param metodo nombre del método donde ocurrió la excepción.
     * @param ex     excepción capturada.
     */
    public void errorExceptionLog(String metodo, Exception ex) {
        if (logger.isErrorEnabled()) {
            String traceId = traceId();
            String metodoUpper = metodo != null ? metodo.toUpperCase() : "NULL";

            logger.error("--[{}]-------EXCEPCION EN EL METODO: {}", traceId, metodoUpper, ex);

            for (StackTraceElement st : ex.getStackTrace()) {
                if (st.getLineNumber() > 0) {
                    logger.error("--[{}]-------CLASE: {} | METODO: {} | LINEA: {}",
                            traceId, st.getClassName(), st.getMethodName(), st.getLineNumber());
                }
            }
        }
    }

    /**
     * Registra un mensaje informativo asociado a un método.
     *
     * <p>
     * Este método es útil para agregar trazas adicionales durante la ejecución,
     * como valores intermedios o eventos relevantes dentro del flujo.
     *
     * @param metodo nombre del método relacionado al log.
     * @param log    mensaje a registrar.
     */
    public void insertLog(String metodo, String log) {
        if (logger.isInfoEnabled()) {
            String traceId = traceId();
            String metodoUpper = metodo != null ? metodo.toUpperCase() : "NULL";

            logger.info("--[{}]-------METODO {} LOG ==> {}", traceId, metodoUpper, log);
        }
    }

    /**
     * Registra un mensaje de error personalizado asociado a un método.
     *
     * <p>
     * A diferencia de {@link #errorExceptionLog(String, Exception)}, este método
     * permite registrar errores sin necesidad de una excepción, por ejemplo:
     * validaciones de negocio o condiciones inesperadas controladas.
     *
     * @param metodo nombre del método relacionado al error.
     * @param log    mensaje de error a registrar.
     */
    public void insertErrorLog(String metodo, String log) {
        if (logger.isErrorEnabled()) {
            String traceId = traceId();
            String metodoUpper = metodo != null ? metodo.toUpperCase() : "NULL";

            logger.error("--[{}]-------METODO {} ERRORLOG ==> {}", traceId, metodoUpper, log);
        }
    }
}