package sv.ba.util;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * factory centralizado para la obtención de instancias de {@link Logger}
 * utilizando Log4j2.
 *
 * <p>
 * Esta clase encapsula la creación de loggers dentro de la aplicación,
 * proporcionando un punto único de acceso y asegurando que la configuración
 * de Log4j2 sea establecida correctamente antes de su uso.
 *
 * <p>
 * Durante su inicialización estática:
 * <ul>
 *   <li>Verifica si existe la propiedad {@code log4j.configurationFile}</li>
 *   <li>Si no está definida, establece por defecto {@code classpath:log4j2.xml}</li>
 *   <li>Crea automáticamente el directorio de logs en {@code /logs/api}</li>
 * </ul>
 *
 * <p>
 * Esto garantiza que:
 * <ul>
 *   <li>La configuración de logging siempre esté disponible</li>
 *   <li>El sistema tenga una estructura base para almacenamiento de logs</li>
 *   <li>Se eviten errores por falta de configuración en tiempo de ejecución</li>
 * </ul>
 *
 * <p>
 * El uso de esta fábrica desacopla la lógica de obtención de loggers y permite
 * aplicar futuras mejoras como:
 * <ul>
 *   <li>Personalización de configuraciones</li>
 *   <li>Integración con sistemas de monitoreo</li>
 *   <li>Adaptación a múltiples frameworks de logging</li>
 * </ul>
 *
 * @author Angel Vladimir Melara
 * @since 1.0.0
 * @see Logger
 * @see LogManager
 */
public class LoggerFactory {

    
    private LoggerFactory() {

    }

    /**
     * Bloque de inicialización estático.
     *
     * <p>
     * Se ejecuta una única vez cuando la clase es cargada en memoria.
     *
     * <p>
     * Responsabilidades:
     * <ul>
     *   <li>Configurar el archivo de configuración de Log4j2 si no ha sido definido</li>
     *   <li>Crear el directorio base para almacenamiento de logs</li>
     * </ul>
     *
     * <p>
     * Ruta por defecto del archivo de configuración:
     * <pre>
     * classpath:log4j2.xml
     * </pre>
     *
     * <p>
     * Directorio creado:
     * <pre>
     * {user.dir}/logs/api
     * </pre>
     *
     * <p>
     * Este comportamiento asegura que la aplicación tenga un entorno de logging
     * funcional desde el inicio.
     */
    static {
        if (System.getProperty("log4j.configurationFile") == null) {
            System.setProperty("log4j.configurationFile", "classpath:log4j2.xml");
        }

        new File(System.getProperty("user.dir") + "/logs/api").mkdirs();
    }

    /**
     * Obtiene una instancia de {@link Logger} asociada a la clase especificada.
     *
     * <p>
     * Este método actúa como punto central de acceso para la obtención de loggers,
     * delegando la creación a {@link LogManager}.
     *
     * <p>
     * El logger devuelto estará configurado de acuerdo al archivo definido en
     * la propiedad {@code log4j.configurationFile}.
     * 
     * @param clazz la clase para la cual se desea obtener el logger
     * @return instancia de {@link Logger} asociada a la clase
     */
    public static Logger getLogger(Class<?> clazz) {
        return LogManager.getLogger(clazz);
    }
}