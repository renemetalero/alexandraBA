package sv.ba.util;

import org.apache.logging.log4j.ThreadContext;

/**
 * Utilidad para la gestión del identificador de trazabilidad (Trace ID)
 * en el contexto de ejecución actual.
 *
 * <p>
 * Esta clase encapsula el uso de {@link ThreadContext} de Log4j2 para
 * almacenar y recuperar el Trace ID asociado a un hilo de ejecución.
 * Permite propagar información de trazabilidad a lo largo de todo el flujo
 * de una solicitud, facilitando el monitoreo y debugging de la aplicación.
 *
 *
 * <p>
 * Esta clase es utilitaria, por lo que no puede ser instanciada.
 *
 *
 * @author Angel Vladimir Melara
 * @since 1.0.0
 * @see ThreadContext
 */
public final class TraceContext {

    /**
     * Clave utilizada para almacenar el Trace ID en el {@link ThreadContext}.
     */
    public static final String TRACE_ID = "traceId";

    /**
     * Constructor privado para evitar la instanciación de la clase.
     *
     * @throws UnsupportedOperationException siempre, ya que es una clase utilitaria.
     */
    private TraceContext() {
        throw new UnsupportedOperationException("Clase utilitaria - no instanciar");
    }

    /**
     * Establece el Trace ID en el contexto del hilo actual.
     *
     * <p>
     * Si el valor proporcionado es {@code null} o está vacío, la operación
     * es ignorada.
     *
     * @param traceId identificador de trazabilidad a registrar.
     */
    public static void setTraceId(String traceId) {
        if (traceId == null || traceId.isBlank()) return;
        ThreadContext.put(TRACE_ID, traceId);
    }

    /**
     * Obtiene el Trace ID almacenado en el contexto del hilo actual.
     *
     * @return Trace ID actual o {@code null} si no ha sido definido.
     */
    public static String getTraceId() {
        return ThreadContext.get(TRACE_ID);
    }

    /**
     * Elimina el Trace ID del contexto del hilo actual.
     *
     * <p>
     * Útil para limpiar el contexto al finalizar el procesamiento
     * de una solicitud.
     */
    public static void clear() {
        ThreadContext.remove(TRACE_ID);
    }

    /**
     * Limpia completamente el {@link ThreadContext} del hilo actual.
     *
     * <p>
     * Elimina todas las entradas almacenadas, no solo el Trace ID.
     * Debe usarse con precaución en caso de que existan otras claves
     * en el contexto.
     */
    public static void clearAll() {
        ThreadContext.clearAll();
    }
}
