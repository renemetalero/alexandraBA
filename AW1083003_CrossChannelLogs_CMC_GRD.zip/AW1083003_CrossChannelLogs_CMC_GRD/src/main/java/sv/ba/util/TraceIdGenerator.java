package sv.ba.util;

import java.security.SecureRandom;

/**
 * Generador de identificadores de trazabilidad (Trace ID) basado en
 * valores aleatorios criptográficamente seguros.
 *
 * <p>
 * Esta clase produce identificadores únicos en formato hexadecimal,
 * utilizando {@link SecureRandom} para garantizar alta entropía y evitar
 * colisiones en escenarios concurrentes o distribuidos.
 *
 *
 * <p>
 * El ID se genera a partir de {@value #BYTES} bytes aleatorios, lo que
 * produce una cadena hexadecimal de longitud fija (12 caracteres).
 *
 * <p>
 * Esta clase es utilitaria y no permite instanciación.
 *
 *
 * @author Angel Vladimir Melara
 * @since 1.0.0
 * @see SecureRandom
 * @see TraceContext
 */
public final class TraceIdGenerator {

    /**
     * Generador de números aleatorios seguro para uso criptográfico.
     */
    private static final SecureRandom RNG = new SecureRandom();

    /**
     * Cantidad de bytes utilizados para generar el Trace ID.
     */
    private static final int BYTES = 6;

    /**
     * Constructor privado para evitar la instanciación de la clase.
     */
    private TraceIdGenerator() {}

    /**
     * Genera un nuevo Trace ID en formato hexadecimal.
     *
     * <p>
     * El valor generado es seguro, aleatorio y adecuado para identificar
     * de manera única una ejecución o solicitud dentro del sistema.
     *
     * @return cadena hexadecimal que representa el Trace ID.
     */
    public static String newTraceId() {
        byte[] b = new byte[BYTES];
        RNG.nextBytes(b);
        return toHex(b);
    }

    /**
     * Convierte un arreglo de bytes en su representación hexadecimal.
     *
     * <p>
     * Cada byte se transforma en dos caracteres hexadecimales, produciendo
     * una cadena de longitud {@code bytes.length * 2}.
     *
     * @param bytes arreglo de bytes a convertir.
     * @return representación hexadecimal del arreglo.
     */
    private static String toHex(byte[] bytes) {
        char[] hex = new char[bytes.length * 2];
        final char[] digits = "0123456789abcdef".toCharArray();

        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xFF;
            hex[i * 2]     = digits[v >>> 4];
            hex[i * 2 + 1] = digits[v & 0x0F];
        }
        return new String(hex);
    }
}