package sv.ba.util;

import java.io.File;

import org.apache.logging.log4j.Logger;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LoggerFactoryTest {

    @BeforeEach
    void setUp() {
        System.clearProperty("log4j.configurationFile");
    }

    @Test
    void shouldNotOverrideExistingLog4jConfiguration() {
        // Arrange
        System.setProperty("log4j.configurationFile", "custom-log4j2.xml");

        // Assert
        String config = System.getProperty("log4j.configurationFile");
        assertEquals("custom-log4j2.xml", config);
    }

    @Test
    void shouldCreateLogsDirectory() {
        // Act
        LoggerFactory.getLogger(LoggerFactoryTest.class);

        // Assert
        File dir = new File(System.getProperty("user.dir") + "/logs/api");
        assertTrue(dir.exists());
        assertTrue(dir.isDirectory());
    }

    @Test
    void shouldReturnLoggerInstance() {
        // Act
        Logger logger = LoggerFactory.getLogger(LoggerFactoryTest.class);

        // Assert
        assertNotNull(logger);
    }

    @Test
    void shouldReturnSameLoggerForSameClass() {
        // Act
        Logger logger1 = LoggerFactory.getLogger(LoggerFactoryTest.class);
        Logger logger2 = LoggerFactory.getLogger(LoggerFactoryTest.class);

        // Assert
        assertEquals(logger1.getName(), logger2.getName());
    }

    @Test
    void shouldReturnDifferentLoggerForDifferentClasses() {
        // Act
        Logger logger1 = LoggerFactory.getLogger(LoggerFactoryTest.class);
        Logger logger2 = LoggerFactory.getLogger(String.class);

        // Assert
        assertNotEquals(logger1.getName(), logger2.getName());
    }
}