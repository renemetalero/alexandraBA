package sv.ba.util;

import org.apache.logging.log4j.ThreadContext;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TraceContextTest {

    @AfterEach
    void tearDown() {
        ThreadContext.clearAll();
    }

    @Test
    void setTraceId_whenValidValueProvided() {
        String traceId = "abc-123";

        TraceContext.setTraceId(traceId);

        assertEquals(traceId, ThreadContext.get(TraceContext.TRACE_ID));
    }

    @Test
    void setTraceId_whenTraceIdIsNull() {
        TraceContext.setTraceId(null);

        assertNull(ThreadContext.get(TraceContext.TRACE_ID));
    }

    @Test
    void setTraceId_whenTraceIdIsBlank() {
        TraceContext.setTraceId("   ");

        assertNull(ThreadContext.get(TraceContext.TRACE_ID));
    }

    @Test
    void getTraceId_shouldReturnStoredTraceId() {
        ThreadContext.put(TraceContext.TRACE_ID, "xyz-789");

        String result = TraceContext.getTraceId();

        assertEquals("xyz-789", result);
    }

    @Test
    void getTraceId_shouldReturnNull_whenNotSet() {
        assertNull(TraceContext.getTraceId());
    }

    @Test
    void clear_shouldRemoveOnlyTraceId() {
        ThreadContext.put(TraceContext.TRACE_ID, "trace-1");
        ThreadContext.put("otherKey", "otherValue");

        TraceContext.clear();

        assertNull(ThreadContext.get(TraceContext.TRACE_ID));
        assertEquals("otherValue", ThreadContext.get("otherKey"));
    }

    @Test
    void clearAll_shouldRemoveAllEntriesFromThreadContext() {
        ThreadContext.put(TraceContext.TRACE_ID, "trace-1");
        ThreadContext.put("anotherKey", "value");

        TraceContext.clearAll();

        assertTrue(ThreadContext.isEmpty());
    }
}
