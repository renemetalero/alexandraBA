package sv.ba.util;

import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class TraceIdGeneratorTest {

    @Test
    void newTraceId_shouldReturnNonNullValue() {
        String traceId = TraceIdGenerator.newTraceId();

        assertNotNull(traceId);
    }

    @Test
    void newTraceId_shouldReturnHexStringWithExpectedLength() {
        // BYTES = 6 → 12 caracteres hex
        String traceId = TraceIdGenerator.newTraceId();

        assertEquals(12, traceId.length());
    }

    @Test
    void newTraceId_shouldContainOnlyLowercaseHexCharacters() {
        String traceId = TraceIdGenerator.newTraceId();

        assertTrue(traceId.matches("[0-9a-f]+"),
                "TraceId should contain only lowercase hexadecimal characters");
    }

    @Test
    void newTraceId_shouldGenerateDifferentValuesOnMultipleCalls() {
        Set<String> ids = new HashSet<>();

        for (int i = 0; i < 100; i++) {
            ids.add(TraceIdGenerator.newTraceId());
        }

        assertEquals(100, ids.size());
    }

    @Test
    void newTraceId_shouldNotBeBlank() {
        String traceId = TraceIdGenerator.newTraceId();

        assertFalse(traceId.isBlank());
    }
}