package sv.ba.service;

import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import sv.ba.util.TraceContext;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TestLogService {

    @Mock
    private Logger logger;

    private LogService logService;

    @BeforeEach
    void setUp() {
        logService = new LogService(logger);
    }

    @AfterEach
    void tearDown() {
        TraceContext.clearAll();
    }

    @Test
    void testConstructor_logger() {
        LogService service = new LogService();

        TraceContext.setTraceId("123");

        service.insertLog("metodo", "mensaje");

        assertNotNull(service);
    }

    @Test
    void testInicioMetodo() {
        when(logger.isInfoEnabled()).thenReturn(true);

        String traceId = "qC2l2wLSlc";
        String metodo = "pagoTDC";
        String request = "{nombre:'Juan'}";

        TraceContext.setTraceId(traceId);

        logService.inicioMetodo(metodo, request);

        verify(logger).info("--[{}]-------INICIO DEL METODO {} ----------------", traceId, metodo.toUpperCase());
        verify(logger).info("--[{}]-------REQUEST {}: {}", traceId, metodo.toUpperCase(), request);

        verifyNoMoreInteractions(logger);
    }

    @Test
    void testFinMetodo() {
        when(logger.isInfoEnabled()).thenReturn(true);

        String traceId = "qC2l2wLSlc";
        String metodo = "pagoTDC";
        String response = "{status:'OK'}";

        TraceContext.setTraceId(traceId);

        logService.finMetodo(metodo, response);

        verify(logger).info("--[{}]-------RESPONSE {}: {}", traceId, metodo.toUpperCase(), response);
        verify(logger).info("--[{}]-------FINAL DEL METODO {} ----------------", traceId, metodo.toUpperCase());

        verifyNoMoreInteractions(logger);
    }

    @Test
    void testInsertLog() {
        when(logger.isInfoEnabled()).thenReturn(true);

        String traceId = "qC2l2wLSlc";
        String metodo = "pagoTDC";
        String mensaje = "METODO UTILIZADO PARA PAGO TDC";

        TraceContext.setTraceId(traceId);

        logService.insertLog(metodo, mensaje);

        verify(logger).info("--[{}]-------METODO {} LOG ==> {}", traceId, metodo.toUpperCase(), mensaje);

        verifyNoMoreInteractions(logger);
    }

    @Test
    void testInsertErrorLog() {
        when(logger.isErrorEnabled()).thenReturn(true);

        String traceId = "qC2l2wLSlc";
        String metodo = "pagoTDC";
        String mensaje = "FALLA CONTROLADA";

        TraceContext.setTraceId(traceId);

        logService.insertErrorLog(metodo, mensaje);

        verify(logger).error("--[{}]-------METODO {} ERRORLOG ==> {}", traceId, metodo.toUpperCase(), mensaje);

        verifyNoMoreInteractions(logger);
    }

    @Test
    void testErrorExceptionLog() {
        when(logger.isErrorEnabled()).thenReturn(true);

        String traceId = "qC2l2wLSlc";
        String metodo = "pagoTDC";

        TraceContext.setTraceId(traceId);

        Exception exception = new Exception("Error de prueba");

        StackTraceElement element1 = new StackTraceElement(
                "com.test.ClaseTest",
                "metodoTest",
                "ClaseTest.java",
                45
        );

        StackTraceElement element2 = new StackTraceElement(
                "com.test.ClaseTest2",
                "metodoTest2",
                "ClaseTest2.java",
                23
        );

        exception.setStackTrace(new StackTraceElement[]{element1, element2});

        logService.errorExceptionLog(metodo, exception);

        verify(logger).error(
                "--[{}]-------EXCEPCION EN EL METODO: {}",
                traceId,
                metodo.toUpperCase(),
                exception
        );

        verify(logger, times(2)).error(
                eq("--[{}]-------CLASE: {} | METODO: {} | LINEA: {}"),
                eq(traceId),
                anyString(),
                anyString(),
                any()
        );

        verify(logger).error(
                "--[{}]-------CLASE: {} | METODO: {} | LINEA: {}",
                traceId,
                element1.getClassName(),
                element1.getMethodName(),
                element1.getLineNumber()
        );

        verify(logger).error(
                "--[{}]-------CLASE: {} | METODO: {} | LINEA: {}",
                traceId,
                element2.getClassName(),
                element2.getMethodName(),
                element2.getLineNumber()
        );

        verifyNoMoreInteractions(logger);
    }

    @Test
    void testSinTraceId_NoTrace() {
        when(logger.isInfoEnabled()).thenReturn(true);

        String metodo = "pagoTDC";
        String request = "request";

        logService.inicioMetodo(metodo, request);

        verify(logger).info("--[{}]-------INICIO DEL METODO {} ----------------", "00000", metodo.toUpperCase());
        verify(logger).info("--[{}]-------REQUEST {}: {}", "00000", metodo.toUpperCase(), request);

        verifyNoMoreInteractions(logger);
    }
}