package sv.ba;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = { "app.message=Mensaje de prueba" })
class Aw1060012PocDynamicYieldCnsGrdApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    void shouldRunMainMethod() {

        try (MockedStatic<SpringApplication> mocked = Mockito.mockStatic(SpringApplication.class)) {

            String[] args = {};

            Aw1060012PocDynamicYieldCnsGrdApplication.main(args);

            mocked.verify(() -> SpringApplication.run(
                    Aw1060012PocDynamicYieldCnsGrdApplication.class,
                    args));
        }
    }

}
