package sv.ba.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
public class HelloControllerTest {

    @Test
    void retornaMensajeYSaludo() {
        String mensajeConfigurado = "Mensaje de prueba";
        HelloController controller = new HelloController(mensajeConfigurado);

        Map<String, Object> resultado = controller.saludar();

        assertEquals("Hola mundo", resultado.get("saludo"));
        assertEquals(mensajeConfigurado, resultado.get("mensaje"));
    }

}
