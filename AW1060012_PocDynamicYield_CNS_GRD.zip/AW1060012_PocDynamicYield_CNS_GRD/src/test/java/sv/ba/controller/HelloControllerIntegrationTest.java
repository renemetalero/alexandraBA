package sv.ba.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
@SpringBootTest(properties = { "app.message= Mensaje desde test" })
@AutoConfigureMockMvc
public class HelloControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void retornaMensajeYSaludo() throws Exception {
        mockMvc.perform(get("/hello/saludar"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.saludo").value("Hola mundo"))
                .andExpect(jsonPath("$.mensaje").value("Mensaje desde test"));
    }

}
