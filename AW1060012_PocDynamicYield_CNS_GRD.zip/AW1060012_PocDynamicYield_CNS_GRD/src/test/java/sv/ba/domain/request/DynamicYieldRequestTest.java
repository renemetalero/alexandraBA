package sv.ba.domain.request;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
public class DynamicYieldRequestTest {

    @Test
    void shouldSerializeRequestCorrectly() throws Exception {

        ObjectMapper mapper = new ObjectMapper();

        DynamicYieldRequest request = new DynamicYieldRequest(
                Map.of(),
                Map.of(),
                new Selector(
                        List.of("poc_home_banner")),
                new Context(
                        new Page(
                                "HOMEPAGE",
                                "app://home",
                                List.of())),
                new Options(true));

        String json = mapper.writeValueAsString(request);

        assertNotNull(json);

        assertTrue(
                json.contains("poc_home_banner"));

    }
}
