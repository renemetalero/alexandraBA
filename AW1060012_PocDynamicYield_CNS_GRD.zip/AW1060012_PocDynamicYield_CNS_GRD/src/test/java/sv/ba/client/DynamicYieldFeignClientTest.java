package sv.ba.client;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
@SpringBootTest(properties = {
        "dy.base-url=http://localhost:9999",
        "dy.api-key=test-api-key"
})
public class DynamicYieldFeignClientTest {

    @Autowired
    private DynamicYieldFeignClient client;

    @Test
    void shouldLoadFeignClient() {
        assertThat(client).isNotNull();
    }

}
