package sv.ba.client;

import static org.assertj.core.api.Assertions.assertThat;

import feign.Request;
import feign.Response;
import feign.codec.ErrorDecoder;
import sv.ba.config.DynamicYieldFeignConfiguration;
import sv.ba.exception.DynamicYieldClientException;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import org.junit.jupiter.api.Test;

class DynamicYieldFeignConfigurationTest {

    private final DynamicYieldFeignConfiguration configuration = new DynamicYieldFeignConfiguration();

    @Test
    void shouldDecodeDynamicYieldError() {
        ErrorDecoder decoder = configuration.dynamicYieldErrorDecoder();

        Request request = Request.create(
                Request.HttpMethod.POST,
                "https://dy-api.com/v2/serve/user/choose",
                Collections.emptyMap(),
                null,
                StandardCharsets.UTF_8,
                null);

        Response response = Response.builder()
                .status(401)
                .reason("Unauthorized")
                .request(request)
                .headers(Collections.emptyMap())
                .build();

        Exception exception = decoder.decode(
                "DynamicYieldFeignClient#choose",
                response);

        assertThat(exception)
                .isInstanceOf(DynamicYieldClientException.class);

        DynamicYieldClientException clientException = (DynamicYieldClientException) exception;

        assertThat(clientException.getStatus())
                .isEqualTo(401);

        assertThat(clientException.getMessage())
                .contains("Dynamic Yield")
                .contains("401");
    }
}
