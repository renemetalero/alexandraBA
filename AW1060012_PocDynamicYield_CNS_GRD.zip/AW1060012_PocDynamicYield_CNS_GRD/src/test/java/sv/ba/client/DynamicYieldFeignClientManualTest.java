package sv.ba.client;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import sv.ba.domain.request.Context;
import sv.ba.domain.request.DynamicYieldRequest;
import sv.ba.domain.request.Options;
import sv.ba.domain.request.Page;
import sv.ba.domain.request.Selector;

@SpringBootTest(properties = {
        "dy.base-url=https://dy-api.com"
})
@Disabled("Prueba manual contra Dynamic Yield")
class DynamicYieldFeignClientManualTest {

    @Autowired
    private DynamicYieldFeignClient client;

    @Test
    void shouldCallDynamicYield() {
        DynamicYieldRequest request = new DynamicYieldRequest(
                Map.of(),
                Map.of(),
                new Selector(
                        List.of("poc_home_banner")),
                new Context(
                        new Page(
                                "HOMEPAGE",
                                "app://home",
                                List.of())),
                new Options(true));

        long start = System.nanoTime();

        JsonNode response = client.choose(request);

        long elapsedMilliseconds = (System.nanoTime() - start) / 1_000_000;

        assertThat(response).isNotNull();
        assertThat(response.isMissingNode()).isFalse();

        System.out.printf(
                "Dynamic Yield respondió en %d ms%n",
                elapsedMilliseconds);

        System.out.println(response.toPrettyString());
    }
}
