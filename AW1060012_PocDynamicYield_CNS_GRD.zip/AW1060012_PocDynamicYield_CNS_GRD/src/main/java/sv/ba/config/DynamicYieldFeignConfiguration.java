package sv.ba.config;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import feign.RequestInterceptor;
import feign.codec.ErrorDecoder;
import lombok.RequiredArgsConstructor;
import sv.ba.exception.DynamicYieldClientException;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
@RequiredArgsConstructor
public class DynamicYieldFeignConfiguration {

    @Bean
    public RequestInterceptor dynamicYieldInterceptor(DynamicYieldProperties properties) {
        return requestTemplate -> {
            requestTemplate.header("DY-API-Key", properties.apiKey());
            requestTemplate.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            requestTemplate.header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);

        };
    }

    @Bean
    public ErrorDecoder dynamicYieldErrorDecoder() {
        return (methodKey, response) -> new DynamicYieldClientException(
                "Error al consumir Dynamic Yield. "
                        + "methodKey=%s, status=%d"
                                .formatted(methodKey, response.status()),
                response.status());
    }
}
