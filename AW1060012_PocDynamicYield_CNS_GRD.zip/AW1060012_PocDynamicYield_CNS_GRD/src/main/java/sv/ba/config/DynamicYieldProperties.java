package sv.ba.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * DTO inmutable para transferencia de datos...
 *
 * @author Jose Luis Pereira
 */
@ConfigurationProperties(prefix = "dy")
public record DynamicYieldProperties(
        String baseUrl,
        String apiKey) {
}
