package sv.ba.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
@Configuration
@EnableConfigurationProperties(DynamicYieldProperties.class)
public class PropertiesConfig {

}
