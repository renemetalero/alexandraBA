package sv.ba.domain.request;

import java.util.List;

/**
 * DTO inmutable para transferencia de datos...
 *
 * @author Jose Luis Pereira
 */
public record Page(
        String type,
        String location,
        List<Object> data) {

}
