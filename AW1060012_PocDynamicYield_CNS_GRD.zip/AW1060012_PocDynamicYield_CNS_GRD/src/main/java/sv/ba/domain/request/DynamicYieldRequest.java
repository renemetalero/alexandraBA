package sv.ba.domain.request;

import java.util.Map;

/**
 * DTO inmutable para transferencia de datos...
 *
 * @author Jose Luis Pereira
 */
public record DynamicYieldRequest(
        Map<String, Object> user,
        Map<String, Object> session,
        Selector selector,
        Context context,
        Options options) {

}
