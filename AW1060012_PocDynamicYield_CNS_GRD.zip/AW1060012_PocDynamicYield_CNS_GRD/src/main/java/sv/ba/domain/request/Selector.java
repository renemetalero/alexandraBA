package sv.ba.domain.request;

import java.util.List;

/**
 * DTO inmutable para transferencia de datos...
 *
 * @author Jose Luis Pereira
 */
public record Selector(List<String> names) {

}
