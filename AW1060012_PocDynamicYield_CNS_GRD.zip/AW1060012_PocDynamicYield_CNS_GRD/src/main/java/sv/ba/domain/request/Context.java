package sv.ba.domain.request;

/**
 * DTO inmutable para transferencia de datos...
 *
 * @author Jose Luis Pereira
 */
public record Context(Page page) {

}
