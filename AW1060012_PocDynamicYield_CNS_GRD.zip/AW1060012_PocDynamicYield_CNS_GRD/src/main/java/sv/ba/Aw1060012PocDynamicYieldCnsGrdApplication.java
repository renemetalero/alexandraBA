package sv.ba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class Aw1060012PocDynamicYieldCnsGrdApplication {

    public static void main(String[] args) {
        SpringApplication.run(Aw1060012PocDynamicYieldCnsGrdApplication.class, args);
    }

}
