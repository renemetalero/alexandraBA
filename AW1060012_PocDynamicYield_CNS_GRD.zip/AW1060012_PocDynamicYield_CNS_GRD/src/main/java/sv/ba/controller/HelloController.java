package sv.ba.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controlador REST para dominio
 *
 * @author Jose Luis Pereira
 */
@RestController
@RequestMapping("/hello")
public class HelloController {

    private final String message;

    public HelloController(@Value("${app.message}") String message) {
        this.message = message;
    }

    @GetMapping("/saludar")
    public Map<String, Object> saludar() {
        return Map.of(
                "saludo", "Hola mundo",
                "mensaje", message);

    }

}
