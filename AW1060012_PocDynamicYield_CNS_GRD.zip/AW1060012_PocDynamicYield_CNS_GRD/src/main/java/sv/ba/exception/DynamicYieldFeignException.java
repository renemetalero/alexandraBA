package sv.ba.exception;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
public class DynamicYieldFeignException extends RuntimeException {

    public DynamicYieldFeignException(String message) {
        super(message);
    }

}
