package sv.ba.exception;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
public class DynamicYieldClientException extends RuntimeException {

    private final int status;

    public DynamicYieldClientException(String message, int status) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

}
