package sv.ba.constants;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
public final class DynamicYieldConstants {

    private DynamicYieldConstants() {
    }

    public static final String HOMEPAGE = "HOMEPAGE";
    public static final String HOME_LOCATION = "app://home";
    public static final String HOME_BANNER = "poc_home_banner";

}
