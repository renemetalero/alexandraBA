package sv.ba.client;

import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import sv.ba.config.DynamicYieldFeignConfiguration;
import sv.ba.domain.request.DynamicYieldRequest;

/**
 * Descripción del contrato...
 *
 * @author Jose Luis Pereira
 */
@FeignClient(name = "dynamicYieldClient", url = "${dy.base-url}", configuration = DynamicYieldFeignConfiguration.class)
public interface DynamicYieldFeignClient {

    @PostMapping("/v2/serve/user/choose")
    JsonNode choose(@RequestBody DynamicYieldRequest request);
}
