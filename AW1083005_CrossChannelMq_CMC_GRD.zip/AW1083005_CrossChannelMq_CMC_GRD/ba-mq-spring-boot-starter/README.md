# ba-mq-spring-boot-starter

Auto-configuración Spring Boot para el sistema de mensajería de `ba-crosschannel-mq-lib`.
Incluir este módulo en el classpath es suficiente para tener un `MQClient` completamente configurado e inyectable, sin escribir ningún bean manualmente.

---

## ¿Para qué sirve?

Provee integración **zero-configuration** entre cualquier microservicio Spring Boot y RabbitMQ, aplicando los principios:

- **Convención sobre configuración**: todos los beans se crean automáticamente con valores razonables.
- **`@ConditionalOnMissingBean`**: cualquier bean puede sobreescribirse con una implementación propia sin conflictos.
- **Desacoplamiento total**: el código de negocio solo depende de las interfaces de `ba-mq-core` (`MQClient`, `MessagePublisher`, `MessageConsumer`), nunca de RabbitMQ directamente.

---

## ¿Cuándo utilizarla?

| Escenario | ¿Usar este starter? |
|---|---|
| Microservicio Spring Boot que necesita publicar eventos a RabbitMQ | ✅ Sí |
| Microservicio Spring Boot que necesita consumir mensajes de RabbitMQ | ✅ Sí |
| Librería o módulo sin contexto Spring Boot | ❌ Usar `ba-mq-rabbit` directamente |
| Se requiere un broker distinto (Kafka, ActiveMQ) | ❌ Implementar las interfaces de `ba-mq-core` |

---

## Instalación

### Gradle

```gradle
dependencies {
    implementation "sv.ba.crosschannel.mq:ba-mq-spring-boot-starter:1.0.0"
}
```

### Maven

```xml
<dependency>
    <groupId>sv.ba.crosschannel.mq</groupId>
    <artifactId>ba-mq-spring-boot-starter</artifactId>
    <version>1.0.0</version>
</dependency>
```

> No es necesario agregar `ba-mq-core` ni `ba-mq-rabbit` por separado; este starter los incluye transitivamente.

---

## Configuración

Agrega las siguientes propiedades en el `application.yml` del proyecto consumidor:

```yaml
ba:
  messaging:
    rabbit:
      enabled: true        # true por defecto. false deshabilita toda la auto-configuración
      host: localhost
      port: 5672           # 5672 por defecto
      username: guest
      password: guest
      exchange: mi-exchange
```

### Propiedades disponibles

| Propiedad | Tipo | Default | Descripción |
|---|---|---|---|
| `ba.messaging.rabbit.enabled` | `boolean` | `true` | Habilita/deshabilita la auto-configuración |
| `ba.messaging.rabbit.host` | `String` | — | Host del servidor RabbitMQ |
| `ba.messaging.rabbit.port` | `int` | `5672` | Puerto del servidor RabbitMQ |
| `ba.messaging.rabbit.username` | `String` | — | Usuario de autenticación |
| `ba.messaging.rabbit.password` | `String` | — | Contraseña de autenticación |
| `ba.messaging.rabbit.exchange` | `String` | — | Exchange principal de publicación |

---

## Uso en el proyecto consumidor

### Publicar un mensaje

```java
@Service
@RequiredArgsConstructor
public class OrderService {

    private final MQClient mqClient;

    public void createOrder(OrderDto order) {
        Message message = Message.builder()
            .payload(order)
            .metadata(MessageMetadata.defaultMetadata())
            .build();

        mqClient.publisher().publish("ordenes.creadas", message);
    }
}
```

### Suscribirse a una queue

```java
@Component
@RequiredArgsConstructor
public class OrderEventListener {

    private final MQClient mqClient;

    @PostConstruct
    public void listen() {
        mqClient.consumer().subscribe("ordenes.creadas", message -> {
            OrderDto order = (OrderDto) message.getPayload();
            // procesar evento...
        });
    }
}
```

### Inyectar publisher o consumer directamente

```java
@Service
@RequiredArgsConstructor
public class NotificationService {

    private final MessagePublisher publisher;   // bean registrado por el starter

    public void notify(NotificationDto dto) {
        publisher.publish("notificaciones", Message.builder().payload(dto).build());
    }
}
```

---

## Extensibilidad

### Sobreescribir el serializador (e.g. usar Avro)

Basta con declarar un bean `MessageSerializer` en el contexto del proyecto consumidor:

```java
@Bean
public MessageSerializer avroSerializer() {
    return new AvroMessageSerializer();
}
```

El starter detectará el bean existente y **no creará** el `JacksonMessageSerializer`.

### Sobreescribir la conexión a RabbitMQ

```java
@Bean
public ConnectionFactory customConnectionFactory() {
    CachingConnectionFactory factory = new CachingConnectionFactory("mi-rabbit-cluster");
    factory.setVirtualHost("/produccion");
    return factory;
}
```

### Deshabilitar la auto-configuración en tests

```yaml
# src/test/resources/application-test.yml
ba:
  messaging:
    rabbit:
      enabled: false
```

---

## Beans registrados automáticamente

| Bean | Tipo | Condición |
|---|---|---|
| `rabbitConnectionFactory` | `ConnectionFactory` | `@ConditionalOnMissingBean` |
| `rabbitTemplate` | `RabbitTemplate` | `@ConditionalOnMissingBean` |
| `messageSerializer` | `MessageSerializer` | `@ConditionalOnMissingBean` |
| `messagePublisher` | `MessagePublisher` | `@ConditionalOnMissingBean` |
| `messageConsumer` | `MessageConsumer` | `@ConditionalOnMissingBean` |
| `mqClient` | `MQClient` | `@ConditionalOnMissingBean` |

---

## Módulos relacionados

| Módulo | Descripción |
|---|---|
| `ba-mq-core` | Interfaces, modelos y excepciones base (sin dependencia de broker) |
| `ba-mq-rabbit` | Implementación RabbitMQ de los contratos de `ba-mq-core` |
