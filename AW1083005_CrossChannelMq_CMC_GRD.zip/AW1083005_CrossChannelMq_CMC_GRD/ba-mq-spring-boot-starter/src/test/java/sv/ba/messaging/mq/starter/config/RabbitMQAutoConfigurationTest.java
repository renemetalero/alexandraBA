package sv.ba.messaging.mq.starter.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.rabbit.consumer.RabbitMessageConsumer;
import sv.ba.messaging.mq.rabbit.factory.RabbitMQClient;
import sv.ba.messaging.mq.rabbit.publisher.RabbitMessagePublisher;
import sv.ba.messaging.mq.serialization.MessageSerializer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RabbitMQAutoConfigurationTest {

    @Mock
    private RabbitMQProperties props;

    @Mock
    private ConnectionFactory connectionFactory;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private MessageSerializer serializer;

    @Mock
    private MQErrorResolver errorResolver;

    @Mock
    private MessagePublisher publisher;

    @Mock
    private MessageConsumer consumer;

    private RabbitMQAutoConfiguration config;

    @BeforeEach
    void setUp() {
        config = new RabbitMQAutoConfiguration();
    }

    @Test
    void rabbitConnectionFactoryReturnsCachingConnectionFactory() {
        when(props.getHost()).thenReturn("localhost");
        when(props.getPort()).thenReturn(5672);
        when(props.getUsername()).thenReturn("guest");
        when(props.getPassword()).thenReturn("guest");

        ConnectionFactory factory = config.rabbitConnectionFactory(props);

        assertThat(factory).isNotNull().isInstanceOf(CachingConnectionFactory.class);
    }

    @Test
    void rabbitTemplateReturnsRabbitTemplate() {
        RabbitTemplate template = config.rabbitTemplate(connectionFactory);

        assertThat(template).isNotNull().isInstanceOf(RabbitTemplate.class);
    }

    @Test
    void rabbitMessagePublisherIsRabbitMessagePublisher() {
        MessagePublisher result = config.rabbitMessagePublisher(rabbitTemplate, serializer, errorResolver);

        assertThat(result).isNotNull().isInstanceOf(RabbitMessagePublisher.class);
    }

    @Test
    void rabbitMessageConsumerIsRabbitMessageConsumer() {
        MessageConsumer result = config.rabbitMessageConsumer(connectionFactory, serializer, errorResolver);

        assertThat(result).isNotNull().isInstanceOf(RabbitMessageConsumer.class);
    }

    @Test
    void rabbitMQClientIsRabbitMQClient() {
        MQClient result = config.rabbitMQClient(publisher, consumer);

        assertThat(result).isNotNull().isInstanceOf(RabbitMQClient.class).isInstanceOf(MQClient.class);
    }
}
