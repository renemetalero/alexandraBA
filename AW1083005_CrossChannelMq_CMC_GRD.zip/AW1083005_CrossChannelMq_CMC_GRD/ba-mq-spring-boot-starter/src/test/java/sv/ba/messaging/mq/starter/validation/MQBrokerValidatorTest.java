package sv.ba.messaging.mq.starter.validation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MQBrokerValidatorTest {

    @Mock
    private Environment environment;

    @ParameterizedTest
    @CsvSource({
        "true, false",
        "false, true",
        "true, true"
    })
    void validateDoesNotThrow(boolean rabbitEnabled, boolean ibmEnabled) {
        when(environment.getProperty("ba.messaging.rabbit.enabled", Boolean.class, false)).thenReturn(rabbitEnabled);
        when(environment.getProperty("ba.messaging.ibm.enabled", Boolean.class, false)).thenReturn(ibmEnabled);

        MQBrokerValidator validator = new MQBrokerValidator(environment);

        assertThatCode(validator::validate).doesNotThrowAnyException();
    }

    @Test
    void validateThrowsIllegalStateExceptionWhenNoneEnabled() {
        when(environment.getProperty("ba.messaging.rabbit.enabled", Boolean.class, false)).thenReturn(false);
        when(environment.getProperty("ba.messaging.ibm.enabled", Boolean.class, false)).thenReturn(false);

        MQBrokerValidator validator = new MQBrokerValidator(environment);

        assertThatThrownBy(validator::validate)
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void validateExceptionMessageContainsBrokerGuidance() {
        when(environment.getProperty("ba.messaging.rabbit.enabled", Boolean.class, false)).thenReturn(false);
        when(environment.getProperty("ba.messaging.ibm.enabled", Boolean.class, false)).thenReturn(false);

        MQBrokerValidator validator = new MQBrokerValidator(environment);

        assertThatThrownBy(validator::validate)
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("ba-mq-starter")
                .hasMessageContaining("rabbit")
                .hasMessageContaining("ibm");
    }
}
