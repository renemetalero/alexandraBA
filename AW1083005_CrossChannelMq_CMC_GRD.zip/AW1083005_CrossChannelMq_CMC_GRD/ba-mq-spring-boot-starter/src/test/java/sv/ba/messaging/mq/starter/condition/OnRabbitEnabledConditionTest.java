package sv.ba.messaging.mq.starter.condition;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OnRabbitEnabledConditionTest {

    @Mock
    private ConditionContext context;

    @Mock
    private Environment environment;

    @Mock
    private AnnotatedTypeMetadata metadata;

    private final OnRabbitEnabledCondition condition = new OnRabbitEnabledCondition();

    @Test
    void getMatchOutcomeReturnsMatchWhenPropertyIsTrue() {
        when(context.getEnvironment()).thenReturn(environment);
        when(environment.getProperty("ba.messaging.rabbit.enabled", "true")).thenReturn("true");

        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        assertThat(outcome.isMatch()).isTrue();
    }

    @Test
    void getMatchOutcomeReturnsNoMatchWhenPropertyIsFalse() {
        when(context.getEnvironment()).thenReturn(environment);
        when(environment.getProperty("ba.messaging.rabbit.enabled", "true")).thenReturn("false");

        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).contains("RabbitMQ disabled by configuration");
    }

    @Test
    void getMatchOutcomeReturnsMatchWhenPropertyAbsentDefaultsToTrue() {
        when(context.getEnvironment()).thenReturn(environment);
        when(environment.getProperty("ba.messaging.rabbit.enabled", "true")).thenReturn("true");

        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        assertThat(outcome.isMatch()).isTrue();
        assertThat(outcome.getMessage()).isNull();
    }
}
