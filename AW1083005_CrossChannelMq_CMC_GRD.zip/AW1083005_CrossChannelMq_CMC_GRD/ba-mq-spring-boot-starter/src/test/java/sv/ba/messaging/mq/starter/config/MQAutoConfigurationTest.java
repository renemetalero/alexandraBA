package sv.ba.messaging.mq.starter.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.rabbit.serialization.JacksonMessageSerializer;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.starter.validation.MQBrokerValidator;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class MQAutoConfigurationTest {

    @Mock
    private MQClient rabbitMQClient;

    @Mock
    private MQClient ibmMQClient;

    @Mock
    private Environment environment;

    private MQAutoConfiguration config;

    @BeforeEach
    void setUp() {
        config = new MQAutoConfiguration();
    }

    @Test
    void objectMapperReturnsNonNull() {
        ObjectMapper mapper = config.objectMapper();

        assertThat(mapper).isNotNull().isInstanceOf(ObjectMapper.class);
    }

    @Test
    void messageSerializerReturnsJacksonMessageSerializer() {
        MessageSerializer serializer = config.messageSerializer(new ObjectMapper());

        assertThat(serializer).isNotNull().isInstanceOf(JacksonMessageSerializer.class);
    }

    @Test
    void mqClientFromRabbitReturnsSameRabbitInstance() {
        MQClient result = config.mqClientFromRabbit(rabbitMQClient);

        assertThat(result).isSameAs(rabbitMQClient);
    }

    @Test
    void mqClientFromIBMReturnsSameIBMInstance() {
        MQClient result = config.mqClientFromIBM(ibmMQClient);

        assertThat(result).isSameAs(ibmMQClient);
    }

    @Test
    void mqBrokerValidatorReturnsNonNull() {
        MQBrokerValidator validator = config.mqBrokerValidator(environment);

        assertThat(validator).isNotNull().isInstanceOf(MQBrokerValidator.class);
    }
}
