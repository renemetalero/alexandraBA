package sv.ba.messaging.mq.starter.config;

import jakarta.jms.ConnectionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.core.JmsTemplate;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.ibm.consumer.IBMMessageConsumer;
import sv.ba.messaging.mq.ibm.factory.IBMMQClient;
import sv.ba.messaging.mq.ibm.publisher.IBMMessagePublisher;
import sv.ba.messaging.mq.serialization.MessageSerializer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

@ExtendWith(MockitoExtension.class)
class IBMMQAutoConfigurationTest {

    @Mock
    private ConnectionFactory connectionFactory;

    @Mock
    private JmsTemplate jmsTemplate;

    @Mock
    private MessageSerializer serializer;

    @Mock
    private MQErrorResolver errorResolver;

    @Mock
    private MessagePublisher publisher;

    @Mock
    private MessageConsumer consumer;

    private IBMMQAutoConfiguration config;

    @BeforeEach
    void setUp() {
        config = new IBMMQAutoConfiguration();
    }

    @Test
    void ibmConnectionFactoryReturnsNonNull() throws Exception {
        IBMMQProperties props = new IBMMQProperties();
        props.setHost("localhost");
        props.setPort(1414);
        props.setChannel("DEV.APP.SVRCONN");
        props.setQueueManager("QM1");

        ConnectionFactory factory = config.ibmConnectionFactory(props);

        assertThat(factory).isNotNull();
    }

    @Test
    void ibmConnectionFactoryWithCredentialsReturnsNonNull() {
        IBMMQProperties props = new IBMMQProperties();
        props.setHost("localhost");
        props.setPort(1414);
        props.setChannel("DEV.APP.SVRCONN");
        props.setQueueManager("QM1");
        props.setUsername("mquser");
        props.setPassword("mqpass");

        assertThatCode(() -> config.ibmConnectionFactory(props)).doesNotThrowAnyException();
    }

    @Test
    void ibmJmsTemplateReturnsJmsTemplate() {
        JmsTemplate result = config.ibmJmsTemplate(connectionFactory);

        assertThat(result).isNotNull().isInstanceOf(JmsTemplate.class);
    }

    @Test
    void ibmMessagePublisherIsIBMMessagePublisher() {
        MessagePublisher result = config.ibmMessagePublisher(jmsTemplate, serializer, errorResolver);

        assertThat(result).isNotNull().isInstanceOf(IBMMessagePublisher.class);
    }

    @Test
    void ibmMessageConsumerIsIBMMessageConsumer() {
        MessageConsumer result = config.ibmMessageConsumer(connectionFactory, serializer, errorResolver);

        assertThat(result).isNotNull().isInstanceOf(IBMMessageConsumer.class);
    }

    @Test
    void ibmMQClientIsIBMMQClient() {
        MQClient result = config.ibmMQClient(publisher, consumer);

        assertThat(result).isNotNull().isInstanceOf(IBMMQClient.class).isInstanceOf(MQClient.class);
    }
}
