package sv.ba.messaging.mq.starter.config;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class IBMMQPropertiesTest {

    @Test
    void defaultValuesAreCorrect() {
        IBMMQProperties props = new IBMMQProperties();

        assertThat(props.isEnabled()).isFalse();
        assertThat(props.getHost()).isEqualTo("localhost");
        assertThat(props.getPort()).isEqualTo(1414);
        assertThat(props.getChannel()).isEqualTo("DEV.APP.SVRCONN");
        assertThat(props.getQueueManager()).isNull();
        assertThat(props.getUsername()).isNull();
        assertThat(props.getPassword()).isNull();
    }

    @Test
    void setEnabledUpdatesValue() {
        IBMMQProperties props = new IBMMQProperties();
        props.setEnabled(true);

        assertThat(props.isEnabled()).isTrue();
    }

    @Test
    void setHostUpdatesValue() {
        IBMMQProperties props = new IBMMQProperties();
        props.setHost("ibmmq.example.com");

        assertThat(props.getHost()).isEqualTo("ibmmq.example.com");
    }

    @Test
    void setPortUpdatesValue() {
        IBMMQProperties props = new IBMMQProperties();
        props.setPort(1415);

        assertThat(props.getPort()).isEqualTo(1415);
    }

    @Test
    void setChannelUpdatesValue() {
        IBMMQProperties props = new IBMMQProperties();
        props.setChannel("PROD.SVRCONN");

        assertThat(props.getChannel()).isEqualTo("PROD.SVRCONN");
    }

    @Test
    void setQueueManagerUpdatesValue() {
        IBMMQProperties props = new IBMMQProperties();
        props.setQueueManager("QM1");

        assertThat(props.getQueueManager()).isEqualTo("QM1");
    }

    @Test
    void setUsernameUpdatesValue() {
        IBMMQProperties props = new IBMMQProperties();
        props.setUsername("mquser");

        assertThat(props.getUsername()).isEqualTo("mquser");
    }

    @Test
    void setPasswordUpdatesValue() {
        IBMMQProperties props = new IBMMQProperties();
        props.setPassword("p4ssw0rd");

        assertThat(props.getPassword()).isEqualTo("p4ssw0rd");
    }
}
