package sv.ba.messaging.mq.starter.condition;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OnIBMEnabledConditionTest {

    @Mock
    private ConditionContext context;

    @Mock
    private Environment environment;

    @Mock
    private AnnotatedTypeMetadata metadata;

    private final OnIBMEnabledCondition condition = new OnIBMEnabledCondition();

    @Test
    void getMatchOutcomeReturnsMatchWhenPropertyIsTrue() {
        when(context.getEnvironment()).thenReturn(environment);
        when(environment.getProperty("ba.messaging.ibm.enabled", "false")).thenReturn("true");

        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        assertThat(outcome.isMatch()).isTrue();
    }

    @Test
    void getMatchOutcomeReturnsNoMatchWhenPropertyIsFalse() {
        when(context.getEnvironment()).thenReturn(environment);
        when(environment.getProperty("ba.messaging.ibm.enabled", "false")).thenReturn("false");

        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).contains("IBM MQ disabled by configuration");
    }

    @Test
    void getMatchOutcomeReturnsNoMatchWhenPropertyAbsentDefaultsFalse() {
        when(context.getEnvironment()).thenReturn(environment);
        when(environment.getProperty("ba.messaging.ibm.enabled", "false")).thenReturn("false");

        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        assertThat(outcome.isMatch()).isFalse();
    }
}
