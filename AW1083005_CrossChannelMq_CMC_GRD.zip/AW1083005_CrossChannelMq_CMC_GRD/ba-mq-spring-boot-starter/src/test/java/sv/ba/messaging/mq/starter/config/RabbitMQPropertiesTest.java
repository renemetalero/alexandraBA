package sv.ba.messaging.mq.starter.config;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class RabbitMQPropertiesTest {

    @Test
    void defaultValuesAreCorrect() {
        RabbitMQProperties props = new RabbitMQProperties();

        assertThat(props.isEnabled()).isTrue();
        assertThat(props.getPort()).isEqualTo(5672);
        assertThat(props.getHost()).isNull();
        assertThat(props.getUsername()).isNull();
        assertThat(props.getPassword()).isNull();
        assertThat(props.getExchange()).isNull();
    }

    @Test
    void setEnabledUpdatesValue() {
        RabbitMQProperties props = new RabbitMQProperties();
        props.setEnabled(false);

        assertThat(props.isEnabled()).isFalse();
    }

    @Test
    void setHostUpdatesValue() {
        RabbitMQProperties props = new RabbitMQProperties();
        props.setHost("rabbit.example.com");

        assertThat(props.getHost()).isEqualTo("rabbit.example.com");
    }

    @Test
    void setPortUpdatesValue() {
        RabbitMQProperties props = new RabbitMQProperties();
        props.setPort(5673);

        assertThat(props.getPort()).isEqualTo(5673);
    }

    @Test
    void setUsernameUpdatesValue() {
        RabbitMQProperties props = new RabbitMQProperties();
        props.setUsername("admin");

        assertThat(props.getUsername()).isEqualTo("admin");
    }

    @Test
    void setPasswordUpdatesValue() {
        RabbitMQProperties props = new RabbitMQProperties();
        props.setPassword("s3cr3t");

        assertThat(props.getPassword()).isEqualTo("s3cr3t");
    }

    @Test
    void setExchangeUpdatesValue() {
        RabbitMQProperties props = new RabbitMQProperties();
        props.setExchange("my-exchange");

        assertThat(props.getExchange()).isEqualTo("my-exchange");
    }
}
