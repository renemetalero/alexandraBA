package sv.ba.messaging.mq.starter.condition;

import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * Condición Spring Boot que activa la auto-configuración de RabbitMQ
 * únicamente cuando la propiedad {@code ba.messaging.rabbit.enabled} es
 * {@code true} (valor por defecto si no se especifica).
 * <p>
 * Permite deshabilitar completamente el cliente de mensajería en entornos
 * donde RabbitMQ no está disponible (e.g. tests unitarios, entornos locales)
 * sin necesidad de excluir la auto-configuración manualmente.
 * </p>
 *
 * <pre>{@code
 * # Para deshabilitar:
 * ba:
 *   messaging:
 *     rabbit:
 *       enabled: false
 * }</pre>
 */
public class OnRabbitEnabledCondition extends SpringBootCondition {

    
    /**
     * Evalúa si la propiedad {@code ba.messaging.rabbit.enabled} está activa.
     *
     * @param context  contexto de la condición con acceso al {@code Environment}
     * @param metadata metadata de la clase anotada
     * @return {@link ConditionOutcome#match()} si habilitado,
     *         {@link ConditionOutcome#noMatch} en caso contrario
     */
    @Override
    public ConditionOutcome getMatchOutcome(
            ConditionContext context,
            AnnotatedTypeMetadata metadata) {

        String enabled =
                context.getEnvironment()
                       .getProperty("ba.messaging.rabbit.enabled", "true");

        return Boolean.parseBoolean(enabled)
                ? ConditionOutcome.match()
                : ConditionOutcome.noMatch("RabbitMQ disabled by configuration");
    }
}

