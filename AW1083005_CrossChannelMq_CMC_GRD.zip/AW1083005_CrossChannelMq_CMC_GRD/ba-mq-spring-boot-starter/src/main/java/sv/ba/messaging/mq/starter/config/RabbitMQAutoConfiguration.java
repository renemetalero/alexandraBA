package sv.ba.messaging.mq.starter.config;

import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.rabbit.consumer.RabbitMessageConsumer;
import sv.ba.messaging.mq.rabbit.factory.RabbitMQClient;
import sv.ba.messaging.mq.rabbit.publisher.RabbitMessagePublisher;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.starter.condition.OnRabbitEnabledCondition;

/**
 * Auto-configuración Spring Boot para RabbitMQ.
 * <p>
 * Se activa únicamente cuando la propiedad {@code ba.messaging.rabbit.enabled=true}.
 * Registra los beans de infraestructura RabbitMQ con nombres explícitos para
 * coexistir correctamente cuando IBM MQ también está habilitado.
 * </p>
 *
 * <p>Beans registrados:</p>
 * <ul>
 *   <li>{@code rabbitConnectionFactory} — {@link ConnectionFactory} AMQP hacia RabbitMQ</li>
 *   <li>{@code rabbitTemplate} — {@link RabbitTemplate} de Spring AMQP</li>
 *   <li>{@code rabbitMessagePublisher} — {@link MessagePublisher} RabbitMQ</li>
 *   <li>{@code rabbitMessageConsumer} — {@link MessageConsumer} RabbitMQ</li>
 *   <li>{@code rabbitMQClient} — {@link MQClient} Facade RabbitMQ</li>
 * </ul>
 *
 * @see RabbitMQProperties
 * @see OnRabbitEnabledCondition
 */
@AutoConfiguration
@EnableConfigurationProperties(RabbitMQProperties.class)
@Conditional(OnRabbitEnabledCondition.class)
public class RabbitMQAutoConfiguration {

    // Infra ----------------------------------------------------------------

    /**
     * Registra una {@link CachingConnectionFactory} configurada con los valores
     * de {@link RabbitMQProperties}.
     * Solo se crea si no existe un bean {@code rabbitConnectionFactory} en el contexto.
     *
     * @param props propiedades de conexión RabbitMQ
     * @return factory de conexiones AMQP cacheada
     */
    @Bean("rabbitConnectionFactory")
    @ConditionalOnMissingBean(name = "rabbitConnectionFactory")
    ConnectionFactory rabbitConnectionFactory(RabbitMQProperties props) {
        CachingConnectionFactory factory =
                new CachingConnectionFactory(props.getHost(), props.getPort());
        factory.setUsername(props.getUsername());
        factory.setPassword(props.getPassword());
        return factory;
    }

    /**
     * Registra el {@link RabbitTemplate} de Spring AMQP.
     * Solo se crea si no existe un bean {@code rabbitTemplate} en el contexto.
     *
     * @param connectionFactory factory de conexiones AMQP
     * @return cliente de operaciones AMQP
     */
    @Bean("rabbitTemplate")
    @ConditionalOnMissingBean(name = "rabbitTemplate")
    RabbitTemplate rabbitTemplate(
            @Qualifier("rabbitConnectionFactory") ConnectionFactory connectionFactory) {
        return new RabbitTemplate(connectionFactory);
    }

    // Adapter ---------------------------------------------------------------

    /**
     * Registra el {@link MessagePublisher} respaldado por RabbitMQ.
     * Solo se crea si no existe un bean {@code rabbitMessagePublisher} en el contexto.
     *
     * @param rabbitTemplate cliente AMQP de Spring
     * @param serializer     serializador de payloads
     * @return publisher RabbitMQ
     */
    @Bean("rabbitMessagePublisher")
    @ConditionalOnMissingBean(name = "rabbitMessagePublisher")
    MessagePublisher rabbitMessagePublisher(
            @Qualifier("rabbitTemplate") RabbitTemplate rabbitTemplate,
            MessageSerializer serializer,
            MQErrorResolver errorResolver) {
        return new RabbitMessagePublisher(rabbitTemplate, serializer, errorResolver);
    }

    /**
     * Registra el {@link MessageConsumer} respaldado por RabbitMQ.
     * Solo se crea si no existe un bean {@code rabbitMessageConsumer} en el contexto.
     *
     * @param connectionFactory factory de conexiones AMQP
     * @param serializer        serializador de payloads
     * @return consumer RabbitMQ
     */
    @Bean("rabbitMessageConsumer")
    @ConditionalOnMissingBean(name = "rabbitMessageConsumer")
    MessageConsumer rabbitMessageConsumer(
            @Qualifier("rabbitConnectionFactory") ConnectionFactory connectionFactory,
            MessageSerializer serializer,
            MQErrorResolver errorResolver) {
        return new RabbitMessageConsumer(connectionFactory, serializer, errorResolver);
    }

    // Facade ----------------------------------------------------------------

    /**
     * Registra el {@link MQClient} Facade de RabbitMQ, identificado como {@code rabbitMQClient}.
     * Solo se crea si no existe un bean {@code rabbitMQClient} en el contexto.
     *
     * @param publisher publisher RabbitMQ registrado en el contexto
     * @param consumer  consumer RabbitMQ registrado en el contexto
     * @return cliente unificado RabbitMQ
     */
    @Bean("rabbitMQClient")
    @ConditionalOnMissingBean(name = "rabbitMQClient")
    MQClient rabbitMQClient(
            @Qualifier("rabbitMessagePublisher") MessagePublisher publisher,
            @Qualifier("rabbitMessageConsumer") MessageConsumer consumer) {
        return new RabbitMQClient(publisher, consumer);
    }
}
