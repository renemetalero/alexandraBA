package sv.ba.messaging.mq.starter.condition;

import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * Condición Spring Boot que activa la auto-configuración de IBM MQ
 * únicamente cuando la propiedad {@code ba.messaging.ibm.enabled} es {@code true}.
 * <p>
 * Por defecto esta condición es {@code false}: IBM MQ debe habilitarse explícitamente.
 * </p>
 *
 * <pre>{@code
 * ba:
 *   messaging:
 *     ibm:
 *       enabled: true
 * }</pre>
 */
public class OnIBMEnabledCondition extends SpringBootCondition {

    /**
     * Evalúa si la propiedad {@code ba.messaging.ibm.enabled} está activa.
     *
     * @param context  contexto de la condición con acceso al {@code Environment}
     * @param metadata metadata de la clase anotada
     * @return {@link ConditionOutcome#match()} si habilitado,
     *         {@link ConditionOutcome#noMatch} en caso contrario
     */
    @Override
    public ConditionOutcome getMatchOutcome(
            ConditionContext context,
            AnnotatedTypeMetadata metadata) {

        String enabled =
                context.getEnvironment()
                       .getProperty("ba.messaging.ibm.enabled", "false");

        return Boolean.parseBoolean(enabled)
                ? ConditionOutcome.match()
                : ConditionOutcome.noMatch("IBM MQ disabled by configuration");
    }
}
