package sv.ba.messaging.mq.starter.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Propiedades de configuración para la conexión a RabbitMQ.
 * <p>
 * Se mapean automáticamente desde {@code application.yml} o
 * {@code application.properties} bajo el prefijo {@code ba.messaging.rabbit}.
 * </p>
 *
 * <pre>{@code
 * ba:
 *   messaging:
 *     rabbit:
 *       enabled: true
 *       host: localhost
 *       port: 5672
 *       username: guest
 *       password: guest
 *       exchange: my-exchange
 * }</pre>
 */
@ConfigurationProperties(prefix = "ba.messaging.rabbit")
public class RabbitMQProperties {

    /** Habilita o deshabilita toda la auto-configuración. Valor por defecto: {@code true}. */
    private boolean enabled = true;

    /** Host del servidor RabbitMQ. */
    private String host;

    /** Puerto del servidor RabbitMQ. Valor por defecto: {@code 5672}. */
    private int port = 5672;

    /** Usuario para autenticación en RabbitMQ. */
    private String username;

    /** Contraseña para autenticación en RabbitMQ. */
    private String password;

    /** Nombre del exchange principal al que se publican los mensajes. */
    private String exchange;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getHost() {
        return host;
    }
    public void setHost(String host) {
        this.host = host;
    }
    public int getPort() {
        return port;
    }
    public void setPort(int port) {
        this.port = port;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getExchange() {
        return exchange;
    }
    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    

}
