package sv.ba.messaging.mq.starter.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.rabbit.serialization.JacksonMessageSerializer;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.starter.error.PropertiesMQErrorResolver;
import sv.ba.messaging.mq.starter.validation.MQBrokerValidator;

/**
 * Auto-configuración principal del starter de mensajería.
 * <p>
 * Actúa como <b>orquestador</b>: delega la configuración específica de cada broker
 * a {@link RabbitMQAutoConfiguration} e {@link IBMMQAutoConfiguration}, y se encarga
 * de los beans compartidos (serialización) y del bean primario {@code mqClient}.
 * </p>
 *
 * <h3>Comportamiento según la configuración:</h3>
 * <ul>
 *   <li><b>Solo Rabbit habilitado</b>: se registra un bean primario {@code mqClient}
 *       que delega a {@code rabbitMQClient}. Inyectables: {@code MQClient} o
 *       {@code @Qualifier("rabbitMQClient") MQClient}.</li>
 *   <li><b>Solo IBM habilitado</b>: se registra un bean primario {@code mqClient}
 *       que delega a {@code ibmMQClient}. Inyectables: {@code MQClient} o
 *       {@code @Qualifier("ibmMQClient") MQClient}.</li>
 *   <li><b>Ambos habilitados</b>: no se registra bean primario. El consumidor
 *       debe usar {@code @Qualifier("rabbitMQClient")} o {@code @Qualifier("ibmMQClient")}.</li>
 *   <li><b>Ninguno habilitado</b>: la aplicación falla en startup con mensaje descriptivo.</li>
 * </ul>
 *
 * @see RabbitMQAutoConfiguration
 * @see IBMMQAutoConfiguration
 * @see MQBrokerValidator
 */
@AutoConfiguration(after = {RabbitMQAutoConfiguration.class, IBMMQAutoConfiguration.class})
public class MQAutoConfiguration {

    // Serialización compartida -----------------------------------------------

    /**
     * Registra el {@link MQErrorResolver} que provee los mensajes del catálogo de errores.
     * Solo se crea si el consumidor no declara su propio bean {@link MQErrorResolver},
     * permitiendo sobrescribir los mensajes sin necesidad de modificar la librería.
     *
     * @return resolver de mensajes basado en {@code classpath:mq-errors.properties}
     */
    @Bean
    @ConditionalOnMissingBean(MQErrorResolver.class)
    MQErrorResolver mqErrorResolver() {
        return new PropertiesMQErrorResolver();
    }

    /**
     * Registra un {@link ObjectMapper} por defecto.
     * Solo se crea si el proyecto consumidor no declara su propio bean
     * (e.g. proyectos sin {@code spring-boot-starter-web}).
     *
     * @return instancia de Jackson con configuración por defecto
     */
    @Bean
    @ConditionalOnMissingBean
    ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    /**
     * Registra el {@link MessageSerializer} basado en Jackson.
     * Puede sobreescribirse con una estrategia personalizada (Avro, Protobuf, etc.)
     * declarando un bean {@link MessageSerializer} en el contexto consumidor.
     *
     * @param objectMapper instancia de Jackson provista por Spring Boot o por este starter
     * @return serializador JSON
     */
    @Bean
    @ConditionalOnMissingBean
    MessageSerializer messageSerializer(ObjectMapper objectMapper) {
        return new JacksonMessageSerializer(objectMapper);
    }

    // Bean primario: solo Rabbit activo -------------------------------------

    /**
     * Registra el bean primario {@code mqClient} delegando a {@code rabbitMQClient}
     * cuando <b>solo</b> RabbitMQ está habilitado (IBM MQ no existe en el contexto).
     *
     * @param rabbitMQClient cliente RabbitMQ registrado por {@link RabbitMQAutoConfiguration}
     * @return cliente primario inyectable como {@code MQClient}
     */
    @Bean
    @Primary
    @ConditionalOnBean(name = "rabbitMQClient")
    @ConditionalOnMissingBean(name = "ibmMQClient")
    MQClient mqClientFromRabbit(
            @Qualifier("rabbitMQClient") MQClient rabbitMQClient) {
        return rabbitMQClient;
    }

    // Bean primario: solo IBM activo ----------------------------------------

    /**
     * Registra el bean primario {@code mqClient} delegando a {@code ibmMQClient}
     * cuando <b>solo</b> IBM MQ está habilitado (RabbitMQ no existe en el contexto).
     *
     * @param ibmMQClient cliente IBM MQ registrado por {@link IBMMQAutoConfiguration}
     * @return cliente primario inyectable como {@code MQClient}
     */
    @Bean
    @Primary
    @ConditionalOnBean(name = "ibmMQClient")
    @ConditionalOnMissingBean(name = "rabbitMQClient")
    MQClient mqClientFromIBM(
            @Qualifier("ibmMQClient") MQClient ibmMQClient) {
        return ibmMQClient;
    }

    // Validación -------------------------------------------------------------

    /**
     * Registra el validador de arranque que garantiza que al menos un broker
     * esté habilitado. Falla con mensaje descriptivo si ninguno está activo.
     *
     * @param environment entorno Spring para leer las propiedades
     * @return validador de configuración de brokers
     */
    @Bean
    MQBrokerValidator mqBrokerValidator(Environment environment) {
        return new MQBrokerValidator(environment);
    }
}
