package sv.ba.messaging.mq.starter.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.jms.core.JmsTemplate;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.ibm.config.IBMConnectionFactoryBuilder;
import sv.ba.messaging.mq.ibm.consumer.IBMMessageConsumer;
import sv.ba.messaging.mq.ibm.factory.IBMMQClient;
import sv.ba.messaging.mq.ibm.publisher.IBMMessagePublisher;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.starter.condition.OnIBMEnabledCondition;

import jakarta.jms.ConnectionFactory;

/**
 * Auto-configuración Spring Boot para IBM MQ sobre JMS.
 * <p>
 * Se activa únicamente cuando la propiedad {@code ba.messaging.ibm.enabled=true}.
 * Registra los beans de infraestructura IBM MQ con nombres explícitos para
 * coexistir correctamente cuando RabbitMQ también está habilitado.
 * </p>
 *
 * <p>Beans registrados:</p>
 * <ul>
 *   <li>{@code ibmConnectionFactory} — {@link ConnectionFactory} JMS hacia IBM MQ</li>
 *   <li>{@code ibmJmsTemplate} — {@link JmsTemplate} de Spring JMS</li>
 *   <li>{@code ibmMessagePublisher} — {@link MessagePublisher} IBM MQ</li>
 *   <li>{@code ibmMessageConsumer} — {@link MessageConsumer} IBM MQ</li>
 *   <li>{@code ibmMQClient} — {@link MQClient} Facade IBM MQ</li>
 * </ul>
 *
 * @see IBMMQProperties
 * @see OnIBMEnabledCondition
 */
@AutoConfiguration
@EnableConfigurationProperties(IBMMQProperties.class)
@Conditional(OnIBMEnabledCondition.class)
public class IBMMQAutoConfiguration {

    // Infra ----------------------------------------------------------------

    /**
     * Registra la {@link ConnectionFactory} JMS apuntando a IBM MQ,
     * configurada con los valores de {@link IBMMQProperties}.
     * Solo se crea si no existe un bean {@code ibmConnectionFactory} en el contexto.
     *
     * @param props propiedades de conexión IBM MQ
     * @return factory de conexiones JMS hacia IBM MQ
     * @throws Exception si la configuración del MQQueueConnectionFactory falla
     */
    @Bean("ibmConnectionFactory")
    @ConditionalOnMissingBean(name = "ibmConnectionFactory")
    ConnectionFactory ibmConnectionFactory(IBMMQProperties props) {
        return IBMConnectionFactoryBuilder.build(
                props.getHost(),
                props.getPort(),
                props.getChannel(),
                props.getQueueManager(),
                props.getUsername(),
                props.getPassword());
    }

    /**
     * Registra el {@link JmsTemplate} de Spring JMS configurado para IBM MQ.
     * Solo se crea si no existe un bean {@code ibmJmsTemplate} en el contexto.
     *
     * @param connectionFactory factory de conexiones IBM MQ
     * @return template de operaciones JMS
     */
    @Bean("ibmJmsTemplate")
    @ConditionalOnMissingBean(name = "ibmJmsTemplate")
    JmsTemplate ibmJmsTemplate(
            @Qualifier("ibmConnectionFactory") ConnectionFactory connectionFactory) {
        return new JmsTemplate(connectionFactory);
    }

    // Adapter ---------------------------------------------------------------

    /**
     * Registra el {@link MessagePublisher} respaldado por IBM MQ.
     * Solo se crea si no existe un bean {@code ibmMessagePublisher} en el contexto.
     *
     * @param jmsTemplate cliente JMS de Spring
     * @param serializer  serializador de payloads
     * @return publisher IBM MQ
     */
    @Bean("ibmMessagePublisher")
    @ConditionalOnMissingBean(name = "ibmMessagePublisher")
    MessagePublisher ibmMessagePublisher(
            @Qualifier("ibmJmsTemplate") JmsTemplate jmsTemplate,
            MessageSerializer serializer,
            MQErrorResolver errorResolver) {
        return new IBMMessagePublisher(jmsTemplate, serializer, errorResolver);
    }

    /**
     * Registra el {@link MessageConsumer} respaldado por IBM MQ.
     * Solo se crea si no existe un bean {@code ibmMessageConsumer} en el contexto.
     *
     * @param connectionFactory factory de conexiones IBM MQ
     * @param serializer        serializador de payloads
     * @return consumer IBM MQ
     */
    @Bean("ibmMessageConsumer")
    @ConditionalOnMissingBean(name = "ibmMessageConsumer")
    MessageConsumer ibmMessageConsumer(
            @Qualifier("ibmConnectionFactory") ConnectionFactory connectionFactory,
            MessageSerializer serializer,
            MQErrorResolver errorResolver) {
        return new IBMMessageConsumer(connectionFactory, serializer, errorResolver);
    }

    // Facade ----------------------------------------------------------------

    /**
     * Registra el {@link MQClient} Facade de IBM MQ, identificado como {@code ibmMQClient}.
     * Solo se crea si no existe un bean {@code ibmMQClient} en el contexto.
     *
     * @param publisher publisher IBM MQ registrado en el contexto
     * @param consumer  consumer IBM MQ registrado en el contexto
     * @return cliente unificado IBM MQ
     */
    @Bean("ibmMQClient")
    @ConditionalOnMissingBean(name = "ibmMQClient")
    MQClient ibmMQClient(
            @Qualifier("ibmMessagePublisher") MessagePublisher publisher,
            @Qualifier("ibmMessageConsumer") MessageConsumer consumer) {
        return new IBMMQClient(publisher, consumer);
    }
}
