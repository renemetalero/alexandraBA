package sv.ba.messaging.mq.starter.validation;

import jakarta.annotation.PostConstruct;
import org.springframework.core.env.Environment;

/**
 * Validador de arranque que garantiza que al menos un broker de mensajería
 * esté habilitado en la configuración.
 * <p>
 * Se ejecuta durante el arranque del contexto Spring. Si ni RabbitMQ ni IBM MQ
 * están habilitados, lanza una {@link IllegalStateException} con un mensaje
 * descriptivo que guía al desarrollador sobre cómo resolverlo.
 * </p>
 */
public class MQBrokerValidator {

    private final Environment environment;

    /**
     * Construye el validador con el entorno Spring para leer las propiedades.
     *
     * @param environment entorno Spring; no debe ser {@code null}
     */
    public MQBrokerValidator(Environment environment) {
        this.environment = environment;
    }

    /**
     * Valida que al menos un broker esté habilitado.
     * Se ejecuta automáticamente después de la inyección de dependencias.
     *
     * @throws IllegalStateException si ningún broker está habilitado
     */
    @PostConstruct
    public void validate() {
        boolean rabbitEnabled = environment.getProperty(
                "ba.messaging.rabbit.enabled", Boolean.class, false);
        boolean ibmEnabled = environment.getProperty(
                "ba.messaging.ibm.enabled", Boolean.class, false);

        if (!rabbitEnabled && !ibmEnabled) {
            throw new IllegalStateException("""
                    [ba-mq-starter] No hay ningún broker de mensajería habilitado.
                    Por estándar, al menos uno debe estar activo. Habilita uno en tu application.yml:

                      ba:
                        messaging:
                          rabbit:
                            enabled: true   # para RabbitMQ
                          ibm:
                            enabled: true   # para IBM MQ

                    Para deshabilitar esta validación elimina la dependencia del starter.""");
        }
    }
}
