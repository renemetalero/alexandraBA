package sv.ba.messaging.mq.starter.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Propiedades de configuración para la conexión a IBM MQ via JMS.
 * <p>
 * Se mapean automáticamente desde {@code application.yml} o
 * {@code application.properties} bajo el prefijo {@code ba.messaging.ibm}.
 * </p>
 *
 * <pre>{@code
 * ba:
 *   messaging:
 *     ibm:
 *       enabled: true
 *       host: localhost
 *       port: 1414
 *       channel: DEV.APP.SVRCONN
 *       queue-manager: QM1
 *       username: app
 *       password: passw0rd
 * }</pre>
 */
@ConfigurationProperties(prefix = "ba.messaging.ibm")
public class IBMMQProperties {

    /** Habilita o deshabilita la auto-configuración de IBM MQ. Valor por defecto: {@code false}. */
    private boolean enabled = false;

    /** Host del servidor IBM MQ. */
    private String host = "localhost";

    /** Puerto del servidor IBM MQ. Valor por defecto: {@code 1414}. */
    private int port = 1414;

    /** Nombre del canal de conexión del servidor IBM MQ. */
    private String channel = "DEV.APP.SVRCONN";

    /** Nombre del Queue Manager de IBM MQ. */
    private String queueManager;

    /** Usuario para autenticación en IBM MQ. */
    private String username;

    /** Contraseña para autenticación en IBM MQ. */
    private String password;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public String getHost() { return host; }
    public void setHost(String host) { this.host = host; }

    public int getPort() { return port; }
    public void setPort(int port) { this.port = port; }

    public String getChannel() { return channel; }
    public void setChannel(String channel) { this.channel = channel; }

    public String getQueueManager() { return queueManager; }
    public void setQueueManager(String queueManager) { this.queueManager = queueManager; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
