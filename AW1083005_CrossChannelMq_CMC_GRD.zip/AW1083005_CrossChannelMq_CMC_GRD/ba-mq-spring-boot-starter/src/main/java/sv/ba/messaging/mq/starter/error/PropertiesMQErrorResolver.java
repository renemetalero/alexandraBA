package sv.ba.messaging.mq.starter.error;

import sv.ba.messaging.mq.exception.MQErrorResolver;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Implementación de {@link MQErrorResolver} que carga mensajes desde
 * {@code classpath:mq-errors.properties}.
 * <p>
 * El consumidor puede sobreescribir cualquier mensaje colocando su propio
 * {@code mq-errors.properties} en {@code src/main/resources/} de su aplicación.
 * Al tener mayor precedencia en el classpath, reemplaza el archivo de la librería
 * sin necesidad de declarar un bean personalizado.
 * </p>
 * <p>
 * Si el archivo no se encuentra en el classpath, {@link #resolve(String)} retorna
 * un mensaje de fallback con el código entre corchetes.
 * </p>
 */
public class PropertiesMQErrorResolver implements MQErrorResolver {

    private final Properties properties = new Properties();

    public PropertiesMQErrorResolver() {
        try (InputStream is = getClass().getClassLoader()
                .getResourceAsStream("mq-errors.properties")) {
            if (is != null) {
                properties.load(is);
            }
        } catch (IOException ignored) {
            // Si el archivo no está disponible, resolve() retorna el fallback
        }
    }

    @Override
    public String resolve(String errorCode) {
        return properties.getProperty(errorCode, "Error [" + errorCode + "]");
    }
}
