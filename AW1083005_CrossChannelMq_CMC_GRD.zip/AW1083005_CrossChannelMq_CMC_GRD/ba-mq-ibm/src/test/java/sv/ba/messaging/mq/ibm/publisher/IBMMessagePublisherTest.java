package sv.ba.messaging.mq.ibm.publisher;

import jakarta.jms.BytesMessage;
import jakarta.jms.Session;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import sv.ba.messaging.mq.exception.DefaultMQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.serialization.SerializationException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IBMMessagePublisherTest {

    @Mock
    private JmsTemplate jmsTemplate;

    @Mock
    private MessageSerializer serializer;

    private IBMMessagePublisher publisher;

    @BeforeEach
    void setUp() {
        publisher = new IBMMessagePublisher(jmsTemplate, serializer, new DefaultMQErrorResolver());
    }

    @Test
    void publish_serializesPayloadAndSendsToQueue() {
        Message message = Message.builder().payload("order-created").build();
        when(serializer.serialize("order-created")).thenReturn(new byte[]{1, 2, 3});

        publisher.publish("ORDERS.QUEUE", message);

        verify(serializer).serialize("order-created");
        verify(jmsTemplate).send(eq("ORDERS.QUEUE"), any(MessageCreator.class));
    }

    @Test
    void publish_createsBytesMessage_withSerializedBody() throws Exception {
        byte[] serializedBody = "serialized-payload".getBytes();
        Message message = Message.builder().payload("any-payload").build();
        when(serializer.serialize(any())).thenReturn(serializedBody);

        ArgumentCaptor<MessageCreator> creatorCaptor = ArgumentCaptor.forClass(MessageCreator.class);
        publisher.publish("PAYMENTS.QUEUE", message);

        verify(jmsTemplate).send(eq("PAYMENTS.QUEUE"), creatorCaptor.capture());

        // Execute the captured MessageCreator lambda with a mock Session
        Session mockSession = mock(Session.class);
        BytesMessage mockBytesMsg = mock(BytesMessage.class);
        when(mockSession.createBytesMessage()).thenReturn(mockBytesMsg);

        jakarta.jms.Message result = creatorCaptor.getValue().createMessage(mockSession);

        verify(mockSession).createBytesMessage();
        verify(mockBytesMsg).writeBytes(serializedBody);
        assertThat(result).isSameAs(mockBytesMsg);
    }

    @Test
    void publish_throwsMQException_whenSerializerFails() {
        Message message = Message.builder().payload("bad-payload").build();
        when(serializer.serialize(any()))
                .thenThrow(new SerializationException("jackson error", new RuntimeException()));

        assertThatThrownBy(() -> publisher.publish("ORDERS.QUEUE", message))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al publicar mensaje en el broker");
    }

    @Test
    void publish_throwsMQException_whenJmsTemplateFails() {
        Message message = Message.builder().payload("payload").build();
        when(serializer.serialize(any())).thenReturn(new byte[]{1, 2});
        doThrow(new RuntimeException("broker unreachable"))
                .when(jmsTemplate).send(any(String.class), any(MessageCreator.class));

        assertThatThrownBy(() -> publisher.publish("ORDERS.QUEUE", message))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al publicar mensaje en el broker")
                .hasCauseInstanceOf(RuntimeException.class);
    }

    @Test
    void publish_wrapsOriginalCause_inMQException() {
        RuntimeException originalCause = new RuntimeException("network timeout");
        Message message = Message.builder().payload("x").build();
        when(serializer.serialize(any())).thenReturn(new byte[0]);
        doThrow(originalCause)
                .when(jmsTemplate).send(any(String.class), any(MessageCreator.class));

        assertThatThrownBy(() -> publisher.publish("TOPIC", message))
                .isInstanceOf(MQException.class)
                .cause()
                .isSameAs(originalCause);
    }
}
