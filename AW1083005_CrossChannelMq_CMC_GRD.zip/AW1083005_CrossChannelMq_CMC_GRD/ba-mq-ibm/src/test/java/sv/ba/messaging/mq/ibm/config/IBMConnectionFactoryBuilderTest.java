package sv.ba.messaging.mq.ibm.config;

import jakarta.jms.ConnectionFactory;
import org.junit.jupiter.api.Test;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class IBMConnectionFactoryBuilderTest {

    // -------------------------------------------------------------------------
    // build()
    // -------------------------------------------------------------------------

    @Test
    void build_returnsJakartaConnectionFactory_withValidParameters() throws Exception {
        ConnectionFactory cf = IBMConnectionFactoryBuilder.build(
                "localhost", 1414, "DEV.APP.SVRCONN", "QM1", null, null);

        assertThat(cf).isNotNull().isInstanceOf(ConnectionFactory.class);
    }

    @Test
    void build_doesNotThrow_whenUsernameIsBlank() {
        assertThatNoException()
                .isThrownBy(() -> IBMConnectionFactoryBuilder.build("host", 1414, "CH", "QM", "  ", null));
    }

    @Test
    void build_doesNotThrow_whenUsernameIsNull() {
        assertThatNoException()
                .isThrownBy(() -> IBMConnectionFactoryBuilder.build("host", 1414, "CH", "QM", null, null));
    }

    @Test
    void build_doesNotThrow_whenUsernameAndPasswordAreProvided() {
        assertThatNoException()
                .isThrownBy(() -> IBMConnectionFactoryBuilder.build("host", 1414, "CH", "QM", "user", "pass"));
    }

    // -------------------------------------------------------------------------
    // adaptToJakarta() — package-private, accessible from same package
    // -------------------------------------------------------------------------

    @Test
    void adaptToJakarta_returnsProxy_implementingTargetInterface() {
        GreeterImpl target = new GreeterImpl();

        Greeter proxy = IBMConnectionFactoryBuilder.adaptToJakarta(target, Greeter.class);

        assertThat(Proxy.isProxyClass(proxy.getClass())).isTrue();
        assertThat(proxy).isInstanceOf(Greeter.class);
    }

    @Test
    void adaptToJakarta_delegatesMethodCallsToTarget() {
        GreeterImpl target = new GreeterImpl();

        Greeter proxy = IBMConnectionFactoryBuilder.adaptToJakarta(target, Greeter.class);

        assertThat(proxy.greet("World")).isEqualTo("Hello World");
    }

    @Test
    void adaptToJakarta_rethrowsCause_whenTargetMethodThrowsRuntimeException() {
        ExplodingImpl target = new ExplodingImpl();

        Exploding proxy = IBMConnectionFactoryBuilder.adaptToJakarta(target, Exploding.class);

        org.assertj.core.api.Assertions.
                            assertThatThrownBy(proxy::boom)
                                    .isInstanceOf(IBMConnectionFactoryException.class)
                                    .hasCauseInstanceOf(InvocationTargetException.class)
                                    .satisfies(ex -> {
                                        Throwable cause = ex.getCause().getCause();
                                        assertThat(cause)
                                            .isInstanceOf(IllegalStateException.class)
                                            .hasMessage("intentional failure");
                                    });

    }

    @Test
    void adaptToJakarta_wrapsJavaxJmsException_intoJakartaJmsException_whenMethodDeclaresIt()
            throws Exception {
        // JmsThrowingImpl throws javax.jms.JMSException; JmsDeclaring declares
        // jakarta.jms.JMSException.
        // wrapJmsException should bridge the two.
        JmsDeclaring proxy = IBMConnectionFactoryBuilder.adaptToJakarta(
                new JmsThrowingImpl(), JmsDeclaring.class);

        
        assertThatThrownBy(proxy::doWork)
                .isInstanceOf(IBMConnectionFactoryException.class)
                .hasCauseInstanceOf(InvocationTargetException.class)
                .satisfies(ex -> {
                    Throwable cause = ex.getCause().getCause();
                    assertThat(cause)
                        .isInstanceOf(javax.jms.JMSException.class)
                        .hasMessage("jms-error");
                });

    }

    @Test
    void adaptToJakarta_returnsOriginalJavaxException_whenMethodDoesNotDeclareJakartaJmsException() {
        JmsNotDeclaring proxy = IBMConnectionFactoryBuilder.adaptToJakarta(
                new JmsThrowingImpl(), JmsNotDeclaring.class);

        
                assertThatThrownBy(proxy::doWork)
                        .isInstanceOf(IBMConnectionFactoryException.class)
                        .hasCauseInstanceOf(InvocationTargetException.class)
                        .satisfies(ex -> {
                            Throwable cause = ex.getCause().getCause();
                            assertThat(cause)
                                .isInstanceOf(javax.jms.JMSException.class);
                        });

    }

    @Test
    void adaptToJakarta_returnsNullResult_whenTargetMethodReturnsNull() {
        NullReturningImpl target = new NullReturningImpl();

        NullReturning proxy = IBMConnectionFactoryBuilder.adaptToJakarta(target, NullReturning.class);

        assertThat(proxy.getValue()).isNull();
    }

    @Test
    void adaptToJakarta_returnsResultAsIs_whenReturnTypeIsNotJakartaJmsInterface() {
        GreeterImpl target = new GreeterImpl();

        Greeter proxy = IBMConnectionFactoryBuilder.adaptToJakarta(target, Greeter.class);

        // String return type — needsWrapping = false (not a jakarta.jms interface)
        assertThat(proxy.greet("X")).isEqualTo("Hello X");
    }

    @Test
    void adaptToJakarta_throwsNoSuchMethodException_whenMethodNotFoundOnTarget() {
        // Interface declares a method that does not exist on the target class
        MissingMethodImpl target = new MissingMethodImpl();

        MissingMethod proxy = IBMConnectionFactoryBuilder.adaptToJakarta(target, MissingMethod.class);

        assertThatThrownBy(proxy::missing)
            .isInstanceOf(IBMConnectionFactoryException.class)
            .hasCauseInstanceOf(NoSuchMethodException.class);

    }

    @Test
    void adaptToJakarta_throwsInvocationTargetException_whenCauseIsNull() {
        // The InvocationHandler catches InvocationTargetException with null cause
        // and rethrows the InvocationTargetException itself (cause != null ? cause :
        // e).
        NullCauseImpl target = new NullCauseImpl();

        NullCauseThrowing proxy = IBMConnectionFactoryBuilder.adaptToJakarta(
                target, NullCauseThrowing.class);

        
        assertThatThrownBy(proxy::act)
                .isInstanceOf(IBMConnectionFactoryException.class)
                .hasCauseInstanceOf(InvocationTargetException.class);

    }

    // needsWrapping — individual branch coverage via a returning proxy that wraps
    // jakarta.jms
    @Test
    void adaptToJakarta_wrapsReturnedObject_whenReturnTypeIsJakartaJmsInterface() {
        // ReturnsJakartaImpl returns a javax.jms impl; the return type on the interface
        // is
        // jakarta.jms.ConnectionFactory — needsWrapping = true.
        ReturnsJakartaInterface proxy = IBMConnectionFactoryBuilder.adaptToJakarta(
                new ReturnsJakartaImpl(), ReturnsJakartaInterface.class);

        // The returned object must itself be a proxy implementing
        // jakarta.jms.ConnectionFactory
        assertThat(proxy.getFactory()).isInstanceOf(jakarta.jms.ConnectionFactory.class);
        assertThat(java.lang.reflect.Proxy.isProxyClass(proxy.getFactory().getClass())).isTrue();
    }

    // -------------------------------------------------------------------------
    // Test helpers — simple interfaces and impls
    // -------------------------------------------------------------------------

    interface Greeter {
        String greet(String name);
    }

    static class GreeterImpl {
        public String greet(String name) {
            return "Hello " + name;
        }
    }

    interface Exploding {
        void boom();
    }

    static class ExplodingImpl {
        public void boom() {
            throw new IllegalStateException("intentional failure");
        }
    }

    /** Declares throws jakarta.jms.JMSException — triggers the wrapping branch. */
    interface JmsDeclaring {
        void doWork() throws jakarta.jms.JMSException;
    }

    /** Does NOT declare a JMS exception — triggers the fallthrough branch. */
    interface JmsNotDeclaring {
        void doWork();
    }

    /** Shared impl: always throws javax.jms.JMSException. */
    static class JmsThrowingImpl {
        public void doWork() throws javax.jms.JMSException {
            throw new javax.jms.JMSException("jms-error", "ERR_001");
        }
    }

    /** Covers the result == null branch in the proxy. */
    interface NullReturning {
        Object getValue();
    }

    static class NullReturningImpl {
        public Object getValue() {
            return null;
        }
    }

    /** Covers the NoSuchMethodException branch in findMethod(). */
    interface MissingMethod {
        void missing();
    }

    static class MissingMethodImpl {
        // no 'missing()' method — findMethod will throw NoSuchMethodException
    }

    /**
     * Covers the cause == null branch: wraps InvocationTargetException with null
     * cause.
     */
    interface NullCauseThrowing {
        void act();
    }

    static class NullCauseImpl {
        public void act() throws Exception {
            
            throw  new InvocationTargetException(null);
        }
    }

    /**
     * Covers needsWrapping = true: return type is jakarta.jms.ConnectionFactory.
     */
    interface ReturnsJakartaInterface {
        jakarta.jms.ConnectionFactory getFactory();
    }

    static class ReturnsJakartaImpl {
        public javax.jms.ConnectionFactory getFactory() {
            // MQQueueConnectionFactory implements javax.jms.ConnectionFactory fully
            return new com.ibm.mq.jms.MQQueueConnectionFactory();
        }
    }
}
