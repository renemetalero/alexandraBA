package sv.ba.messaging.mq.ibm.factory;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class IBMMQClientTest {

    @Mock
    private MessagePublisher publisher;

    @Mock
    private MessageConsumer consumer;

    @Test
    void publisher_returnsDelegatedPublisher() {
        IBMMQClient client = new IBMMQClient(publisher, consumer);

        assertThat(client.publisher()).isSameAs(publisher);
    }

    @Test
    void consumer_returnsDelegatedConsumer() {
        IBMMQClient client = new IBMMQClient(publisher, consumer);

        assertThat(client.consumer()).isSameAs(consumer);
    }

    @Test
    void implementsMQClientInterface() {
        IBMMQClient client = new IBMMQClient(publisher, consumer);

        assertThat(client).isInstanceOf(MQClient.class);
    }
}
