package sv.ba.messaging.mq.ibm.consumer;

import jakarta.jms.BytesMessage;
import jakarta.jms.ConnectionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sv.ba.messaging.mq.exception.DefaultMQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.serialization.SerializationException;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Tests unitarios para IBMMessageConsumer.
 *
 * Nota de diseño: IBMMessageConsumer instancia directamente DefaultMessageListenerContainer,
 * lo que limita la testeabilidad del flujo completo sin un broker real. La lógica del
 * listener interno se testea a través de InternalMessageHandler, que replica exactamente
 * el lambda de producción. El flujo end-to-end debe cubrirse con tests de integración.
 */
@ExtendWith(MockitoExtension.class)
class IBMMessageConsumerTest {

    @Mock
    private MessageSerializer serializer;

    private IBMMessageConsumer consumer;

    @BeforeEach
    void setUp() {
        consumer = new IBMMessageConsumer(mock(ConnectionFactory.class), serializer, new DefaultMQErrorResolver());
    }

    @Test
    void subscribe_completesWithoutException_withValidConnectionFactory() {
        assertThatNoException().isThrownBy(() ->
                consumer.subscribe("TEST.QUEUE", msg -> {}));
    }

    @Test
    void subscribe_wrapsMQException_whenContainerThrowsDuringSetup() {
        IBMMessageConsumer failingConsumer = new IBMMessageConsumer(
                mock(ConnectionFactory.class), serializer, new DefaultMQErrorResolver()) {
            @Override
            protected org.springframework.jms.listener.DefaultMessageListenerContainer
                    createContainer(String queue, java.util.function.Consumer<Message> handler) {
                throw new RuntimeException("container setup failed");
            }
        };

        assertThatThrownBy(() -> failingConsumer.subscribe("TEST.QUEUE", msg -> {}))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al registrar la suscripción en el broker")
                .cause()
                .hasMessage("container setup failed");
    }

    // -------------------------------------------------------------------------
    // Tests del MessageListener interno via InternalMessageHandler
    // -------------------------------------------------------------------------

    @Test
    void messageHandler_invokesConsumerHandler_withDeserializedPayload() throws Exception {
        byte[] rawBody = new byte[]{10, 20, 30};
        Object deserialized = new Object();
        when(serializer.deserialize(rawBody, Object.class)).thenReturn(deserialized);

        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Message> received = new AtomicReference<>();

        jakarta.jms.MessageListener listener = extractListener(msg -> {
            received.set(msg);
            latch.countDown();
        });

        listener.onMessage(buildBytesMessage(rawBody));

        assertThat(latch.await(1, TimeUnit.SECONDS)).isTrue();
        assertThat(received.get().getPayload()).isSameAs(deserialized);
    }

    @Test
    void messageHandler_throwsMQException_whenDeserializationFails() throws Exception {
        byte[] rawBody = new byte[]{1, 2, 3};
        when(serializer.deserialize(any(), any()))
                .thenThrow(new SerializationException("parse error", new RuntimeException()));

        jakarta.jms.MessageListener listener = extractListener(msg -> {});
        BytesMessage message = buildBytesMessage(rawBody);

        assertThatThrownBy(() -> listener.onMessage(message))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al procesar mensaje entrante");
    }

    @Test
    void messageHandler_builtMessage_hasNonNullMetadataAndId() throws Exception {
        when(serializer.deserialize(any(), any())).thenReturn("hello");

        AtomicReference<Message> received = new AtomicReference<>();
        jakarta.jms.MessageListener listener = extractListener(received::set);
        BytesMessage message = buildBytesMessage("\"hello\"".getBytes());

        listener.onMessage(message);

        assertThat(received.get().getId()).isNotBlank();
        assertThat(received.get().getMetadata().getSource()).isEqualTo("unknown");
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Extrae el MessageListener registrado por createContainer(), permitiendo
     * invocar directamente el código de producción del lambda sin un broker real.
     */
    private jakarta.jms.MessageListener extractListener(Consumer<Message> handler) {
        org.springframework.jms.listener.DefaultMessageListenerContainer container =
                consumer.createContainer("TEST.QUEUE", handler);
        return (jakarta.jms.MessageListener) container.getMessageListener();
    }

    private BytesMessage buildBytesMessage(byte[] body) throws Exception {
        BytesMessage msg = mock(BytesMessage.class);
        when(msg.getBodyLength()).thenReturn((long) body.length);
        when(msg.readBytes(any(byte[].class))).thenAnswer(inv -> {
            byte[] dest = inv.getArgument(0);
            System.arraycopy(body, 0, dest, 0, body.length);
            return body.length;
        });
        return msg;
    }
}
