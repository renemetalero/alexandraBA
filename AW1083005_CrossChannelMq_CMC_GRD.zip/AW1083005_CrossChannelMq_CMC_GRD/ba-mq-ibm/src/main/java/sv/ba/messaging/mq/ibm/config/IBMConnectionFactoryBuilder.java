package sv.ba.messaging.mq.ibm.config;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import jakarta.jms.ConnectionFactory;

import java.lang.reflect.Proxy;

import static com.ibm.msg.client.wmq.common.CommonConstants.WMQ_CM_CLIENT;
import static com.ibm.msg.client.jms.JmsConstants.USERID;
import static com.ibm.msg.client.jms.JmsConstants.PASSWORD;

/**
 * Factory que construye y configura una {@link ConnectionFactory} de Jakarta
 * JMS
 * respaldada por IBM MQ.
 * <p>
 * IBM MQ allclient implementa {@code javax.jms} (JMS 2.0), mientras que
 * Spring Boot 3.x y {@code spring-jms} requieren {@code jakarta.jms} (JMS 3.x).
 * Dado que ambas interfaces son estructuralmente idénticas —solo difieren en el
 * nombre del paquete—, este factory adapta el {@code MQQueueConnectionFactory}
 * mediante un {@link Proxy} dinámico que reenvía todas las llamadas por nombre
 * de método, evitando así la incompatibilidad de tipos en tiempo de
 * compilación.
 * </p>
 *
 * <p>
 * Este builder es de uso interno del módulo {@code ba-mq-ibm}.
 * </p>
 */
public final class IBMConnectionFactoryBuilder {

    private IBMConnectionFactoryBuilder() {
    }

    /**
     * Crea y configura una {@link ConnectionFactory} de Jakarta JMS
     * respaldada por IBM MQ.
     *
     * @param host         hostname del servidor IBM MQ
     * @param port         puerto del servidor IBM MQ
     * @param channel      canal de conexión (SVRCONN)
     * @param queueManager nombre del Queue Manager
     * @param username     usuario de autenticación (puede ser {@code null})
     * @param password     contraseña de autenticación (puede ser {@code null})
     * @return {@link ConnectionFactory} Jakarta JMS configurada para IBM MQ
     * @throws IBMConnectionFactoryException si la configuración del factory falla
     */
    public static ConnectionFactory build(
            String host,
            int port,
            String channel,
            String queueManager,
            String username,
            String password) throws IBMConnectionFactoryException {

        try {
            MQQueueConnectionFactory mqFactory = new MQQueueConnectionFactory();
            mqFactory.setHostName(host);
            mqFactory.setPort(port);
            mqFactory.setChannel(channel);
            mqFactory.setQueueManager(queueManager);
            mqFactory.setTransportType(WMQ_CM_CLIENT);

            if (username != null && !username.isBlank()) {
                mqFactory.setStringProperty(USERID, username);
                mqFactory.setStringProperty(PASSWORD, password);
            }

            return adaptToJakarta(mqFactory, ConnectionFactory.class);
        } catch (IBMConnectionFactoryException e) {
            throw e;
        } catch (Exception e) {
            throw new IBMConnectionFactoryException(
                    "Failed to configure IBM MQ ConnectionFactory: " + e.getMessage(), e);
        }
    }

    /**
     * Crea un proxy dinámico que adapta un objeto {@code javax.jms.*} al tipo
     * {@code jakarta.jms.*} equivalente. Ambas especificaciones comparten nombres
     * y firmas de métodos idénticos —solo difieren en el prefijo del paquete—,
     * por lo que el reenvío por nombre de método es seguro.
     *
     * @param <T>          tipo de la interfaz Jakarta JMS de destino
     * @param target       instancia del objeto javax.jms a adaptar
     * @param jakartaIface interfaz Jakarta JMS que debe implementar el proxy
     * @return proxy dinámico que implementa {@code jakartaIface}
     * @throws IBMConnectionFactoryException si la adaptación falla
     */
    @SuppressWarnings("unchecked")
    static <T> T adaptToJakarta(Object target, Class<T> jakartaIface) throws IBMConnectionFactoryException {
        return (T) Proxy.newProxyInstance(
                jakartaIface.getClassLoader(),
                new Class<?>[] { jakartaIface },
                (proxy, method, args) -> handleProxyInvocation(target, method, args));
    }

    /**
     * Maneja la invocación de un método en el proxy dinámico.
     * Extrae la lógica del handler para reducir la complejidad cognitiva.
     */
    private static Object handleProxyInvocation(Object target, java.lang.reflect.Method method, Object[] args)
            throws IBMConnectionFactoryException {
        try {
            // Find a method with the same name and parameter count on the target.
            // For JMS adapting, parameter types are also structurally identical
            // (same names, different package prefix).
            java.lang.reflect.Method targetMethod = findMethod(
                    target.getClass(), method.getName(), method.getParameterTypes().length);

            Object result = targetMethod.invoke(target, args);
            // Wrap returned javax.jms objects into jakarta.jms proxies recursively
            if (result != null && needsWrapping(result.getClass(), method.getReturnType())) {
                return adaptToJakarta(result, method.getReturnType());
            }
            return result;
        } 
        catch (IBMConnectionFactoryException e) {
            // Both are rethrown as-is: NoSuchMethodException becomes
            // UndeclaredThrowableException,
            // IBMConnectionFactoryException is already the desired exception type
            throw e;
        } catch (ReflectiveOperationException e) {
            throw new IBMConnectionFactoryException(
                    "Failed to adapt javax.jms to jakarta.jms: " + e.getMessage(), e);
        }

    }

    private static java.lang.reflect.Method findMethod(
            Class<?> clazz, String name, int paramCount) throws NoSuchMethodException {
        for (java.lang.reflect.Method m : clazz.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == paramCount) {
                return m;
            }
        }
        throw new NoSuchMethodException(clazz.getName() + "." + name + " (paramCount=" + paramCount + ")");
    }

    private static boolean needsWrapping(Class<?> resultClass, Class<?> returnType) {
        return returnType.isInterface()
                && returnType.getPackageName().startsWith("jakarta.jms")
                && !resultClass.getPackageName().startsWith("jakarta.jms");
    }

    
}
