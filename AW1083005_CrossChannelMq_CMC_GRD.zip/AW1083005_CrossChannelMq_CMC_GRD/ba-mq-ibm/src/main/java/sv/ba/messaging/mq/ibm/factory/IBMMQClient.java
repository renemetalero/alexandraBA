package sv.ba.messaging.mq.ibm.factory;

import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;

/**
 * Implementación IBM MQ de {@link MQClient}.
 * <p>
 * Actúa como <b>Facade</b> que agrupa un {@link MessagePublisher} y un
 * {@link MessageConsumer} respaldados por IBM MQ, exponiéndolos a través
 * de un único punto de entrada.
 * </p>
 */
public class IBMMQClient implements MQClient {

    private final MessagePublisher publisher;
    private final MessageConsumer consumer;

    /**
     * Construye un nuevo {@code IBMMQClient} con el publisher y consumer indicados.
     *
     * @param publisher instancia de {@link MessagePublisher} respaldada por IBM MQ; no debe ser {@code null}
     * @param consumer  instancia de {@link MessageConsumer} respaldada por IBM MQ; no debe ser {@code null}
     */
    public IBMMQClient(MessagePublisher publisher, MessageConsumer consumer) {
        this.publisher = publisher;
        this.consumer = consumer;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public MessagePublisher publisher() {
        return publisher;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public MessageConsumer consumer() {
        return consumer;
    }
}
