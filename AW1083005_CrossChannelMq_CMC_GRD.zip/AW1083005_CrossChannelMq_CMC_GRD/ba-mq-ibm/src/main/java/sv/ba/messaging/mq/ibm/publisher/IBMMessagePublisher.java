package sv.ba.messaging.mq.ibm.publisher;

import jakarta.jms.Session;
import org.springframework.jms.core.JmsTemplate;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.MQErrorCodes;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.serialization.MessageSerializer;

/**
 * Implementación IBM MQ de {@link MessagePublisher}.
 * <p>
 * Serializa el payload del mensaje usando el {@link MessageSerializer} configurado
 * y lo envía a la queue destino mediante {@link JmsTemplate}.
 * Aplica el patrón <b>Adapter</b>: adapta la API de Spring JMS al contrato
 * genérico {@link MessagePublisher} de {@code ba-mq-core}.
 * </p>
 */
public class IBMMessagePublisher implements MessagePublisher {

    private final JmsTemplate jmsTemplate;
    private final MessageSerializer serializer;
    private final MQErrorResolver errorResolver;

    /**
     * Construye un nuevo publicador IBM MQ.
     *
     * @param jmsTemplate   cliente JMS de Spring; no debe ser {@code null}
     * @param serializer    estrategia de serialización del payload; no debe ser {@code null}
     * @param errorResolver resolvedor de mensajes del catálogo de errores; no debe ser {@code null}
     */
    public IBMMessagePublisher(JmsTemplate jmsTemplate, MessageSerializer serializer, MQErrorResolver errorResolver) {
        this.jmsTemplate = jmsTemplate;
        this.serializer = serializer;
        this.errorResolver = errorResolver;
    }

    /**
     * Serializa el payload del {@link Message} y lo envía a la queue indicada.
     *
     * @param topic   nombre de la queue IBM MQ de destino; no debe ser {@code null}
     * @param message mensaje a publicar; no debe ser {@code null}
     * @throws MQException si ocurre un error durante la serialización o el envío
     */
    @Override
    public void publish(String topic, Message message) {
        try {
            byte[] body = serializer.serialize(message.getPayload());
            jmsTemplate.send(topic, (Session session) -> {
                jakarta.jms.BytesMessage msg = session.createBytesMessage();
                msg.writeBytes(body);
                return msg;
            });
        } catch (Exception e) {
            throw MQException.of(MQErrorCodes.PUBLISH_FAILED, e, errorResolver);
        }
    }
}
