package sv.ba.messaging.mq.ibm.config;

/**
 * Excepción lanzada cuando la configuración o construcción de una
 * {@link jakarta.jms.ConnectionFactory} respaldada por IBM MQ falla.
 *
 * <p>Esta excepción envuelve las causas raíz (como excepciones de
 * configuración de IBM MQ o problemas de reflection) con un tipo
 * dedicado y significativo.</p>
 */
public class IBMConnectionFactoryException extends RuntimeException {

    public IBMConnectionFactoryException(String message) {
        super(message);
    }

    public IBMConnectionFactoryException(String message, Throwable cause) {
        super(message, cause);
    }

    public IBMConnectionFactoryException(Throwable cause) {
        super(cause);
    }
}
