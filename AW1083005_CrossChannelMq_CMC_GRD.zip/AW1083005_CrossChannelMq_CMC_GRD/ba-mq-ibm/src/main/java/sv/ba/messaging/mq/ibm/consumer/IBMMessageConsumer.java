package sv.ba.messaging.mq.ibm.consumer;

import jakarta.jms.BytesMessage;
import jakarta.jms.ConnectionFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.exception.MQErrorCodes;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.serialization.MessageSerializer;

import java.util.function.Consumer;

/**
 * Implementación IBM MQ de {@link MessageConsumer}.
 * <p>
 * Crea un {@link DefaultMessageListenerContainer} por cada suscripción, que
 * escucha la queue indicada y deserializa cada {@link BytesMessage} entrante
 * antes de delegarlo al handler.
 * Aplica el patrón <b>Adapter</b>: adapta el modelo listener de Spring JMS
 * al contrato genérico {@link MessageConsumer} de {@code ba-mq-core}.
 * </p>
 */
public class IBMMessageConsumer implements MessageConsumer {

    private final ConnectionFactory connectionFactory;
    private final MessageSerializer serializer;
    private final MQErrorResolver errorResolver;

    /**
     * Construye un nuevo consumidor IBM MQ.
     *
     * @param connectionFactory fábrica de conexiones JMS de IBM MQ; no debe ser {@code null}
     * @param serializer        estrategia de deserialización del payload; no debe ser {@code null}
     * @param errorResolver     resolvedor de mensajes del catálogo de errores; no debe ser {@code null}
     */
    public IBMMessageConsumer(ConnectionFactory connectionFactory, MessageSerializer serializer, MQErrorResolver errorResolver) {
        this.connectionFactory = connectionFactory;
        this.serializer = serializer;
        this.errorResolver = errorResolver;
    }

    /**
     * Se suscribe a la queue indicada y procesa cada mensaje con el handler proporcionado.
     * <p>
     * Internamente levanta un {@link DefaultMessageListenerContainer} que queda activo
     * en segundo plano. Cada {@link BytesMessage} recibido es deserializado y envuelto
     * en un {@link Message} antes de ser entregado al handler.
     * </p>
     *
     * @param queue   nombre de la queue IBM MQ a escuchar; no debe ser {@code null}
     * @param handler función que procesa cada {@link Message} entrante; no debe ser {@code null}
     * @throws MQException si ocurre un error al registrar el listener o al procesar un mensaje
     */
    @Override
    public void subscribe(String queue, Consumer<Message> handler) {
        try {
            DefaultMessageListenerContainer container = createContainer(queue, handler);
            container.initialize();
            container.start();
        } catch (Exception e) {
            throw MQException.of(MQErrorCodes.SUBSCRIBE_FAILED, e, errorResolver);
        }
    }

    /**
     * Crea y configura el {@link DefaultMessageListenerContainer} para la queue dada.
     * Extraído como método protegido para permitir sobreescritura en tests unitarios.
     */
    protected DefaultMessageListenerContainer createContainer(String queue, Consumer<Message> handler) {
        DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setDestinationName(queue);
        container.setMessageListener((jakarta.jms.MessageListener) jmsMessage -> {
            try {
                BytesMessage bytesMessage = (BytesMessage) jmsMessage;
                byte[] body = new byte[(int) bytesMessage.getBodyLength()];
                bytesMessage.readBytes(body);
                Object payload = serializer.deserialize(body, Object.class);
                handler.accept(Message.builder().payload(payload).build());
            } catch (Exception e) {
                throw MQException.of(MQErrorCodes.MESSAGE_PROCESSING, e, errorResolver);
            }
        });
        return container;
    }
}
