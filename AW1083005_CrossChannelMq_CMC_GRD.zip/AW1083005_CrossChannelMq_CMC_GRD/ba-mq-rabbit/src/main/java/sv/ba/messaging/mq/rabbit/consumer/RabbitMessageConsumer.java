package sv.ba.messaging.mq.rabbit.consumer;

import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.exception.MQErrorCodes;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.serialization.MessageSerializer;

import java.util.function.Consumer;

/**
 * Implementación RabbitMQ de {@link MessageConsumer}.
 * <p>
 * Crea un {@link SimpleMessageListenerContainer} por cada suscripción, que
 * escucha la queue indicada y deserializa cada mensaje entrante usando el
 * {@link MessageSerializer} configurado antes de delegarlo al handler.
 * Aplica el patrón <b>Adapter</b>: adapta el modelo listener de Spring AMQP
 * al contrato genérico {@link MessageConsumer} de {@code ba-mq-core}.
 * </p>
 */
public class RabbitMessageConsumer implements MessageConsumer {

    private final ConnectionFactory connectionFactory;
    private final MessageSerializer serializer;
    private final MQErrorResolver errorResolver;

    /**
     * Construye un nuevo consumidor RabbitMQ.
     *
     * @param connectionFactory fábrica de conexiones AMQP; no debe ser {@code null}
     * @param serializer        estrategia de deserialización del payload; no debe ser {@code null}
     * @param errorResolver     resolvedor de mensajes del catálogo de errores; no debe ser {@code null}
     */
    public RabbitMessageConsumer(
            ConnectionFactory connectionFactory,
            MessageSerializer serializer,
            MQErrorResolver errorResolver) {

        this.connectionFactory = connectionFactory;
        this.serializer = serializer;
        this.errorResolver = errorResolver;
    }

    /**
     * Crea el contenedor AMQP para la suscripción.
     * <p>
     * Método protegido para permitir su sustitución en tests unitarios.
     * </p>
    *
    * @return nuevo {@link SimpleMessageListenerContainer} sin inicializar
    */
   protected SimpleMessageListenerContainer createContainer() {
       return new SimpleMessageListenerContainer(connectionFactory);
    }
    
    /**
     * Se suscribe a la queue indicada y procesa cada mensaje con el handler proporcionado.
     * <p>
     * Internamente levanta un {@link SimpleMessageListenerContainer} que queda activo
     * en segundo plano. Cada mensaje recibido es deserializado y envuelto en un
     * {@link Message} antes de ser entregado al handler.
     * </p>
     *
     * @param queue   nombre de la queue RabbitMQ a escuchar; no debe ser {@code null}
     * @param handler función que procesa cada {@link Message} entrante; no debe ser {@code null}
     * @throws MQException si ocurre un error al registrar el listener o al procesar un mensaje
     */
    @Override
    public void subscribe(String queue, Consumer<Message> handler) {
        try {
            SimpleMessageListenerContainer container = createContainer();

            container.setQueueNames(queue);

            container.setMessageListener(message -> {
                try {
                    Object payload = serializer.deserialize(message.getBody(), Object.class);
                    handler.accept(
                        Message.builder()
                               .payload(payload)
                               .build()
                    );
                } catch (Exception e) {
                    throw MQException.of(MQErrorCodes.MESSAGE_PROCESSING, e, errorResolver);
                }
            });

            container.start();

        } catch (Exception e) {
            throw MQException.of(MQErrorCodes.SUBSCRIBE_FAILED, e, errorResolver);
        }
    }
}
