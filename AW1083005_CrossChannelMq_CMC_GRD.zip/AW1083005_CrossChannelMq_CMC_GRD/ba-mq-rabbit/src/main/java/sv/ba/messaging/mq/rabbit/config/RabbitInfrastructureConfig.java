package sv.ba.messaging.mq.rabbit.config;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.DefaultMQErrorResolver;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.rabbit.consumer.RabbitMessageConsumer;
import sv.ba.messaging.mq.rabbit.publisher.RabbitMessagePublisher;
import sv.ba.messaging.mq.rabbit.serialization.JacksonMessageSerializer;
import sv.ba.messaging.mq.serialization.MessageSerializer;

/**
 * Configuración Spring de la infraestructura RabbitMQ del módulo {@code ba-mq-rabbit}.
 * <p>
 * Declara los beans necesarios para el funcionamiento interno del módulo:
 * {@link sv.ba.messaging.mq.serialization.MessageSerializer},
 * {@link sv.ba.messaging.mq.api.MessagePublisher} y
 * {@link sv.ba.messaging.mq.api.MessageConsumer}.
 * </p>
 * <p>
 * Esta configuración es de uso interno. Para proyectos Spring Boot se recomienda
 * usar el módulo {@code ba-mq-spring-boot-starter}, que provee auto-configuración
 * con beans condicionales y soporte de properties externas.
 * </p>
 */
@Configuration
public class RabbitInfrastructureConfig {

    /**
     * Registra el {@link MessageSerializer} basado en Jackson.
     *
     * @param objectMapper instancia de Jackson proporcionada por Spring
     * @return serializador JSON
     */
    @Bean
    MessageSerializer messageSerializer(ObjectMapper objectMapper) {
        return new JacksonMessageSerializer(objectMapper);
    }

    @Bean
    MQErrorResolver mqErrorResolver() {
        return new DefaultMQErrorResolver();
    }

    /**
     * Registra el {@link MessagePublisher} respaldado por RabbitMQ.
     *
     * @param rabbitTemplate cliente AMQP de Spring
     * @param serializer     serializador de payloads
     * @return publisher RabbitMQ
     */
    @Bean
    MessagePublisher rabbitMessagePublisher(
            RabbitTemplate rabbitTemplate,
            MessageSerializer serializer,
            MQErrorResolver mqErrorResolver) {

        return new RabbitMessagePublisher(rabbitTemplate, serializer, mqErrorResolver);
    }

    /**
     * Registra el {@link MessageConsumer} respaldado por RabbitMQ.
     *
     * @param connectionFactory fábrica de conexiones AMQP de Spring
     * @param serializer        serializador de payloads
     * @return consumer RabbitMQ
     */
    @Bean
    MessageConsumer rabbitMessageConsumer(
            ConnectionFactory connectionFactory,
            MessageSerializer serializer,
            MQErrorResolver mqErrorResolver) {

        return new RabbitMessageConsumer(connectionFactory, serializer, mqErrorResolver);
    }
}

