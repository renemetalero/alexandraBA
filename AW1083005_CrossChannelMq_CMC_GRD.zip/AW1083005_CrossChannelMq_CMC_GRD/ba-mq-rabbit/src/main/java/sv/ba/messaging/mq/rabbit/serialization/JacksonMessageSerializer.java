package sv.ba.messaging.mq.rabbit.serialization;

import com.fasterxml.jackson.databind.ObjectMapper;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.serialization.SerializationException;

/**
 * Implementación de {@link MessageSerializer} basada en Jackson.
 * <p>
 * Aplica el patrón <b>Strategy</b>: implementa el contrato de serialización
 * usando {@link ObjectMapper} para convertir objetos a JSON (bytes) y viceversa.
 * Puede ser reemplazada por otras estrategias (Avro, Protobuf) sin modificar
 * el código cliente.
 * </p>
 */
public class JacksonMessageSerializer implements MessageSerializer {

    private final ObjectMapper objectMapper;

    /**
     * Construye un nuevo serializador Jackson.
     *
     * @param objectMapper instancia de Jackson {@link ObjectMapper} a utilizar; no debe ser {@code null}
     */
    public JacksonMessageSerializer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * Serializa el payload a JSON en formato de arreglo de bytes.
     *
     * @param payload objeto a serializar; no debe ser {@code null}
     * @return bytes JSON del objeto
     * @throws SerializationException si Jackson no puede serializar el objeto
     */
    @Override
    public byte[] serialize(Object payload) {
        try {
            return objectMapper.writeValueAsBytes(payload);
        } catch (Exception e) {
            throw new SerializationException("Error serializando payload", e);
        }
    }

    /**
     * Deserializa un arreglo de bytes JSON al tipo destino indicado.
     *
     * @param <T>        tipo del objeto resultante
     * @param data       bytes JSON a deserializar; no debe ser {@code null}
     * @param targetType clase del tipo destino; no debe ser {@code null}
     * @return instancia del tipo {@code T} reconstruida desde el JSON
     * @throws SerializationException si Jackson no puede deserializar los bytes al tipo indicado
     */
    @Override
    public <T> T deserialize(byte[] data, Class<T> targetType) {
        try {
            return objectMapper.readValue(data, targetType);
        } catch (Exception e) {
            throw new SerializationException("Error deserializando payload", e);
        }
    }
}

