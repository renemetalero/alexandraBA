package sv.ba.messaging.mq.rabbit.publisher;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.MQErrorCodes;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.serialization.MessageSerializer;

/**
 * Implementación RabbitMQ de {@link MessagePublisher}.
 * <p>
 * Serializa el payload del mensaje usando el {@link MessageSerializer} configurado
 * y lo envía al exchange o queue indicado mediante {@link RabbitTemplate}.
 * Aplica el patrón <b>Adapter</b>: adapta la API de Spring AMQP al contrato
 * genérico {@link MessagePublisher} de {@code ba-mq-core}.
 * </p>
 */
public class RabbitMessagePublisher implements MessagePublisher {

    private final RabbitTemplate rabbitTemplate;
    private final MessageSerializer serializer;
    private final MQErrorResolver errorResolver;

    /**
     * Construye un nuevo publicador RabbitMQ.
     *
     * @param rabbitTemplate  cliente Spring AMQP para enviar mensajes; no debe ser {@code null}
     * @param serializer      estrategia de serialización del payload; no debe ser {@code null}
     * @param errorResolver   resolvedor de mensajes del catálogo de errores; no debe ser {@code null}
     */
    public RabbitMessagePublisher(
            RabbitTemplate rabbitTemplate,
            MessageSerializer serializer,
            MQErrorResolver errorResolver) {

        this.rabbitTemplate = rabbitTemplate;
        this.serializer = serializer;
        this.errorResolver = errorResolver;
    }

    /**
     * Serializa el payload del {@link Message} y lo envía al exchange o queue indicado.
     *
     * @param topic   nombre del exchange o queue de destino en RabbitMQ; no debe ser {@code null}
     * @param message mensaje a publicar; no debe ser {@code null}
     * @throws MQException si ocurre un error durante la serialización o el envío
     */
    @Override
    public void publish(String topic, Message message) {
        try {
            byte[] body = serializer.serialize(message.getPayload());
            rabbitTemplate.convertAndSend(topic, body);
        } catch (Exception e) {
            throw MQException.of(MQErrorCodes.PUBLISH_FAILED, e, errorResolver);
        }
    }
}
