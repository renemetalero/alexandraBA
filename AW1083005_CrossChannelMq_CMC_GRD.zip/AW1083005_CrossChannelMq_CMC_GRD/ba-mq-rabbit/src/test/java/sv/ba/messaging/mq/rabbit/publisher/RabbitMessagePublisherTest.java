package sv.ba.messaging.mq.rabbit.publisher;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import sv.ba.messaging.mq.exception.DefaultMQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.serialization.SerializationException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RabbitMessagePublisherTest {

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private MessageSerializer serializer;

    private RabbitMessagePublisher publisher;

    @BeforeEach
    void setUp() {
        publisher = new RabbitMessagePublisher(rabbitTemplate, serializer, new DefaultMQErrorResolver());
    }

    @Test
    void publish_serializesPayloadAndSendsToTopic() {
        Message message = Message.builder().payload("order-created").build();
        byte[] expectedBytes = "\"order-created\"".getBytes();
        when(serializer.serialize("order-created")).thenReturn(expectedBytes);

        publisher.publish("orders.created", message);

        verify(serializer).serialize("order-created");
        verify(rabbitTemplate).convertAndSend("orders.created",expectedBytes);
    }

    @Test
    void publish_sendsExactSerializedBytesToBroker() {
        byte[] serializedBody = new byte[]{10, 20, 30, 40};
        Message message = Message.builder().payload("any-payload").build();
        when(serializer.serialize(any())).thenReturn(serializedBody);

        publisher.publish("payments.processed", message);

        ArgumentCaptor<Object> bodyCaptor = ArgumentCaptor.forClass(Object.class);
        verify(rabbitTemplate).convertAndSend(eq("payments.processed"), bodyCaptor.capture());
        assertThat((byte[]) bodyCaptor.getValue()).isEqualTo(serializedBody);
    }

    @Test
    void publish_throwsMQException_whenSerializerFails() {
        Message message = Message.builder().payload("bad-payload").build();
        when(serializer.serialize(any()))
                .thenThrow(new SerializationException("jackson error", new RuntimeException()));

        assertThatThrownBy(() -> publisher.publish("orders.created", message))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al publicar mensaje en el broker");
    }

    @Test
    void publish_throwsMQException_whenBrokerSendFails() {
        Message message = Message.builder().payload("payload").build();
        when(serializer.serialize(any())).thenReturn(new byte[]{1, 2, 3});
        doThrow(new RuntimeException("broker unreachable"))
                .when(rabbitTemplate).convertAndSend(any(String.class), any(Object.class));

        assertThatThrownBy(() -> publisher.publish("orders.created", message))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al publicar mensaje en el broker")
                .hasCauseInstanceOf(RuntimeException.class);
    }

    @Test
    void publish_wrapsOriginalCause_inMQException() {
        RuntimeException originalCause = new RuntimeException("network timeout");
        Message message = Message.builder().payload("x").build();
        when(serializer.serialize(any())).thenReturn(new byte[0]);
        doThrow(originalCause)
                .when(rabbitTemplate).convertAndSend(any(String.class), any(Object.class));

        assertThatThrownBy(() -> publisher.publish("topic", message))
                .isInstanceOf(MQException.class)
                .cause()
                .isSameAs(originalCause);
    }
}
