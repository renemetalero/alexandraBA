package sv.ba.messaging.mq.rabbit.serialization;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sv.ba.messaging.mq.serialization.SerializationException;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JacksonMessageSerializerTest {

    private JacksonMessageSerializer serializer;

    @Mock
    private ObjectMapper mockObjectMapper;

    @BeforeEach
    void setUp() {
        serializer = new JacksonMessageSerializer(new ObjectMapper());
    }

    @Test
    void serializeReturnsNonEmptyBytesForStringPayload() {
        byte[] result = serializer.serialize("hello world");

        assertThat(result).isNotEmpty();
        assertThat(new String(result)).contains("hello world");
    }

    @Test
    void serializeReturnsValidJsonForComplexPayload() {
        Map<String, Object> payload = Map.of("orderId", 42, "status", "CREATED");

        byte[] result = serializer.serialize(payload);

        assertThat(new String(result))
                .contains("orderId")
                .contains("CREATED");
    }

    @Test
    void serializeThrowsSerializationExceptionOnObjectMapperFailure() throws Exception {
        JacksonMessageSerializer failingSerializer = new JacksonMessageSerializer(mockObjectMapper);
        when(mockObjectMapper.writeValueAsBytes(any()))
                .thenThrow(new JsonMappingException(null, "forced failure"));

        assertThatThrownBy(() -> failingSerializer.serialize("payload"))
                .isInstanceOf(SerializationException.class)
                .hasMessageContaining("Error serializando payload");
    }

    @Test
    void deserializeReturnsTypedObjectForValidJson() {
        byte[] json = "{\"name\":\"test\",\"active\":true}".getBytes();

        @SuppressWarnings("unchecked")
        Map<String, Object> result = serializer.deserialize(json, Map.class);

        assertThat(result)
                .containsEntry("name", "test")
                .containsEntry("active", true);
    }

    @Test
    void deserializeThrowsSerializationExceptionForMalformedJson() {
        byte[] malformed = "{ invalid json".getBytes();

        assertThatThrownBy(() -> serializer.deserialize(malformed, Object.class))
                .isInstanceOf(SerializationException.class)
                .hasMessageContaining("Error deserializando payload");
    }

    @Test
    void deserializeThrowsSerializationExceptionOnObjectMapperFailure() throws Exception {
        JacksonMessageSerializer failingSerializer = new JacksonMessageSerializer(mockObjectMapper);
        when(mockObjectMapper.readValue(any(byte[].class), eq(Object.class)))
                .thenThrow(new JsonProcessingException("forced failure") {});

        assertThatThrownBy(() -> failingSerializer.deserialize(new byte[0], Object.class))
                .isInstanceOf(SerializationException.class)
                .hasMessageContaining("Error deserializando payload");
    }

    @Test
    void serializeThenDeserializeRoundTrip() {
        record Order(String id, double amount) {}
        ObjectMapper objectMapper = new ObjectMapper();
        JacksonMessageSerializer roundTripSerializer = new JacksonMessageSerializer(objectMapper);
        Order original = new Order("ord-001", 99.99);

        byte[] bytes = roundTripSerializer.serialize(original);
        @SuppressWarnings("unchecked")
        Map<String, Object> restored = roundTripSerializer.deserialize(bytes, Map.class);

        assertThat(restored)
                .containsEntry("id", "ord-001")
                .containsEntry("amount", 99.99);
    }
}
