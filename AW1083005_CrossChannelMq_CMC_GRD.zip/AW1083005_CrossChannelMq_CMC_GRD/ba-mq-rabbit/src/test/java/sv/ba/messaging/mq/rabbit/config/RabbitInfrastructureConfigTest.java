package sv.ba.messaging.mq.rabbit.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;
import sv.ba.messaging.mq.exception.MQErrorResolver;
import sv.ba.messaging.mq.rabbit.consumer.RabbitMessageConsumer;
import sv.ba.messaging.mq.rabbit.publisher.RabbitMessagePublisher;
import sv.ba.messaging.mq.rabbit.serialization.JacksonMessageSerializer;
import sv.ba.messaging.mq.serialization.MessageSerializer;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests unitarios para RabbitInfrastructureConfig.
 *
 * Estrategia: se instancia la clase de configuración directamente (sin contexto Spring)
 * y se llama a cada método @Bean con dependencias mockeadas. Así se verifica que
 * el cableado (wiring) produce beans del tipo correcto sin arrancar ningún ApplicationContext.
 */
@ExtendWith(MockitoExtension.class)
class RabbitInfrastructureConfigTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private ConnectionFactory connectionFactory;

    @Mock
    private MessageSerializer messageSerializer;

    @Mock
    private MQErrorResolver errorResolver;

    private RabbitInfrastructureConfig config;

    @BeforeEach
    void setUp() {
        config = new RabbitInfrastructureConfig();
    }

    @Test
    void messageSerializerReturnsJacksonMessageSerializer() {
        MessageSerializer serializer = config.messageSerializer(objectMapper);

        assertThat(serializer).isInstanceOf(JacksonMessageSerializer.class);
    }

    @Test
    void messageSerializerIsNotNull() {
        MessageSerializer serializer = config.messageSerializer(objectMapper);

        assertThat(serializer).isNotNull();
    }

    @Test
    void rabbitMessagePublisherReturnsRabbitMessagePublisher() {
        MessagePublisher publisher = config.rabbitMessagePublisher(rabbitTemplate, messageSerializer, errorResolver);

        assertThat(publisher).isInstanceOf(RabbitMessagePublisher.class);
    }

    @Test
    void rabbitMessagePublisherImplementsMessagePublisherInterface() {
        MessagePublisher publisher = config.rabbitMessagePublisher(rabbitTemplate, messageSerializer, errorResolver);

        assertThat(publisher).isInstanceOf(MessagePublisher.class);
    }

    @Test
    void rabbitMessageConsumerReturnsRabbitMessageConsumer() {
        MessageConsumer consumer = config.rabbitMessageConsumer(connectionFactory, messageSerializer, errorResolver);

        assertThat(consumer).isInstanceOf(RabbitMessageConsumer.class);
    }

    @Test
    void rabbitMessageConsumerImplementsMessageConsumerInterface() {
        MessageConsumer consumer = config.rabbitMessageConsumer(connectionFactory, messageSerializer, errorResolver);

        assertThat(consumer).isInstanceOf(MessageConsumer.class);
    }
}
