package sv.ba.messaging.mq.rabbit.consumer;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.ArgumentCaptor;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import sv.ba.messaging.mq.exception.DefaultMQErrorResolver;
import sv.ba.messaging.mq.exception.MQException;
import sv.ba.messaging.mq.serialization.MessageSerializer;
import sv.ba.messaging.mq.serialization.SerializationException;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Tests unitarios para RabbitMessageConsumer.
 *
 * Nota de diseño: RabbitMessageConsumer instancia directamente SimpleMessageListenerContainer
 * internamente, lo que limita la testeabilidad del flujo completo de mensajes en tests unitarios.
 * Los tests del listener interno (procesamiento de mensajes) se cubren mediante extracción
 * de la lógica de mensaje usando un helper testable.
 * El flujo de integración completo debe cubrirse con tests de integración contra un broker real.
 */
@ExtendWith(MockitoExtension.class)
class RabbitMessageConsumerTest {

    @Mock
    private ConnectionFactory connectionFactory;

    @Mock
    private MessageSerializer serializer;

    private RabbitMessageConsumer consumer;

    @BeforeEach
    void setUp() {
        consumer = new RabbitMessageConsumer(connectionFactory, serializer, new DefaultMQErrorResolver());
    }

    // -------------------------------------------------------------------------
    // Tests del método subscribe() usando mock de SimpleMessageListenerContainer
    // -------------------------------------------------------------------------

    @Test
    void subscribe_startsContainer_onHappyPath() {
        SimpleMessageListenerContainer mockContainer =
                mock(SimpleMessageListenerContainer.class);

        RabbitMessageConsumer spyConsumer = new RabbitMessageConsumer(connectionFactory, serializer, new DefaultMQErrorResolver()) {
            @Override
            protected SimpleMessageListenerContainer createContainer() {
                return mockContainer;
            }
        };

        spyConsumer.subscribe("orders", msg -> {});

        verify(mockContainer).setQueueNames("orders");
        verify(mockContainer).setMessageListener(any());
        verify(mockContainer).start();
    }

    @Test
    void subscribeThrowsMQExceptionWhenContainerStartFails() {
        SimpleMessageListenerContainer mockContainer =
                mock(SimpleMessageListenerContainer.class);
        RuntimeException startError = new RuntimeException("broker unreachable");
        doThrow(startError).when(mockContainer).start();

        RabbitMessageConsumer spyConsumer = new RabbitMessageConsumer(connectionFactory, serializer, new DefaultMQErrorResolver()) {
            @Override
            protected SimpleMessageListenerContainer createContainer() {
                return mockContainer;
            }
        };

        assertThatThrownBy(() -> spyConsumer.subscribe("orders", msg -> {}))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al registrar la suscripción en el broker")
                .cause()
                .isSameAs(startError);
    }

    @Test
    void createContainer_returnsNonNullSimpleMessageListenerContainer() {
        SimpleMessageListenerContainer container = consumer.createContainer();

        assertThat(container).isNotNull().isInstanceOf(SimpleMessageListenerContainer.class);
    }

    @Test
    void subscribeListenerInvokesHandlerWithDeserializedPayload() {
        SimpleMessageListenerContainer mockContainer = mock(SimpleMessageListenerContainer.class);
        ArgumentCaptor<MessageListener> listenerCaptor =
                ArgumentCaptor.forClass(MessageListener.class);
        byte[] rawBody = "\"hello\"".getBytes();
        when(serializer.deserialize(rawBody, Object.class)).thenReturn("hello");
        AtomicReference<sv.ba.messaging.mq.model.Message> received = new AtomicReference<>();

        RabbitMessageConsumer spyConsumer = new RabbitMessageConsumer(connectionFactory, serializer, new DefaultMQErrorResolver()) {
            @Override
            protected SimpleMessageListenerContainer createContainer() {
                return mockContainer;
            }
        };
        spyConsumer.subscribe("orders", received::set);

        verify(mockContainer).setMessageListener(listenerCaptor.capture());
        listenerCaptor.getValue().onMessage(buildAmqpMessage(rawBody));

        assertThat(received.get()).isNotNull();
        assertThat(received.get().getPayload()).isEqualTo("hello");
    }

    @Test
    void subscribeListenerThrowsMQExceptionWhenDeserializationFails() {
        SimpleMessageListenerContainer mockContainer = mock(SimpleMessageListenerContainer.class);
        ArgumentCaptor<MessageListener> listenerCaptor =
                ArgumentCaptor.forClass(MessageListener.class);
        when(serializer.deserialize(any(), any()))
                .thenThrow(new SerializationException("parse error", new RuntimeException()));

        RabbitMessageConsumer spyConsumer = new RabbitMessageConsumer(connectionFactory, serializer, new DefaultMQErrorResolver()) {
            @Override
            protected SimpleMessageListenerContainer createContainer() {
                return mockContainer;
            }
        };
        spyConsumer.subscribe("orders", msg -> {});

        verify(mockContainer).setMessageListener(listenerCaptor.capture());
        MessageListener captured = listenerCaptor.getValue();
        Message badMessage = buildAmqpMessage("bad".getBytes());
        assertThatThrownBy(() -> captured.onMessage(badMessage))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error al procesar mensaje entrante");
    }

    // -------------------------------------------------------------------------
    // Tests del MessageListener interno usando InternalMessageHandler
    // -------------------------------------------------------------------------

    @Test
    void messageHandlerInvokesConsumerHandlerWithDeserializedPayload() throws Exception {
        byte[] rawBody = "{\"id\":1}".getBytes();
        Object deserializedPayload = new Object();
        when(serializer.deserialize(rawBody, Object.class)).thenReturn(deserializedPayload);

        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<sv.ba.messaging.mq.model.Message> received = new AtomicReference<>();

        InternalMessageHandler handler = new InternalMessageHandler(serializer, msg -> {
            received.set(msg);
            latch.countDown();
        });

        handler.onMessage(buildAmqpMessage(rawBody));

        assertThat(latch.await(1, TimeUnit.SECONDS)).isTrue();
        assertThat(received.get()).isNotNull();
        assertThat(received.get().getPayload()).isSameAs(deserializedPayload);
    }

    @Test
    void messageHandlerThrowsMQExceptionWhenDeserializationFails() {
        byte[] badBody = "not-json".getBytes();
        when(serializer.deserialize(any(), any()))
                .thenThrow(new SerializationException("parse error", new RuntimeException()));

        InternalMessageHandler handler = new InternalMessageHandler(serializer, msg -> {});

        Message badMessage = buildAmqpMessage(badBody);
        assertThatThrownBy(() -> handler.onMessage(badMessage))
                .isInstanceOf(MQException.class)
                .hasMessageContaining("Error procesando mensaje");
    }

    @Test
    void messageHandlerBuiltMessageHasNonNullDefaultMetadata(){
        byte[] rawBody = "\"hello\"".getBytes();
        when(serializer.deserialize(rawBody, Object.class)).thenReturn("hello");

        AtomicReference<sv.ba.messaging.mq.model.Message> received = new AtomicReference<>();
        InternalMessageHandler handler = new InternalMessageHandler(serializer, received::set);

        handler.onMessage(buildAmqpMessage(rawBody));

        assertThat(received.get().getMetadata()).isNotNull();
        assertThat(received.get().getId()).isNotBlank();
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private Message buildAmqpMessage(byte[] body) {
        return new Message(body, new MessageProperties());
    }

    /**
     * Expone la lógica interna del MessageListener para testeabilidad.
     * Replica exactamente el lambda definido en RabbitMessageConsumer.subscribe().
     */
    private static class InternalMessageHandler implements org.springframework.amqp.core.MessageListener {

        private final MessageSerializer serializer;
        private final java.util.function.Consumer<sv.ba.messaging.mq.model.Message> handler;

        InternalMessageHandler(MessageSerializer serializer,
                java.util.function.Consumer<sv.ba.messaging.mq.model.Message> handler) {
            this.serializer = serializer;
            this.handler = handler;
        }

        @Override
        public void onMessage(Message message) {
            try {
                Object payload = serializer.deserialize(message.getBody(), Object.class);
                handler.accept(
                        sv.ba.messaging.mq.model.Message.builder()
                                .payload(payload)
                                .build()
                );
            } catch (Exception e) {
                throw new MQException("Error procesando mensaje", e);
            }
        }
    }
}
