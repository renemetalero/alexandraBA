package sv.ba.messaging.mq.rabbit.factory;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.api.MessageConsumer;
import sv.ba.messaging.mq.api.MessagePublisher;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class RabbitMQClientTest {

    @Mock
    private MessagePublisher publisher;

    @Mock
    private MessageConsumer consumer;

    @Test
    void publisher_returnsDelegatedPublisher() {
        RabbitMQClient client = new RabbitMQClient(publisher, consumer);

        assertThat(client.publisher()).isSameAs(publisher);
    }

    @Test
    void consumer_returnsDelegatedConsumer() {
        RabbitMQClient client = new RabbitMQClient(publisher, consumer);

        assertThat(client.consumer()).isSameAs(consumer);
    }

    @Test
    void implementsMQClientInterface() {
        RabbitMQClient client = new RabbitMQClient(publisher, consumer);

        assertThat(client).isInstanceOf(MQClient.class);
    }
}
