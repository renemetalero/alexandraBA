package sv.ba.messaging.mq.serialization;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class SerializationExceptionTest {

    @Test
    void constructor_storesMessageAndCause() {
        RuntimeException cause = new RuntimeException("json parse error");

        SerializationException ex = new SerializationException("deserialize failed", cause);

        assertThat(ex.getMessage()).isEqualTo("deserialize failed");
        assertThat(ex.getCause()).isSameAs(cause);
    }

    @Test
    void isRuntimeException() {
        assertThat(new SerializationException("x", new RuntimeException()))
                .isInstanceOf(RuntimeException.class);
    }
}
