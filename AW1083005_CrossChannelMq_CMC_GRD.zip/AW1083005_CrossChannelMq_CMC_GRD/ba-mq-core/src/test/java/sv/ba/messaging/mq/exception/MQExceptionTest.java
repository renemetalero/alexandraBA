package sv.ba.messaging.mq.exception;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MQExceptionTest {

    @Test
    void constructor_withMessage_storesMessage() {
        MQException ex = new MQException("broker down");

        assertThat(ex.getMessage()).isEqualTo("broker down");
        assertThat(ex.getCause()).isNull();
    }

    @Test
    void constructor_withMessageAndCause_storesBoth() {
        RuntimeException cause = new RuntimeException("timeout");

        MQException ex = new MQException("publish failed", cause);

        assertThat(ex.getMessage()).isEqualTo("publish failed");
        assertThat(ex.getCause()).isSameAs(cause);
    }

    @Test
    void isRuntimeException() {
        assertThat(new MQException("x")).isInstanceOf(RuntimeException.class);
    }
}
