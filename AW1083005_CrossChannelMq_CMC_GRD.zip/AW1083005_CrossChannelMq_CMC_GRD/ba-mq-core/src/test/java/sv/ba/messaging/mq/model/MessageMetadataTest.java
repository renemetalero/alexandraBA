package sv.ba.messaging.mq.model;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MessageMetadataTest {

    @Test
    void defaultMetadataHasExpectedDefaults() {
        MessageMetadata meta = MessageMetadata.defaultMetadata();

        assertThat(meta.getSource()).isEqualTo("unknown");
        assertThat(meta.getVersion()).isEqualTo("v1");
        assertThat(meta.getHeaders()).isEmpty();
    }

    @Test
    void defaultMetadataTimestampIsRecentlyCreated() {
        Instant before = Instant.now();
        MessageMetadata meta = MessageMetadata.defaultMetadata();
        Instant after = Instant.now();

        assertThat(meta.getTimestamp()).isBetween(before, after);
    }

    @Test
    void ofWithSourceAndVersionSetsValues() {
        MessageMetadata meta = MessageMetadata.of("payments-service", "v3");

        assertThat(meta.getSource()).isEqualTo("payments-service");
        assertThat(meta.getVersion()).isEqualTo("v3");
        assertThat(meta.getHeaders()).isEmpty();
    }

    @Test
    void ofWithHeadersSetsHeaders() {
        Map<String, String> headers = Map.of("x-trace-id", "abc123", "x-region", "us-east");
        MessageMetadata meta = MessageMetadata.of("svc", "v1", headers);

        assertThat(meta.getHeaders())
                .containsEntry("x-trace-id", "abc123")
                .containsEntry("x-region", "us-east");
    }

    @Test
    void headersAreImmutable() {
        MessageMetadata meta = MessageMetadata.of("svc", "v1", Map.of("k", "v"));
        Map<String, String> headers = meta.getHeaders();

        assertThatThrownBy(() -> headers.put("new-key", "new-value"))
                .isInstanceOf(UnsupportedOperationException.class);
    }
}
