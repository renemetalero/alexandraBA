package sv.ba.messaging.mq.model;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class MessageTest {

    @Test
    void build_setsPayload() {
        Message msg = Message.builder().payload("hello").build();

        assertThat(msg.getPayload()).isEqualTo("hello");
    }

    @Test
    void build_generatesId() {
        Message msg = Message.builder().payload("x").build();

        assertThat(msg.getId()).isNotBlank();
    }

    @Test
    void build_twoMessages_haveDifferentIds() {
        Message a = Message.builder().payload("x").build();
        Message b = Message.builder().payload("x").build();

        assertThat(a.getId()).isNotEqualTo(b.getId());
    }

    @Test
    void build_usesDefaultMetadata_whenNotSet() {
        Message msg = Message.builder().payload("x").build();

        assertThat(msg.getMetadata()).isNotNull();
        assertThat(msg.getMetadata().getSource()).isEqualTo("unknown");
    }

    @Test
    void build_usesCustomMetadata_whenSet() {
        MessageMetadata custom = MessageMetadata.of("order-service", "v2");

        Message msg = Message.builder()
                .payload("x")
                .metadata(custom)
                .build();

        assertThat(msg.getMetadata().getSource()).isEqualTo("order-service");
        assertThat(msg.getMetadata().getVersion()).isEqualTo("v2");
    }

    @Test
    void build_throwsNullPointerException_whenPayloadIsNull() {
        assertThatNullPointerException()
                .isThrownBy(() -> Message.builder().build())
                .withMessageContaining("payload");
    }
}
