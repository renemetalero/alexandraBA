package sv.ba.messaging.mq.exception;

/**
 * Excepción de tiempo de ejecución raíz para errores relacionados con el broker de mensajería.
 * <p>
 * Todas las excepciones específicas de la librería deben extender esta clase,
 * permitiendo a los consumidores capturar errores de mensajería de forma genérica
 * con un único {@code catch (MQException e)}.
 * </p>
 * <p>
 * La forma recomendada de construir instancias es mediante los factory methods
 * {@link #of(String, Throwable, MQErrorResolver)} y {@link #of(String, MQErrorResolver)},
 * que asocian un código de error del catálogo {@link MQErrorCodes} y delegan la
 * resolución del mensaje al {@link MQErrorResolver} configurado.
 * Los constructores legacy se conservan para retrocompatibilidad.
 * </p>
 */
public class MQException extends RuntimeException {

    private final String errorCode; // nullable — retrocompatibilidad con constructores legacy

    // ─── Constructores legacy (retrocompatibles) ──────────────────────────────

    /**
     * Construye una nueva excepción con el mensaje descriptivo indicado.
     *
     * @param message descripción del error
     */
    public MQException(String message) {
        super(message);
        this.errorCode = null;
    }

    /**
     * Construye una nueva excepción con mensaje descriptivo y causa raíz.
     *
     * @param message descripción del error
     * @param cause   excepción original que provocó este error
     */
    public MQException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = null;
    }

    // ─── Constructor interno con código (usado por factory methods) ───────────

    private MQException(String errorCode, String resolvedMessage, Throwable cause) {
        super(resolvedMessage, cause);
        this.errorCode = errorCode;
    }

    // ─── Factory methods recomendados ─────────────────────────────────────────

    /**
     * Crea una excepción con código de error y causa, resolviendo el mensaje
     * mediante el {@link MQErrorResolver} indicado.
     *
     * @param errorCode código del catálogo (e.g. {@link MQErrorCodes#PUBLISH_FAILED})
     * @param cause     excepción original que provocó este error
     * @param resolver  resolvedor de mensajes; no debe ser {@code null}
     * @return nueva instancia de {@code MQException}
     */
    public static MQException of(String errorCode, Throwable cause, MQErrorResolver resolver) {
        return new MQException(errorCode, resolver.resolve(errorCode), cause);
    }

    /**
     * Crea una excepción con código de error (sin causa), resolviendo el mensaje
     * mediante el {@link MQErrorResolver} indicado.
     *
     * @param errorCode código del catálogo (e.g. {@link MQErrorCodes#BROKER_NOT_CONFIGURED})
     * @param resolver  resolvedor de mensajes; no debe ser {@code null}
     * @return nueva instancia de {@code MQException}
     */
    public static MQException of(String errorCode, MQErrorResolver resolver) {
        return new MQException(errorCode, resolver.resolve(errorCode), null);
    }

    // ─── Getter ───────────────────────────────────────────────────────────────

    /**
     * Retorna el código de error asociado a esta excepción.
     *
     * @return código de error (e.g. {@code "MQ-PUB-001"}); retorna {@code "UNKNOWN"}
     *         si la excepción fue construida con un constructor legacy sin código
     */
    public String getErrorCode() {
        return errorCode != null ? errorCode : "UNKNOWN";
    }
}
