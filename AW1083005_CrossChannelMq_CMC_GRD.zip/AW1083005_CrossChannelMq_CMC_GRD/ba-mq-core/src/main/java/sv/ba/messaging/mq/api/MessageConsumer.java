package sv.ba.messaging.mq.api;

import sv.ba.messaging.mq.model.Message;
import java.util.function.Consumer;

/**
 * Contrato para la suscripción y consumo de mensajes desde un broker de mensajería.
 * <p>
 * Aplica el patrón <b>Observer</b>: el llamador registra un {@link Consumer} que
 * será invocado cada vez que arribe un mensaje al topic indicado.
 * </p>
 */
public interface MessageConsumer {

    /**
     * Se suscribe al topic indicado y procesa cada mensaje recibido con el handler.
     *
     * @param topic   nombre del topic, queue o exchange a escuchar; no debe ser {@code null}
     * @param handler función que procesa cada {@link Message} entrante; no debe ser {@code null}
     * @throws sv.ba.messaging.mq.exception.MQException si ocurre un error al registrar la suscripción
     */
    void subscribe(String topic, Consumer<Message> handler);

}

