package sv.ba.messaging.mq.exception;

/**
 * Catálogo de códigos de error de la librería {@code ba-mq}.
 * <p>
 * Cada constante representa un tipo de fallo identificable de forma única.
 * Los consumidores pueden usar estos valores para distinguir errores en bloques
 * {@code catch}, logging estructurado o alertas de monitoreo.
 * </p>
 * <p>
 * Al ser constantes {@code String}, los consumidores pueden definir sus propios
 * códigos del mismo tipo sin necesidad de extender este catálogo.
 * </p>
 */
public final class MQErrorCodes {

    private MQErrorCodes() {}

    // --- Publicación ---
    public static final String PUBLISH_FAILED           = "MQ-PUB-001";
    public static final String PUBLISH_SERIALIZATION    = "MQ-PUB-002";

    // --- Suscripción ---
    public static final String SUBSCRIBE_FAILED         = "MQ-SUB-001";
    public static final String MESSAGE_PROCESSING       = "MQ-SUB-002";

    // --- Conexión ---
    public static final String CONNECTION_FAILED        = "MQ-CON-001";
    public static final String CONNECTION_FACTORY_BUILD = "MQ-CON-002";

    // --- Serialización ---
    public static final String SERIALIZATION_FAILED     = "MQ-SER-001";
    public static final String DESERIALIZATION_FAILED   = "MQ-SER-002";

    // --- Configuración ---
    public static final String BROKER_NOT_CONFIGURED    = "MQ-CFG-001";
}
