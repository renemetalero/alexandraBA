package sv.ba.messaging.mq.api;

import sv.ba.messaging.mq.model.Message;

/**
 * Contrato para la publicación de mensajes hacia un broker de mensajería.
 * <p>
 * Las implementaciones concretas (e.g. RabbitMQ, Kafka) deben garantizar
 * que el mensaje sea enviado de forma confiable al destino indicado.
 * </p>
 */
public interface MessagePublisher {

    /**
     * Publica un {@link Message} en el topic o exchange indicado.
     *
     * @param topic   nombre del topic, queue o exchange de destino; no debe ser {@code null}
     * @param message mensaje a publicar; no debe ser {@code null}
     * @throws sv.ba.messaging.mq.exception.MQException si ocurre un error al publicar
     */
    void publish(String topic, Message message);

}

