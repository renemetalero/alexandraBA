package sv.ba.messaging.mq.api;

/**
 * Punto de entrada principal para interactuar con el broker de mensajería.
 * <p>
 * Actúa como <b>Facade</b> que agrupa las capacidades de publicación y
 * consumo de mensajes, desacoplando al cliente de la implementación
 * concreta del broker (RabbitMQ, IBMMQ, Kafka, etc.).
 * </p>
 *
 * <pre>{@code
 * MQClient client = ...; // inyectado vía Spring
 * client.publisher().publish("ordenes", message);
 * client.consumer().subscribe("ordenes", msg -> process(msg));
 * }</pre>
 */
public interface MQClient {

    /**
     * Retorna el publicador de mensajes asociado a este cliente.
     *
     * @return instancia de {@link MessagePublisher}, nunca {@code null}
     */
    MessagePublisher publisher();

    /**
     * Retorna el consumidor de mensajes asociado a este cliente.
     *
     * @return instancia de {@link MessageConsumer}, nunca {@code null}
     */
    MessageConsumer consumer();
   
}
