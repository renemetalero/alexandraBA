package sv.ba.messaging.mq.exception;

import java.util.Map;

/**
 * Implementación por defecto de {@link MQErrorResolver} que resuelve mensajes
 * desde un {@code Map} inmutable en memoria.
 * <p>
 * No requiere Spring ni archivos externos; puede usarse directamente fuera
 * del starter cuando se configura la librería de forma manual.
 * </p>
 */
public class DefaultMQErrorResolver implements MQErrorResolver {

    private static final Map<String, String> MESSAGES = Map.of(
            MQErrorCodes.PUBLISH_FAILED,           "Error al publicar mensaje en el broker",
            MQErrorCodes.PUBLISH_SERIALIZATION,    "Error al serializar el payload antes de publicar",
            MQErrorCodes.SUBSCRIBE_FAILED,         "Error al registrar la suscripción en el broker",
            MQErrorCodes.MESSAGE_PROCESSING,       "Error al procesar mensaje entrante",
            MQErrorCodes.CONNECTION_FAILED,        "Error al establecer conexión con el broker",
            MQErrorCodes.CONNECTION_FACTORY_BUILD, "Error al construir la ConnectionFactory",
            MQErrorCodes.SERIALIZATION_FAILED,     "Error al serializar el objeto",
            MQErrorCodes.DESERIALIZATION_FAILED,   "Error al deserializar los bytes",
            MQErrorCodes.BROKER_NOT_CONFIGURED,    "Ningún broker habilitado en la configuración"
    );

    @Override
    public String resolve(String errorCode) {
        return MESSAGES.getOrDefault(errorCode, "Error desconocido [" + errorCode + "]");
    }
}
