package sv.ba.messaging.mq.exception;

/**
 * Contrato para resolver el mensaje descriptivo asociado a un código de error MQ.
 * <p>
 * Las implementaciones pueden leer los mensajes desde un {@code Map} en memoria,
 * un archivo {@code .properties}, un {@code ResourceBundle} para i18n, o cualquier
 * fuente externa. La interfaz no depende de Spring y puede usarse en cualquier
 * contexto Java.
 * </p>
 *
 * @see DefaultMQErrorResolver
 */
public interface MQErrorResolver {

    /**
     * Retorna el mensaje descriptivo asociado al código dado.
     *
     * @param errorCode código de error (e.g. {@code "MQ-PUB-001"}); no debe ser {@code null}
     * @return mensaje descriptivo; nunca {@code null}
     */
    String resolve(String errorCode);
}
