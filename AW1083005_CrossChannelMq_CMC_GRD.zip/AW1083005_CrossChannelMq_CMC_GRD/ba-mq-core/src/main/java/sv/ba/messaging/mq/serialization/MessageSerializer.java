package sv.ba.messaging.mq.serialization;

/**
 * Contrato de serialización y deserialización de payloads de mensajes.
 * <p>
 * Aplica el patrón <b>Strategy</b>: distintas implementaciones pueden ofrecer
 * diferentes formatos (JSON via Jackson, Avro, Protobuf, etc.) sin cambiar
 * el código cliente.
 * </p>
 */
public interface MessageSerializer {

    /**
     * Serializa el payload de un mensaje a un arreglo de bytes.
     *
     * @param payload objeto a serializar; no debe ser {@code null}
     * @return representación binaria del payload
     * @throws SerializationException si ocurre un error durante la serialización
     */
    byte[] serialize(Object payload);

    /**
     * Deserializa un arreglo de bytes al tipo destino indicado.
     *
     * @param <T>        tipo del objeto resultante
     * @param data       bytes a deserializar; no debe ser {@code null}
     * @param targetType clase del tipo destino; no debe ser {@code null}
     * @return instancia del tipo {@code T} reconstruida desde los bytes
     * @throws SerializationException si ocurre un error durante la deserialización
     */
    <T> T deserialize(byte[] data, Class<T> targetType);
}
