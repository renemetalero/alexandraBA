package sv.ba.messaging.mq.model;

import java.util.Objects;
import java.util.UUID;

/**
 * Representa un mensaje inmutable que viaja a través del broker de mensajería.
 * <p>
 * Se construye mediante el patrón <b>Builder</b>. El {@code id} se genera
 * automáticamente con {@link UUID} si no se especifica uno.
 * </p>
 *
 * <pre>{@code
 * Message msg = Message.builder()
 *     .payload(myDto)
 *     .metadata(MessageMetadata.defaultMetadata())
 *     .build();
 * }</pre>
 */
public final class Message {

    private final String id;
    private final Object payload;
    private final MessageMetadata metadata;

    private Message(Builder builder) {
        this.id = builder.id;
        this.payload = builder.payload;
        this.metadata = builder.metadata;
    }

    /**
     * Retorna el identificador único del mensaje.
     *
     * @return UUID del mensaje como {@link String}, nunca {@code null}
     */
    public String getId() {
        return id;
    }

    /**
     * Retorna el cuerpo del mensaje.
     *
     * @return payload del mensaje; nunca {@code null}
     */
    public Object getPayload() {
        return payload;
    }

    /**
     * Retorna la metadata asociada al mensaje.
     *
     * @return instancia de {@link MessageMetadata}, nunca {@code null}
     */
    public MessageMetadata getMetadata() {
        return metadata;
    }

    /**
     * Retorna un nuevo {@link Builder} para construir instancias de {@code Message}.
     *
     * @return nuevo builder
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Builder para la construcción fluida de instancias {@link Message}.
     */
    public static final class Builder {

        private String id = UUID.randomUUID().toString();
        private Object payload;
        private MessageMetadata metadata = MessageMetadata.defaultMetadata();

        /**
         * Establece el cuerpo del mensaje.
         *
         * @param payload objeto a transportar; no debe ser {@code null}
         * @return este builder
         */
        public Builder payload(Object payload) {
            this.payload = payload;
            return this;
        }

        /**
         * Establece la metadata del mensaje.
         * Si no se invoca, se usará {@link MessageMetadata#defaultMetadata()}.
         *
         * @param metadata metadata personalizada; no debe ser {@code null}
         * @return este builder
         */
        public Builder metadata(MessageMetadata metadata) {
            this.metadata = metadata;
            return this;
        }

        /**
         * Construye y retorna una instancia inmutable de {@link Message}.
         *
         * @return nueva instancia de {@link Message}
         * @throws NullPointerException si {@code payload} es {@code null}
         */
        public Message build() {
            Objects.requireNonNull(payload, "payload no puede ser null");
            return new Message(this);
        }
    }
}

