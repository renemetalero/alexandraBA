package sv.ba.messaging.mq.model;

import java.time.Instant;
import java.util.Map;

/**
 * Datos de contexto inmutables asociados a un {@link Message}.
 * <p>
 * Contiene información sobre el origen, versión del esquema, momento de
 * creación y cabeceras personalizadas del mensaje. El mapa de headers
 * es una copia defensiva inmutable.
 * </p>
 */
public final class MessageMetadata {

    private final String source;
    private final String version;
    private final Instant timestamp;
    private final Map<String, String> headers;

    private MessageMetadata(
            String source,
            String version,
            Instant timestamp,
            Map<String, String> headers) {

        this.source = source;
        this.version = version;
        this.timestamp = timestamp;
        this.headers = Map.copyOf(headers);
    }

    /**
     * Crea una instancia de {@code MessageMetadata} con valores por defecto:
     * source {@code "unknown"}, version {@code "v1"}, timestamp actual y headers vacíos.
     *
     * @return nueva instancia con valores por defecto
     */
    public static MessageMetadata defaultMetadata() {
        return new MessageMetadata(
            "unknown",
            "v1",
            Instant.now(),
            Map.of()
        );
    }

    /**
     * Crea una instancia con source, version y headers personalizados.
     *
     * @param source  nombre del servicio origen; no debe ser {@code null}
     * @param version versión del esquema (e.g. {@code "v2"}); no debe ser {@code null}
     * @param headers cabeceras clave-valor; no debe ser {@code null}
     * @return nueva instancia de {@code MessageMetadata}
     */
    public static MessageMetadata of(String source, String version, Map<String, String> headers) {
        return new MessageMetadata(source, version, Instant.now(), headers);
    }

    /**
     * Crea una instancia con source y version personalizados y headers vacíos.
     *
     * @param source  nombre del servicio origen; no debe ser {@code null}
     * @param version versión del esquema (e.g. {@code "v2"}); no debe ser {@code null}
     * @return nueva instancia de {@code MessageMetadata}
     */
    public static MessageMetadata of(String source, String version) {
        return of(source, version, Map.of());
    }

    /**
     * Retorna el identificador del sistema o servicio que originó el mensaje.
     *
     * @return nombre del origen; nunca {@code null}
     */
    public String getSource() {
        return source;
    }

    /**
     * Retorna la versión del esquema del mensaje.
     *
     * @return versión del esquema (e.g. {@code "v1"}); nunca {@code null}
     */
    public String getVersion() {
        return version;
    }

    /**
     * Retorna el instante en que fue creado el mensaje.
     *
     * @return timestamp de creación; nunca {@code null}
     */
    public Instant getTimestamp() {
        return timestamp;
    }

    /**
     * Retorna las cabeceras personalizadas del mensaje como mapa inmutable.
     *
     * @return mapa de cabeceras clave-valor; nunca {@code null}, puede estar vacío
     */
    public Map<String, String> getHeaders() {
        return headers;
    }
}

