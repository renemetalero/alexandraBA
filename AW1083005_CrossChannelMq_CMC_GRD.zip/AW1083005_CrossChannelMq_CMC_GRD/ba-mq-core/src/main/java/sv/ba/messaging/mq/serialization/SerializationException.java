package sv.ba.messaging.mq.serialization;

/**
 * Excepción lanzada cuando ocurre un error durante la serialización
 * o deserialización de un payload de mensaje.
 *
 * @see MessageSerializer
 */
public class SerializationException extends RuntimeException {

    /**
     * Construye una nueva excepción con mensaje descriptivo y causa raíz.
     *
     * @param message descripción del error de serialización
     * @param cause   excepción original que provocó el fallo
     */
    public SerializationException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
