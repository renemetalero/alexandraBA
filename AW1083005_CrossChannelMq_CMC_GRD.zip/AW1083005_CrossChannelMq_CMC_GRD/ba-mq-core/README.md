# ba-mq-core

Módulo base de la librería `ba-crosschannel-mq-lib`. Define los **contratos, modelos y excepciones** del sistema de mensajería, sin acoplar ninguna implementación concreta de broker.

---

## Estructura del módulo

```
ba-mq-core
└── sv.ba.messaging.mq
    ├── api
    │   ├── MQClient.java           # Facade: punto de entrada principal
    │   ├── MessagePublisher.java   # Contrato de publicación
    │   └── MessageConsumer.java    # Contrato de consumo (Observer)
    ├── model
    │   ├── Message.java            # Mensaje inmutable (Builder)
    │   └── MessageMetadata.java    # Metadata inmutable del mensaje
    ├── serialization
    │   ├── MessageSerializer.java  # Contrato de serialización (Strategy)
    │   └── SerializationException.java
    └── exception
        └── MQException.java        # Excepción raíz de mensajería
```

---

## Patrones de diseño aplicados

| Patrón | Clase |
|---|---|
| **Facade** | `MQClient` — agrupa publisher y consumer en un único punto de entrada |
| **Builder** | `Message.Builder` — construcción fluida de mensajes inmutables |
| **Strategy** | `MessageSerializer` — intercambiable entre JSON, Avro, Protobuf, etc. |
| **Observer** | `MessageConsumer.subscribe()` — registro de handlers reactivos |

---

## Uso básico

### Construir un mensaje

```java
Message message = Message.builder()
    .payload(myDto)
    .metadata(MessageMetadata.defaultMetadata())
    .build();
```

### Publicar un mensaje

```java
MQClient client = ...; // inyectado vía Spring

client.publisher().publish("ordenes.creadas", message);
```

### Suscribirse a un topic

```java
client.consumer().subscribe("ordenes.creadas", msg -> {
    OrderDto order = (OrderDto) msg.getPayload();
    process(order);
});
```

### Implementar un serializer personalizado

```java
public class AvroMessageSerializer implements MessageSerializer {

    @Override
    public byte[] serialize(Object payload) { ... }

    @Override
    public <T> T deserialize(byte[] data, Class<T> targetType) { ... }
}
```

---

## Dependencias

```gradle
dependencies {
    api platform("org.springframework.boot:spring-boot-dependencies:3.4.4")
    api "com.fasterxml.jackson.core:jackson-databind"
}
```

> Este módulo **no depende de ningún broker**. Las implementaciones concretas residen en módulos separados (e.g. `ba-mq-rabbit`).

---

## Módulos relacionados

| Módulo | Descripción |
|---|---|
| `ba-mq-rabbit` | Implementación RabbitMQ de `MQClient`, `MessagePublisher` y `MessageConsumer` |
| `ba-mq-spring-boot-starter` | Auto-configuración Spring Boot para levantar el cliente sin configuración manual |
