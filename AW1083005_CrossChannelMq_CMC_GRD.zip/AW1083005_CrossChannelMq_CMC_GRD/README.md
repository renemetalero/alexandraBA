# Cross Channel MQ - Librería de Integración Multibroker

## Descripción

**ba-mq** es una librería Java 21 que estandariza la integración con sistemas de mensajería, proporcionando una capa de abstracción para simplificar el envío y recepción de mensajes en aplicaciones que utilicen **RabbitMQ** e **IBM MQ**.

La librería permite:
- **Publicar mensajes** de forma unificada en ambos brokers
- **Suscribirse a colas** con manejo automático de listeners
- **Cambiar de broker** sin modificar el código de negocio
- **Manejo estructurado de errores** con catálogos de códigos de error
- **Serialización flexible** de mensajes (JSON, custom)
- **Trazabilidad completa** del flujo de mensajes

---

## Índice

| # | Sección |
|---|---|
| 1 | [¿Qué es?](#qué-es) |
| 2 | [Requisitos](#requisitos) |
| 3 | [Estructura del Proyecto](#estructura-del-proyecto) |
| 4 | [Módulos Disponibles](#módulos-disponibles) |
| 5 | [Instalación](#instalación) |
| 6 | [Uso Básico](#uso-básico) |
| 7 | [Componentes de la Librería](#componentes-de-la-librería) |
| 8 | [Casos de Uso](#casos-de-uso) |
| 9 | [Manejo de Errores](#manejo-de-errores) |
| 10 | [Comandos Gradle](#comandos-gradle) |
| 11 | [Versiones y Compatibilidad](#versiones-y-compatibilidad) |

---

## Requisitos

- **Java**: 21+
- **Gradle**: 8.14.3+
- **Spring Boot**: 3.5.14+
- **Spring Framework**: 6.2.13+
- **Jakarta JMS**: 3.x (JMS 3.0+)

---

## Estructura del Proyecto

```
ba-mq/
├── ba-mq-core/                      # Módulo Core - Entidades y Contratos
│   └── src/main/java/sv/ba/messaging/mq/
│       ├── model/                   # Modelos: Message, MessageMetadata
│       ├── api/                     # API pública: MQClient, MQPublisher, MQSubscriber
│       ├── exception/               # Excepciones y resolvidores de errores
│       └── serialization/           # Interfaz de serialización
│
├── ba-mq-rabbit/                    # Módulo RabbitMQ - Implementación específica
│   └── src/main/java/sv/ba/messaging/mq/rabbit/
│       ├── config/                  # Configuración de RabbitMQ
│       ├── client/                  # Implementación de MQClient para RabbitMQ
│       ├── publisher/               # PublisherAdapter para RabbitMQ
│       ├── consumer/                # ConsumerAdapter para RabbitMQ
│       └── serialization/           # Serializadores específicos (Jackson)
│
├── ba-mq-ibm/                       # Módulo IBM MQ - Implementación específica
│   └── src/main/java/sv/ba/messaging/mq/ibm/
│       ├── config/                  # Configuración de IBM MQ + Adaptador Jakarta JMS
│       ├── client/                  # Implementación de MQClient para IBM MQ
│       ├── publisher/               # PublisherAdapter para IBM MQ
│       └── consumer/                # ConsumerAdapter para IBM MQ
│
├── ba-mq-spring-boot-starter/       # Módulo Spring Boot - Autoconfiguración
│   └── src/main/java/sv/ba/messaging/mq/starter/
│       ├── config/                  # AutoConfiguration + Propiedades
│       ├── condition/               # Condiciones: OnIBMEnabled, OnRabbitEnabled
│       ├── validation/              # Validadores de configuración
│       └── error/                   # Resolvidores de errores desde propiedades
│
└── ba-mq-bundle/                    # Módulo BOM - Gestión de dependencias
    └── pom.xml (lógico)             # Define versiones consistentes
```

---

## Módulos Disponibles

| Módulo | Propósito | Dependencias |
|--------|-----------|--------------|
| **ba-mq-core** | API pública, modelos y contratos | Spring Framework, Jakarta JMS (interfaz) |
| **ba-mq-rabbit** | Implementación para RabbitMQ | ba-mq-core, Spring AMQP, Jackson |
| **ba-mq-ibm** | Implementación para IBM MQ + Adaptador Jakarta JMS | ba-mq-core, IBM MQ allclient |
| **ba-mq-spring-boot-starter** | Autoconfiguración Spring Boot | todos los anteriores, Spring Boot |
| **ba-mq-bundle** | BOM (Bill of Materials) | Define versiones consistentes |

---

## Instalación

### Como Dependencia en tu Proyecto

**Opción 1: Solo Spring Boot Starter (Recomendado)**
```gradle
dependencies {
    implementation 'sv.ba.crosschannel.mq:ba-mq-spring-boot-starter:0.1.0-SNAPSHOT'
}
```

**Opción 2: Módulos Específicos**
```gradle
dependencies {
    implementation 'sv.ba.crosschannel.mq:ba-mq-core:0.1.0-SNAPSHOT'
    implementation 'sv.ba.crosschannel.mq:ba-mq-rabbit:0.1.0-SNAPSHOT'
    // O
    implementation 'sv.ba.crosschannel.mq:ba-mq-ibm:0.1.0-SNAPSHOT'
}
```

---

## Uso Básico

### Configuración en application.yml

```yaml
spring:
  application:
    name: mi-app-mensajeria

ba:
  messaging:
    # Habilitar RabbitMQ
    rabbit:
      enabled: true
      host: localhost
      port: 5672
      username: guest
      password: guest
      virtual-host: /
    
    # Habilitar IBM MQ
    ibm:
      enabled: true
      host: localhost
      port: 1414
      channel: DEV.APP.SVRCONN
      queue-manager: QM1
      username: app
      password: passw0rd
```

### Inyectar y Usar MQClient

```java
import sv.ba.messaging.mq.api.MQClient;
import sv.ba.messaging.mq.model.Message;
import sv.ba.messaging.mq.model.MessageMetadata;
import org.springframework.stereotype.Service;

@Service
public class PedidoService {
    
    private final MQClient mqClient;
    
    public PedidoService(MQClient mqClient) {
        this.mqClient = mqClient;
    }
    
    // PUBLICAR un mensaje
    public void crearPedido(String numeroCliente, String detalles) {
        // Crear el mensaje
        Message mensaje = Message.builder()
            .correlationId(UUID.randomUUID().toString())
            .payload(detalles)
            .headers(Map.of(
                "cliente", numeroCliente,
                "timestamp", LocalDateTime.now().toString()
            ))
            .build();
        
        // Publicar en la cola
        mqClient.publish("pedidos.nuevos", mensaje);
    }
    
    // SUSCRIBIRSE a una cola
    public void procesarPedidos() {
        mqClient.subscribe("pedidos.nuevos", mensaje -> {
            // Lógica de procesamiento del mensaje
            System.out.println("Pedido recibido: " + mensaje.getPayload());
            
            // Publicar confirmación
            mqClient.publish("pedidos.confirmados", Message.builder()
                .payload("Pedido procesado")
                .build());
        });
    }
}
```

---

## Componentes de la Librería

### Core API

| Componente | Paquete | Descripción |
|-----------|---------|-------------|
| **MQClient** | `sv.ba.messaging.mq.api` | Interfaz principal para publicar y suscribirse |
| **MQPublisher** | `sv.ba.messaging.mq.api` | Contrato para publicación de mensajes |
| **MQSubscriber** | `sv.ba.messaging.mq.api` | Contrato para suscripción a colas |
| **Message** | `sv.ba.messaging.mq.model` | Modelo de mensaje con payload y metadatos |
| **MessageMetadata** | `sv.ba.messaging.mq.model` | Información adicional: correlationId, headers, etc. |

### Excepciones

| Excepción | Descripción |
|-----------|------------|
| **MQException** | Excepción base de la librería |
| **MQErrorCodes** | Catálogo de códigos de error estándar |
| **MQErrorResolver** | Resolvedor de excepciones con mensajes descriptivos |

### Implementaciones

**RabbitMQ:**
- `RabbitMQClient` - Implementación de MQClient para RabbitMQ
- `RabbitMessagePublisher` - Publicador basado en Spring AMQP
- `RabbitMessageConsumer` - Consumidor con listeners

**IBM MQ:**
- `IBMConnectionFactoryBuilder` - Adaptador Jakarta JMS para IBM MQ (javax.jms → jakarta.jms)
- `IBMMessagePublisher` - Publicador basado en JMS
- `IBMMessageConsumer` - Consumidor con listeners JMS

---

## Casos de Uso

### Caso 1: Publicación Simple

```java
@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {
    
    private final MQClient mqClient;
    
    @PostMapping
    public ResponseEntity<String> crearPedido(@RequestBody PedidoRequest request) {
        Message mensaje = Message.builder()
            .correlationId(UUID.randomUUID().toString())
            .payload(request.getDetalles())
            .build();
        
        mqClient.publish("pedidos.nuevos", mensaje);
        return ResponseEntity.accepted().body("Pedido enviado a la cola");
    }
}
```

### Caso 2: Consumidor Asincrónico

```java
@Component
public class PedidoConsumer {
    
    private final MQClient mqClient;
    private final PedidoRepository repository;
    
    @PostConstruct
    public void iniciarConsumer() {
        mqClient.subscribe("pedidos.nuevos", this::procesarPedido);
    }
    
    private void procesarPedido(Message mensaje) {
        try {
            Pedido pedido = parseJson(mensaje.getPayload());
            repository.save(pedido);
            
            // Enviar confirmación
            mqClient.publish("pedidos.procesados", Message.builder()
                .payload("OK")
                .build());
        } catch (Exception ex) {
            // Enviar a cola de errores
            mqClient.publish("pedidos.errores", Message.builder()
                .payload(ex.getMessage())
                .build());
        }
    }
}
```

### Caso 3: Cambiar entre Brokers

**Sin cambiar código:**
```yaml
# Para RabbitMQ
ba.messaging.rabbit.enabled: true
ba.messaging.ibm.enabled: false

# Para IBM MQ (solo cambiar esta línea)
ba.messaging.rabbit.enabled: false
ba.messaging.ibm.enabled: true
```

---

## Manejo de Errores

La librería proporciona un catálogo estándar de errores:

```java
// MQErrorCodes.java
public static final String PUBLISH_FAILED = "MQ-PUB-001";
public static final String SUBSCRIBE_FAILED = "MQ-SUB-001";
public static final String CONNECTION_FAILED = "MQ-CON-001";
public static final String SERIALIZATION_FAILED = "MQ-SER-001";
public static final String DESERIALIZATION_FAILED = "MQ-SER-002";
```

**Uso en tu aplicación:**

```java
catch (MQException ex) {
    String codigo = ex.getErrorCode();
    String mensaje = errorResolver.resolve(codigo);
    logger.error("Error {}: {}", codigo, mensaje);
}
```

---

## Comandos Gradle

### Compilar el Proyecto Completo
```bash
# Windows
.\gradlew clean build

# Linux/Mac
./gradlew clean build
```

### Ejecutar Tests
```bash
# Todos los módulos
./gradlew test

# Solo ba-mq-ibm
./gradlew ba-mq-ibm:test

# Solo ba-mq-rabbit
./gradlew ba-mq-rabbit:test
```

### Generar Reporte de Cobertura (Jacoco)
```bash
./gradlew clean build jacocoAggregateReport
```
*El reporte consolidado se genera en: `build/reports/jacoco/html/index.html`*

### Generar POMs para Publicación
```bash
./gradlew generarPom
```
*Se crean en cada módulo: `build/publications/mavenJava/{modulo}-{version}.pom`*

### Análisis de Código con SonarQube
```bash
./gradlew sonarqube
```

### Publicar a Artifactory
```bash
# Con credenciales de Azure Pipelines
./gradlew publish \
  -Partifactory_user=${ARTIFACTORY_USER} \
  -Partifactory_password=${ARTIFACTORY_PASSWORD} \
  -Partifactory_contextUrl=${ARTIFACTORY_URL}
```

### Limpiar y Verificar
```bash
# Limpiar todo
./gradlew clean

# Compilar sin tests
./gradlew build -x test

# Ver todas las tareas
./gradlew tasks
```

---

## Seguridad y Configuración

### Dependencias Actualizadas

La librería utiliza versiones patched para mitigar vulnerabilidades:

- **Spring Boot**: 3.5.14 (CVE-2026-40973 fixed)
- **Spring Framework**: 6.2.13 (CVE-2025-41249 fixed)
- **AssertJ**: 3.27.7 (CVE-2026-24400 fixed)
- **Bouncy Castle**: 1.84 (múltiples CVEs fixed)
- **Logback**: 1.5.25 (CVE-2025-11226 fixed)
- **Jackson**: 2.18.6 (GHSA-72hv-8253-57qq fixed)

### Adaptador Jakarta JMS

**IBM MQ allclient** proporciona `javax.jms` (JMS 2.0), pero **Spring Boot 3.x** requiere `jakarta.jms` (JMS 3.x).

El módulo `ba-mq-ibm` incluye un **adaptador dinámico con Proxy** que convierte:
```
javax.jms.ConnectionFactory → jakarta.jms.ConnectionFactory
```

Sin necesidad de cambiar dependencias o código de IBM MQ.

---

## Arquitectura

```
┌─────────────────────────────────────────┐
│  Spring Boot Application                │
│  (Tu aplicación)                        │
└──────────────────┬──────────────────────┘
                   │
                   ↓ inyecta
┌─────────────────────────────────────────┐
│  ba-mq-spring-boot-starter              │
│  (Autoconfiguración + Propiedades)      │
└──────────────────┬──────────────────────┘
                   │
        ┌──────────┴──────────┐
        ↓                     ↓
┌────────────────┐   ┌────────────────┐
│  ba-mq-rabbit  │   │  ba-mq-ibm     │
│  + RabbitMQ    │   │  + IBM MQ      │
│  + AMQP        │   │  + JMS + Proxy │
└────────┬───────┘   └────────┬───────┘
         │                     │
         ↓                     ↓
    RabbitMQ              IBM MQ
   (Broker)             (Broker)
```

---

## Testing

La librería incluye tests completos:

- **Tests Unitarios**: Validación de modelos y lógica
- **Tests de Integración**: ba-mq-ibm, ba-mq-rabbit con brokers reales
- **Tests de Cobertura**: Jacoco reports para cada módulo

```bash
# Ver cobertura de un módulo
./gradlew ba-mq-core:jacocoTestReport
# Abre: ba-mq-core/build/reports/jacoco/test/html/index.html
```

---

## Versiones y Compatibilidad

### Versiones Verificadas

Este proyecto ha sido probado y funciona correctamente con:

- **JDK**: Java 21 (OpenJDK)
- **Gradle**: 8.14.3
- **Spring Boot**: 3.5.14 LTS
- **Maven**: Para publicación en Artifactory

### Compatibilidad de Brokers

| Broker | Versión Mínima | Probado en |
|--------|---|---|
| **RabbitMQ** | 3.8+ | 4.x |
| **IBM MQ** | 9.2+ | 9.4.0.0 |

---

## Responsabilidades del Desarrollador

Al usar **ba-mq**, debes:

1. Inyectar `MQClient` en tus servicios
2. Publicar mensajes con estructura clara (payload + metadata)
3. Implementar suscriptores para procesar mensajes
4. Manejar excepciones `MQException` adecuadamente
5. Configurar las propiedades del broker en `application.yml`
6. Implementar serialización custom si es necesario

---

## Autores y Contribución

**Proyecto**: CrossChannel MQ - ba-mq  
**Versión**: 0.1.0-SNAPSHOT  
**Fecha**: Mayo 2026  
**Responsable**: Alejandro Jose Aragon (aaragon@bancoagricola.com.sv)

---

## Recursos Adicionales

- [Jakarta JMS 3.0 Specification](https://jakarta.ee/specifications/messaging/3.0/)
- [RabbitMQ Documentation](https://www.rabbitmq.com/documentation.html)
- [IBM MQ Documentation](https://www.ibm.com/products/mq)
- [Spring AMQP Reference](https://spring.io/projects/spring-amqp)
- [Spring JMS Reference](https://spring.io/projects/spring-framework)
