
# Descripción del repositorio 📝

# Utilidades - Cross Channel

## 📋 Descripción

Este proyecto implementa un conjunto de clases utilitarias diseñadas para agilizar el desarrollo, mejorar la reutilización del código y reducir la duplicación de funcionalidades comunes.

## 🝗︝ Estructura del Proyecto

```
sv.ba
└── utils
    ├── documents
    │   └── (validaciones de documentos)
    │
    ├── enums
    │   └── (tipos y constantes de documentos)
    │
    ├── exceptions
    │   └── (excepciones de validación)
    │
    └── common
        ├── Base64Util
        ├── CapitalizableWords
        ├── DateUtil
        ├── EmailUtil
        ├── FileUtil
        ├── NumberUtil
        ├── RandomHashUtil
        └── StringUtils
```

## 🎯 Descripción de clases utilitarias

Este módulo agrupa un conjunto de clases utilitarias diseñadas para la validación, transformación y formateo de datos en aplicaciones empresariales, promoviendo reutilización, consistencia y buenas prácticas de desarrollo.

### 1. **ValidateDUINITUtils**
Componente utilitario orientado a la validación de identificadores oficiales salvadoreños, específicamente DUI y NIT, asegurando el cumplimiento de reglas estructurales y de integridad definidas.

**Validaciones principales (DUI):**
- Presencia y no vaciedad del valor
- Formato estructurado `(########-#)`
- Longitud exacta de 9 dígitos
- Contenido exclusivamente numérico
- Validación del dígito verificador mediante algoritmo base 10

**Validaciones principales (NIT):**
- Presencia y no vaciedad del valor
- Formato estructurado `(####-######-###-#)`
- Longitud exacta de 14 dígitos
- Contenido exclusivamente numérico

**Características:**
- Uso de objeto `ValidationResult` para encapsular resultado y mensaje
- Mensajes descriptivos orientados a usuario final
- Validación progresiva por etapas
- Aplicación de lógica algorítmica para verificación de integridad (DUI)
- Enfoque en calidad de datos y cumplimiento de formatos oficiales

### 2. **CapitalizeWords**
Componente utilitario orientado a la estandarización de texto mediante la capitalización de la primera letra de cada palabra.

**Características principales:**
- Conversión previa del texto a minúsculas
- Capitalización de la primera letra por cada palabra
- Separación de palabras basada en espacios
- Manejo seguro de valores `null` o vacíos

**Casos de uso:**
- Normalización de nombres y etiquetas
- Mejora de legibilidad en interfaces de usuario
- Formateo de datos de entrada

### 3. **DateUtil**
Componente utilitario orientado a la transformación y estandarización de fechas en múltiples formatos.

**Capacidades principales:**
- Soporte para múltiples formatos `ISO-8601`
- Conversión automática a `ZonedDateTime`
- Formateo personalizado mediante patrones
- Formato por defecto localizado en español

**Características:**
- Estrategia de parseo resiliente
- Manejo de fechas con/sin zona horaria
- Normalización de entradas heterogéneas
- Validación mediante excepciones controladas

### 4. **EmailUtil**
Componente utilitario especializado en la validación estructural de direcciones de correo electrónico.

**Validaciones principales:**

- Presencia y unicidad del símbolo `@`
- Integridad de la parte local
- Estructura válida del dominio
- Validación mediante expresiones regulares

**Características:**

- Mensajes de error descriptivos (no solo booleanos)
- Validación progresiva por etapas
- Mejora de trazabilidad de errores
- Enfoque orientado a experiencia de usuario

### 5. **FileUtil**

Componente utilitario orientado a la validación integral de archivos en procesos de carga y procesamiento.

**Validaciones principales:**
- Extensión del archivo
- Tipo MIME
- Firma binaria (magic numbers)
- Existencia del archivo

**Características:**
- Lectura parcial del `InputStream` (optimización de rendimiento)
- Prevención de suplantación de archivos
- Manejo de errores mediante excepciones específicas


### 6. **NumberUtil**
Componente utilitario enfocado en la manipulación, validación y formateo de valores numéricos.

**Funcionalidades principales:**
- Redondeo de valores con precisión controlada
- Formateo de moneda basado en `Locale`
- Validación de cadenas numéricas

**Características:**
- Uso de `BigDecimal` con `RoundingMode.HALF_UP`
- Soporte para contextos financieros
- Compatibilidad con formatos internacionales
- Validación mediante expresiones regulares

### 7. **RandomHasUtil**
Componente utilitario diseñado para la generación de identificadores únicos aleatorios.

**Características principales:**
- Generación de `UUID` estándar
- Alta unicidad sin coordinación externa
- Formato string listo para uso

**Casos de uso:**
- Identificadores de registros
- Tokens y referencias internas
- Correlación de eventos en sistemas distribuidos

### 8. **StringUtils**
Componente utilitario orientado a la manipulación y normalización de texto.

**Funcionalidades principales:**
- Eliminación de espacios innecesarios
- Normalización de acentos y caracteres especiales
- Generación de `slugs` para URLs

**Características:**
- Uso de Normalizer para manejo de diacríticos
- Estandarización a minúsculas
- Generación de identificadores amigables para SEO
- Mejora de interoperabilidad entre sistemas


## 📚 Tecnologías Utilizadas

[Breve descripción del repositorio que destaque su propósito y utilidad.]

- **Java 21**: Lenguaje de programación
- **JUnit 5**: Testing
## 🧪 Testing

# Tecnologías Utilizadas ⚡

La arquitectura facilita diferentes tipos de tests:

Enumera las principales tecnologías, lenguajes de programación, frameworks o herramientas que se utilizan en el repositorio. Esta sección proporciona una visión general de la pila tecnológica utilizada.

- **Tests Unitarios**: Todas las clases de utilería (sin dependencias externas)
[Ejemplo:
## 🔧 Comandos Gradle

- Java
- Spring Boot
]

### Compilar el Proyecto
```bash
# Windows
.\gradlew clean build
# Linux/Mac
./gradlew clean build
```

# Estructura del proyecto 🧬
### Ejecutar la Aplicación
```bash
# Windows
.\gradlew bootRun
**Recomendación:** Para la creación del árbol de la estructura del proyecto usar el comando `tree` en la raíz del repositorio.
# Linux/Mac
./gradlew bootRun
```
Estando en la raíz del repositorio, usar el comando `tree | clip`, el cual crea el árbol de la estructura y automáticamente lo copia en tu portapapeles.

### Refrescar Dependencias
```bash
# Windows - Forzar descarga de dependencias
.\gradlew build --refresh-dependencies

Añadir el árbol de la estructura al README y modificarlo para que el nombre del repositorio esté en la cabeza.
# Linux/Mac
./gradlew build --refresh-dependencies
```
[**Ejemplo** (Actualizar el árbol de la estructura existente a la del repositorio):

### Ejecutar Tests
```bash
# Windows
.\gradlew test

# Linux/Mac
./gradlew test


### Limpiar Build
```bash
# Windows
.\gradlew clean

# Linux/Mac
./gradlew clean

### Generar Reporte de Cobertura (Jacoco)
```bash
# Windows
.\gradlew test jacocoTestReport
# Linux/Mac
./gradlew test jacocoTestReport
```
*El reporte se genera en: `build/reports/jacoco/test/html/index.html`*
### Análisis de Código con SonarQube
```bash
# Windows
.\gradlew sonarqube
Instrucciones paso a paso para instalar y ejecutar el proyecto.
# Linux/Mac
./gradlew sonarqube
```

### Ver Todas las Tareas Disponibles
```bash
# Windows
.\gradlew tasks

# Linux/Mac
./gradlew tasks
```

### Comandos Útiles Combinados
```bash
# Limpiar, compilar y ejecutar tests
.\gradlew clean build test
# Limpiar, compilar y ejecutar la aplicación
.\gradlew clean build bootRun
```
## 🔧 Versiones y Compatibilidad

### Versiones Verificadas

Este proyecto ha sido probado y funciona correctamente con las siguientes versiones locales:

- **JDK**: Java 21.0.3
- **Gradle**: 9.3.1

**Autor**: ccorvera@bancoagricola.com.sv
**Versión**: 0.0.1-SNAPSHOT  
**Fecha**: 2026