package sv.ba.utils.documents;

/**
 * Representa el resultado de una validación.
 *
 * <p>
 * Contiene el estado de la validación (válido o no válido)
 * y un mensaje descriptivo que explica el resultado.
 * </p>
 *
 * <p>
 * Esta clase es utilizada por las utilidades de validación
 * de documentos como DUI y NIT.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class ValidationResult {

    /**
     * Indica si la validación fue exitosa.
     */
    private final boolean valid;

    /**
     * Mensaje descriptivo del resultado de la validación.
     */
    private final String message;

    /**
     * Crea una nueva instancia de {@code ValidationResult}.
     *
     * @param valid   {@code true} si la validación es correcta,
     *                {@code false} en caso contrario
     * @param message mensaje descriptivo del resultado
     */
    public ValidationResult(boolean valid, String message) {
        this.valid = valid;
        this.message = message;
    }

    /**
     * Indica si la validación fue exitosa.
     *
     * @return {@code true} si es válida, {@code false} si no lo es
     */
    public boolean isValid() {
        return valid;
    }

    /**
     * Obtiene el mensaje descriptivo del resultado de la validación.
     *
     * @return mensaje del resultado
     */
    public String getMessage() {
        return message;
    }
}