package sv.ba.utils.common;

import java.util.UUID;

/**
 * Clase utilitaria para la generación de identificadores únicos.
 *
 * <p>
 * Utiliza {@link UUID} para generar valores aleatorios únicos
 * que pueden ser usados como hashes, identificadores temporales
 * o tokens no sensibles.
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class RandomHashUtil {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private RandomHashUtil() {
    }

    /**
     * Genera un identificador único aleatorio.
     *
     * <p>
     * El valor generado tiene el formato estándar de un {@link UUID},
     * por ejemplo:
     * </p>
     *
     * <pre>
     * 550e8400-e29b-41d4-a716-446655440000
     * </pre>
     *
     * @return identificador único generado como {@link String}
     */
    public static String generate() {
        return UUID.randomUUID().toString();
    }
}