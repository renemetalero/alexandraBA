package sv.ba.utils.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import sv.ba.utils.enums.FileType;
import sv.ba.utils.exceptions.FileValidationException;

/**
 * Clase utilitaria para validación de archivos basada en:
 * <ul>
 *     <li>Extensión del archivo</li>
 *     <li>Tipo MIME</li>
 *     <li>Firma binaria (magic number)</li>
 * </ul>
 *
 * <p>
 * Esta validación permite asegurar que el archivo recibido
 * corresponde realmente al tipo esperado, evitando validaciones
 * basadas únicamente en la extensión o el MIME.
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class FileUtil {

    /**
     * Constructor con visibilidad por defecto para evitar
     * la instanciación externa.
     */
    FileUtil() {
    }

    /**
     * Valida un archivo recibido a través de un {@link InputStream}.
     *
     * <p>
     * Validaciones realizadas:
     * <ul>
     *     <li>El archivo no debe ser nulo</li>
     *     <li>La extensión del archivo debe coincidir con el tipo esperado</li>
     *     <li>El tipo MIME debe coincidir con el tipo esperado</li>
     *     <li>La firma binaria del archivo debe corresponder al tipo indicado</li>
     * </ul>
     * </p>
     *
     * <p>
     * Este método solo lee los primeros bytes necesarios para validar
     * la firma binaria, sin consumir completamente el {@code InputStream}.
     * </p>
     *
     * @param inputStream flujo de entrada del archivo
     * @param fileName nombre original del archivo
     * @param contentType tipo MIME del archivo
     * @param type tipo de archivo esperado {@link FileType}
     *
     * @throws IllegalArgumentException si la extensión o el tipo MIME
     *                                  no son correctos, o si el archivo es nulo
     * @throws FileValidationException si la firma binaria no coincide
     *                                 o si ocurre un error de lectura
     */
    public static void validateFile(
            InputStream inputStream,
            String fileName,
            String contentType,
            FileType type) {

        if (inputStream == null) {
            throw new IllegalArgumentException("El archivo está vacío");
        }

        if (fileName == null || !fileName.toLowerCase().endsWith(getExtension(type))) {
            throw new IllegalArgumentException(
                    "Extensión incorrecta. Se esperaba: " + getExtension(type));
        }

        if (!type.getMimeType().equalsIgnoreCase(contentType)) {
            throw new IllegalArgumentException(
                    "Tipo MIME incorrecto. Se esperaba: " + type.getMimeType());
        }

        try {
            byte[] fileHeader = inputStream.readNBytes(type.getSignature().length);

            if (!Arrays.equals(fileHeader, type.getSignature())) {
                throw new FileValidationException(
                        "El archivo no coincide con el tipo esperado");
            }

        } catch (IOException e) {
            throw new FileValidationException("Error leyendo archivo", e);
        }
    }

    /**
     * Obtiene la extensión esperada para un tipo de archivo.
     *
     * @param type tipo de archivo {@link FileType}
     * @return extensión asociada al tipo
     */
    private static String getExtension(FileType type) {
        return switch (type) {
            case PDF -> ".pdf";
            case PNG -> ".png";
            case JPG -> ".jpg";
        };
    }
}