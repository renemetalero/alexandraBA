package sv.ba.utils.common;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Clase utilitaria para codificación y decodificación en Base64.
 *
 * <p>
 * Proporciona métodos estáticos para trabajar con cadenas de texto
 * y arreglos de bytes utilizando la codificación Base64 estándar
 * definida en RFC 4648.
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public final class Base64Util {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private Base64Util() {
    }

    /* ============ STRING ============ */

    /**
     * Codifica una cadena de texto en Base64 utilizando UTF-8.
     *
     * @param text texto a codificar
     * @return texto codificado en Base64.
     * Retorna una cadena vacía si el parámetro es {@code null} o vacío.
     */
    public static String encode(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        return Base64.getEncoder()
                .encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Decodifica una cadena Base64 a texto utilizando UTF-8.
     *
     * @param base64 texto codificado en Base64
     * @return texto decodificado.
     * Retorna una cadena vacía si el parámetro es {@code null} o vacío.
     *
     * @throws IllegalArgumentException si la cadena Base64 no es válida
     */
    public static String decode(String base64) {
        if (base64 == null || base64.isEmpty()) {
            return "";
        }
        byte[] decoded = Base64.getDecoder().decode(base64);
        return new String(decoded, StandardCharsets.UTF_8);
    }

    /* ============ BYTES ============ */

    /**
     * Codifica un arreglo de bytes en una cadena Base64.
     *
     * @param data arreglo de bytes a codificar
     * @return representación en Base64 del arreglo de bytes.
     * Retorna una cadena vacía si el arreglo es {@code null} o vacío.
     */
    public static String encode(byte[] data) {
        if (data == null || data.length == 0) {
            return "";
        }
        return Base64.getEncoder().encodeToString(data);
    }

    /**
     * Decodifica una cadena Base64 a un arreglo de bytes.
     *
     * @param base64 texto codificado en Base64
     * @return arreglo de bytes decodificado.
     * Retorna un arreglo vacío si el parámetro es {@code null} o vacío.
     *
     * @throws IllegalArgumentException si la cadena Base64 no es válida
     */
    public static byte[] decodeToBytes(String base64) {
        if (base64 == null || base64.isEmpty()) {
            return new byte[0];
        }
        return Base64.getDecoder().decode(base64);
    }
}
