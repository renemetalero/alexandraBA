package sv.ba.utils.common;

import java.text.Normalizer;

/**
 * Clase utilitaria para manipulación y normalización de cadenas de texto.
 *
 * <p>
 * Proporciona métodos para:
 * <ul>
 *     <li>Eliminar espacios en blanco innecesarios</li>
 *     <li>Normalizar texto eliminando acentos</li>
 *     <li>Generar slugs amigables para URLs</li>
 * </ul>
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class StringUtils {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private StringUtils() {
    }

    /**
     * Elimina espacios en blanco innecesarios de un texto.
     *
     * <p>
     * Aplica las siguientes reglas:
     * <ul>
     *     <li>Elimina espacios al inicio y al final</li>
     *     <li>Reemplaza múltiples espacios internos por un solo espacio</li>
     * </ul>
     * </p>
     *
     * @param text texto a procesar
     * @return texto sin espacios innecesarios,
     *         o {@code null} si el valor de entrada es {@code null}
     */
    public static String removeExtraSpaces(String text) {
        if (text == null) {
            return null;
        }
        return text.trim().replaceAll("\\s+", " ");
    }

    /**
     * Normaliza un texto eliminando acentos y diacríticos.
     *
     * <p>
     * Utiliza {@link Normalizer} con la forma {@code NFD} para separar
     * los caracteres base de sus acentos y posteriormente eliminarlos.
     * </p>
     *
     * <p>
     * Ejemplo:
     * <pre>
     * Entrada:  "Canción Número Uno"
     * Salida:   "Cancion Numero Uno"
     * </pre>
     * </p>
     *
     * @param text texto a normalizar
     * @return texto sin acentos,
     *         o {@code null} si el valor de entrada es {@code null}
     */
    public static String normalize(String text) {
        if (text == null) {
            return null;
        }

        String normalized = Normalizer.normalize(text, Normalizer.Form.NFD);
        return normalized.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }

    /**
     * Genera un {@code slug} amigable para URLs a partir de un texto.
     *
     * <p>
     * El proceso incluye:
     * <ul>
     *     <li>Eliminar acentos</li>
     *     <li>Convertir a minúsculas</li>
     *     <li>Eliminar caracteres especiales</li>
     *     <li>Reemplazar espacios por guiones</li>
     * </ul>
     * </p>
     *
     * <p>
     * Ejemplo:
     * <pre>
     * Entrada:  "Título de Ejemplo 2026"
     * Salida:   "titulo-de-ejemplo-2026"
     * </pre>
     * </p>
     *
     * @param text texto a convertir en slug
     * @return slug generado,
     *         o {@code null} si el valor de entrada es {@code null}
     */
    public static String toSlug(String text) {
        if (text == null) {
            return null;
        }

        String noAccents = normalize(text);
        return noAccents
                .toLowerCase()
                .trim()
                .replaceAll("[^a-z0-9\\s-]", "")
                .replaceAll("\\s+", "-");
    }
}