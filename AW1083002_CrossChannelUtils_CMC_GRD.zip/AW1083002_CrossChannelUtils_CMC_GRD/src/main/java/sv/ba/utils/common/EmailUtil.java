package sv.ba.utils.common;

/**
 * Clase utilitaria para validación básica de direcciones de correo electrónico.
 *
 * <p>
 * Realiza validaciones estructurales comunes sobre una dirección de correo,
 * devolviendo mensajes descriptivos que explican el motivo de la invalidación.
 * </p>
 *
 * <p>
 * Esta clase no implementa la especificación completa de RFC 5322,
 * pero cubre los casos más comunes utilizados en aplicaciones empresariales.
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class EmailUtil {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private EmailUtil() {
    }

    /**
     * Valida una dirección de correo electrónico.
     *
     * <p>
     * Se valida:
     * <ul>
     *     <li>Que no sea nula ni vacía</li>
     *     <li>Que contenga un único símbolo '@'</li>
     *     <li>Formato válido de la parte local</li>
     *     <li>Formato válido del dominio</li>
     * </ul>
     * </p>
     *
     * <p>
     * En caso de error, se retorna un mensaje descriptivo indicando
     * la causa exacta de la invalidación.
     * </p>
     *
     * @param email dirección de correo electrónico a validar
     * @return {@code "OK"} si el correo es válido;
     *         de lo contrario, un mensaje explicando el error encontrado
     */
    public static String isValidEmail(String email) {

        if (email == null || email.isBlank()) {
            return "El correo no puede estar vacío. Ejemplo válido: usuario@dominio.com";
        }

        if (!email.contains("@")) {
            return "Falta el símbolo '@'. Ejemplo: usuario@dominio.com";
        }

        String[] parts = email.split("@", -1);

        if (parts.length != 2) {
            return "El correo debe tener un solo '@'. Ejemplo: usuario@dominio.com";
        }

        String localPart = parts[0];
        String domainPart = parts[1];

        if (localPart.isBlank()) {
            return "La parte antes de '@' no puede estar vacía. Ejemplo: usuario@dominio.com";
        }

        if (!localPart.matches("^[A-Za-z0-9+_.-]+$")) {
            return "La parte antes de '@' contiene caracteres inválidos. "
                    + "Solo se permiten letras, números y + _ . -";
        }

        if (domainPart.isBlank()) {
            return "El dominio no puede estar vacío. Ejemplo: usuario@dominio.com";
        }

        if (!domainPart.contains(".")) {
            return "El dominio debe contener un punto. Ejemplo: usuario@dominio.com";
        }

        if (!domainPart.matches("^[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            return "El dominio no es válido. Ejemplo correcto: dominio.com";
        }

        return "OK";
    }
}