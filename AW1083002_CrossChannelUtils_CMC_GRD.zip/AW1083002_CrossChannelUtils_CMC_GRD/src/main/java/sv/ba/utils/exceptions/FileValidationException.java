package sv.ba.utils.exceptions;

/**
 * Excepción lanzada cuando ocurre un error durante la validación de archivos.
 *
 * <p>
 * Esta excepción se utiliza para representar errores asociados a:
 * <ul>
 *     <li>Tipo de archivo no soportado</li>
 *     <li>Firma binaria inválida (magic number)</li>
 *     <li>Contenido de archivo inconsistente</li>
 * </ul>
 * </p>
 *
 * <p>
 * Es una excepción no comprobada ({@link RuntimeException}), pensada
 * para ser utilizada dentro de utilidades de validación de archivos
 * sin forzar el manejo explícito por parte del consumidor de la librería.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class FileValidationException extends RuntimeException {

    /**
     * Crea una nueva {@code FileValidationException} con un mensaje descriptivo.
     *
     * @param message mensaje que describe la causa del error de validación
     */
    public FileValidationException(String message) {
        super(message);
    }

    /**
     * Crea una nueva {@code FileValidationException} con un mensaje descriptivo
     * y una causa raíz.
     *
     * @param message mensaje que describe la causa del error de validación
     * @param cause   excepción original que provocó el error
     */
    public FileValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
