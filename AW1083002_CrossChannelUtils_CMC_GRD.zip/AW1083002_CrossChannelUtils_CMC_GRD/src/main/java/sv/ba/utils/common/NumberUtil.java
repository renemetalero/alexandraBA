package sv.ba.utils.common;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Clase utilitaria para operaciones y validaciones numéricas comunes.
 *
 * <p>
 * Proporciona métodos para:
 * <ul>
 *     <li>Redondeo de valores decimales</li>
 *     <li>Formato de números como moneda</li>
 *     <li>Validación de cadenas numéricas</li>
 * </ul>
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class NumberUtil {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private NumberUtil() {
    }

    /**
     * Redondea un valor {@code double} a una cantidad específica de decimales.
     *
     * <p>
     * Utiliza {@link RoundingMode#HALF_UP}, el método de redondeo
     * más común en contextos financieros.
     * </p>
     *
     * @param value  valor numérico a redondear
     * @param places cantidad de decimales
     * @return valor redondeado con la cantidad de decimales indicada
     *
     * @throws ArithmeticException si {@code places} es negativo
     */
    public static double round(double value, int places) {
        return BigDecimal.valueOf(value)
                .setScale(places, RoundingMode.HALF_UP)
                .doubleValue();
    }

    /**
     * Formatea un valor numérico como moneda según la localización indicada.
     *
     * <p>
     * El formato incluye símbolo de moneda, separadores de miles
     * y decimales según el {@link Locale}.
     * </p>
     *
     * @param value  valor numérico a formatear
     * @param locale configuración regional utilizada para el formato
     * @return valor formateado como moneda
     */
    public static String formatCurrency(double value, Locale locale) {
        NumberFormat formatter = NumberFormat.getCurrencyInstance(locale);
        return formatter.format(value);
    }

    /**
     * Indica si una cadena representa un valor numérico válido.
     *
     * <p>
     * Acepta números enteros y decimales, positivos o negativos.
     * </p>
     *
     * <p>
     * Ejemplos válidos:
     * <pre>
     *  "123"
     *  "-45"
     *  "12.50"
     * </pre>
     * </p>
     *
     * @param value texto a validar
     * @return {@code true} si la cadena representa un número válido,
     *         {@code false} en caso contrario
     */
    public static boolean isNumeric(String value) {
        if (value == null || value.isBlank()) {
            return false;
        }
        return value.matches("-?\\d+(\\.\\d+)?");
    }
}