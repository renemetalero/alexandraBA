package sv.ba.utils.common;

/**
 * Clase utilitaria para capitalizar palabras dentro de una cadena de texto.
 *
 * <p>
 * Convierte el texto a minúsculas y capitaliza la primera letra
 * de cada palabra, separada por espacios.
 * </p>
 *
 * <p>
 * Ejemplo:
 * <pre>
 * Entrada:  "hOLa mUnDo"
 * Salida:   "Hola Mundo"
 * </pre>
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class CapitalizeWords {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private CapitalizeWords() {
    }

    /**
     * Capitaliza la primera letra de cada palabra en un texto.
     *
     * <p>
     * El texto es convertido previamente a minúsculas.
     * Las palabras se detectan utilizando el espacio como separador.
     * </p>
     *
     * @param text texto a capitalizar
     * @return texto con la primera letra de cada palabra en mayúscula.
     * Retorna el mismo valor si el texto es {@code null} o está en blanco.
     */
    public static String capitalize(String text) {
        if (text == null || text.isBlank()) {
            return text;
        }

        String[] words = text.toLowerCase().split(" ");
        StringBuilder result = new StringBuilder();

        for (String word : words) {
            if (!word.isEmpty()) {
                result.append(word.substring(0, 1).toUpperCase())
                        .append(word.substring(1))
                        .append(" ");
            }
        }

        return result.toString().trim();
    }
}