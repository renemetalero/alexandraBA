package sv.ba.utils.documents;
/**
 * Clase utilitaria para la validación de documentos de identificación
 * de El Salvador: DUI y NIT.
 *
 * <p>
 * Proporciona métodos estáticos para validar
 * y consistencia (en el caso del DUI, el dígito verificador).
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 */
public class ValidateDUINITUtils {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private ValidateDUINITUtils() {
    }

    /**
     * Valida un número de DUI (Documento Único de Identidad).
     *
     * <p>
     * El formato correcto es: ########-#
     * (ejemplo: 12345678-9).
     * </p>
     *
     * <p>
     * Validaciones realizadas:
     * <ul>
     *     <li>No nulo ni vacío</li>
     *     <li>Formato correcto</li>
     *     <li>Longitud exacta de 9 dígitos</li>
     *     <li>Verificación del dígito verificador</li>
     * </ul>
     * </p>
     *
     * @param dui el número de DUI a validar
     * @return {@link ValidationResult} con el resultado de la validación
     * y un mensaje descriptivo
     */
    public static ValidationResult validateDUI(String dui) {

        if (dui == null || dui.isBlank()) {
            return new ValidationResult(false,
                    "El DUI está vacío. Formato correcto: 12345678-9");
        }

        String clean = dui.replace("-", "");

        if (!clean.matches("\\d+")) {
            return new ValidationResult(false,
                    "El DUI solo debe contener números. Ejemplo: 12345678-9");
        }

        if (clean.length() < 9) {
            return new ValidationResult(false,
                    "Faltan " + (9 - clean.length()) + " dígitos. Formato: 12345678-9");
        }

        if (clean.length() > 9) {
            return new ValidationResult(false,
                    "Tiene " + clean.length() + " dígitos, pero el máximo es 9. Formato: 12345678-9");
        }

        if (!dui.matches("\\d{8}-\\d")) {
            return new ValidationResult(false,
                    "Formato incorrecto. Debe ser ########-#. Ejemplo: 12345678-9");
        }

        int sum = 0;
        for (int i = 0; i < 8; i++) {
            sum += Character.getNumericValue(clean.charAt(i)) * (9 - i);
        }

        int checkDigit = (10 - (sum % 10)) % 10;
        int providedDigit = Character.getNumericValue(clean.charAt(8));

        if (checkDigit != providedDigit) {
            return new ValidationResult(false,
                    "Dígito verificador incorrecto. Se esperaba: " + checkDigit);
        }

        return new ValidationResult(true, "DUI válido");
    }

    /**
     * Valida un número de NIT (Número de Identificación Tributaria).
     *
     * <p>
     * El formato correcto es: ####-######-###-#
     * (ejemplo: 1234-123456-123-1).
     * </p>
     *
     * <p>
     * Validaciones realizadas:
     * <ul>
     *     <li>No nulo ni vacío</li>
     *     <li>Formato correcto</li>
     *     <li>Longitud exacta de 14 dígitos</li>
     * </ul>
     * </p>
     *
     * @param nit el número de NIT a validar
     * @return {@link ValidationResult} con el resultado de la validación
     * y un mensaje descriptivo
     */
    public static ValidationResult validateNIT(String nit) {

        if (nit == null || nit.isBlank()) {
            return new ValidationResult(false,
                    "El NIT está vacío. Formato correcto: 1234-123456-123-1");
        }

        String clean = nit.replace("-", "");

        if (!clean.matches("\\d+")) {
            return new ValidationResult(false,
                    "El NIT solo debe contener números. Ejemplo: 1234-123456-123-1");
        }

        if (clean.length() < 14) {
            return new ValidationResult(false,
                    "Faltan " + (14 - clean.length()) + " dígitos. Formato: 1234-123456-123-1");
        }

        if (clean.length() > 14) {
            return new ValidationResult(false,
                    "Tiene " + clean.length() + " dígitos, pero el máximo es 14. Formato: 1234-123456-123-1");
        }

        if (!nit.matches("\\d{4}-\\d{6}-\\d{3}-\\d")) {
            return new ValidationResult(false,
                    "Formato incorrecto. Debe ser ####-######-###-#. Ejemplo: 1234-123456-123-1");
        }

        return new ValidationResult(true, "NIT válido");
    }
}
