package sv.ba.utils.common;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;

/**
 * Clase utilitaria para el manejo flexible de fechas y horas.
 *
 * <p>
 * Permite interpretar fechas en distintos formatos estándar ISO
 * y devolverlas en un formato de salida configurable.
 * </p>
 *
 * <p>
 * Los formatos de entrada soportados incluyen fechas con zona horaria,
 * sin zona horaria y solo fechas.
 * </p>
 *
 * <p>
 * Esta clase no debe ser instanciada.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public class DateUtil {

    /**
     * Constructor privado para evitar la instanciación
     * de la clase utilitaria.
     */
    private DateUtil() {
    }

    /**
     * Lista de formatos ISO soportados para el parseo flexible de fechas.
     */
    private static final List<DateTimeFormatter> SUPPORTED_FORMATS = List.of(
            DateTimeFormatter.ISO_DATE_TIME,         // 2026-04-15T10:30:45Z
            DateTimeFormatter.ISO_ZONED_DATE_TIME,   // 2026-04-15T10:30:45-06:00
            DateTimeFormatter.ISO_LOCAL_DATE_TIME,   // 2026-04-15T10:30:45
            DateTimeFormatter.ISO_LOCAL_DATE         // 2026-04-15
    );

    /**
     * Formatea una fecha de entrada utilizando múltiples formatos ISO soportados.
     *
     * <p>
     * Si no se especifica un patrón de salida, se utiliza un formato
     * por defecto en español:
     * </p>
     *
     * <pre>
     * EEEE, d 'de' MMMM 'de' yyyy
     * </pre>
     *
     * <p>
     * Ejemplo de salida:
     * </p>
     *
     * <pre>
     * miércoles, 15 de abril de 2026
     * </pre>
     *
     * @param inputDate    fecha de entrada en un formato ISO soportado
     * @param outputPattern patrón de salida {@link DateTimeFormatter}.
     *                      Si es {@code null} o vacío se utilizará el patrón por defecto
     * @return fecha formateada como {@link String}
     *
     * @throws IllegalArgumentException si el formato de la fecha de entrada
     *                                  no es soportado
     */
    public static String formatFlexible(String inputDate, String outputPattern) {
        ZonedDateTime parsedDate = parseToZonedDateTime(inputDate);

        DateTimeFormatter outputFormatter;

        if (outputPattern == null || outputPattern.isBlank()) {
            outputFormatter = DateTimeFormatter
                    .ofPattern("EEEE, d 'de' MMMM 'de' yyyy", Locale.of("es", "ES"));
        } else {
            outputFormatter = DateTimeFormatter.ofPattern(outputPattern);
        }

        return parsedDate.format(outputFormatter);
    }

    /**
     * Intenta convertir una cadena de texto a {@link ZonedDateTime}
     * utilizando los formatos soportados.
     *
     * <p>
     * Estrategia de parseo:
     * <ul>
     *     <li>Intenta {@link ZonedDateTime}</li>
     *     <li>Intenta {@link LocalDateTime} usando la zona por defecto del sistema</li>
     *     <li>Intenta {@link LocalDate} al inicio del día</li>
     * </ul>
     * </p>
     *
     * @param input fecha de entrada como texto
     * @return fecha convertida a {@link ZonedDateTime}
     *
     * @throws IllegalArgumentException si ningún formato soportado
     *                                  puede interpretar la fecha
     */
    private static ZonedDateTime parseToZonedDateTime(String input) {

        for (DateTimeFormatter formatter : SUPPORTED_FORMATS) {
            try {
                return ZonedDateTime.parse(input, formatter);

            } catch (DateTimeParseException e) {
                try {
                    LocalDateTime ldt = LocalDateTime.parse(input, formatter);
                    return ldt.atZone(ZoneId.systemDefault());

                } catch (DateTimeParseException e2) {
                    try {
                        LocalDate ld = LocalDate.parse(input, formatter);
                        return ld.atStartOfDay(ZoneId.systemDefault());

                    } catch (DateTimeParseException ignored) {
                        // Continúa intentando con el siguiente formato
                    }
                }
            }
        }

        throw new IllegalArgumentException("Formato de fecha no soportado: " + input);
    }
}