package sv.ba.utils.enums;

/**
 * Enum que representa tipos de archivos soportados basados en su
 * tipo MIME y su firma binaria (magic number).
 *
 * <p>
 * La firma binaria permite validar el contenido real de un archivo,
 * evitando depender únicamente de la extensión o del MIME enviado
 * por el cliente.
 * </p>
 *
 * <p>
 * Este enum es utilizado por utilidades de validación de archivos
 * dentro de la librería.
 * </p>
 *
 * @author ---
 * @version 1.0
 * @since 1.0
 */
public enum FileType {

    /**
     * Documento PDF.
     * <p>Firma binaria: %PDF</p>
     */
    PDF("application/pdf", new byte[]{0x25, 0x50, 0x44, 0x46}),

    /**
     * Imagen PNG.
     * <p>Firma binaria: 89 50 4E 47</p>
     */
    PNG("image/png", new byte[]{(byte) 0x89, 0x50, 0x4E, 0x47}),

    /**
     * Imagen JPG / JPEG.
     * <p>Firma binaria: FF D8 FF</p>
     */
    JPG("image/jpeg", new byte[]{(byte) 0xFF, (byte) 0xD8, (byte) 0xFF});

    /**
     * Tipo MIME asociado al archivo.
     */
    private final String mimeType;

    /**
     * Firma binaria (magic number) utilizada para validar
     * el tipo real del archivo.
     */
    private final byte[] signature;

    /**
     * Constructor del enum {@code FileType}.
     *
     * @param mimeType  tipo MIME del archivo
     * @param signature firma binaria del archivo
     */
    FileType(String mimeType, byte[] signature) {
        this.mimeType = mimeType;
        this.signature = signature;
    }

    /**
     * Obtiene el tipo MIME asociado al archivo.
     *
     * @return tipo MIME
     */
    public String getMimeType() {
        return mimeType;
    }

    /**
     * Obtiene la firma binaria (magic number) del archivo.
     *
     * @return arreglo de bytes que representa la firma del archivo
     */
    public byte[] getSignature() {
        return signature;
    }
}
