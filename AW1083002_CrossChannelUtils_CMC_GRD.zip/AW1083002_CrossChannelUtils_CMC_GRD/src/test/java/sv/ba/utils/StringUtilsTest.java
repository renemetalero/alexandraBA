package sv.ba.utils;

import org.junit.jupiter.api.Test;
import sv.ba.utils.common.StringUtils;

import java.lang.reflect.Constructor;

import static org.junit.jupiter.api.Assertions.*;

class StringUtilsTest {

    /**
     * Valida que el metodo removeExtraSpaces
     * retorne null cuando el texto de entrada es null.
     * Regla cubierta:
     * - Manejo de valores null.
     */
    @Test
    void removeExtraSpacesConNull() {
        String result = StringUtils.removeExtraSpaces(null);
        assertNull(result);
    }

    /**
     * Valida que el metodo removeExtraSpaces
     * elimine espacios al inicio, al final
     * y reduzca múltiples espacios internos a uno solo.
     * Regla cubierta:
     * - Normalización de espacios.
     */
    @Test
    void removeExtraSpacesConMultiplesEspacios() {
        String result = StringUtils.removeExtraSpaces("   Hola     mundo   Java   ");
        assertEquals("Hola mundo Java", result);
    }

    /**
     * Valida que el metodo normalize
     * retorne null cuando el texto de entrada es null.
     * Regla cubierta:
     * - Manejo de valores null.
     */
    @Test
    void normalizeConNull() {
        String result = StringUtils.normalize(null);
        assertNull(result);
    }

    /**
     * Valida que el metodo normalize
     * elimine correctamente los acentos
     * y caracteres diacríticos del texto.
     * Regla cubierta:
     * - Normalización Unicode.
     */
    @Test
    void normalizeEliminaAcentos() {
        String result = StringUtils.normalize("Árbol, niño, corazón, acción");
        assertEquals("Arbol, nino, corazon, accion", result);
    }

    /**
     * Valida que el metodo normalize
     * no altere un texto que ya
     * no contiene acentos.
     * Regla cubierta:
     * - Texto sin cambios.
     */
    @Test
    void normalizeSinAcentos() {
        String result = StringUtils.normalize("Texto plano");
        assertEquals("Texto plano", result);
    }

    /**
     * Valida que el metodo toSlug
     * retorne null cuando el texto de entrada es null.
     * Regla cubierta:
     * - Manejo de valores null.
     */
    @Test
    void toSlugConNull() {
        String result = StringUtils.toSlug(null);
        assertNull(result);
    }

    /**
     * Valida que el metodo toSlug:
     * - elimine acentos
     * - convierta a minúsculas
     * - remueva caracteres especiales
     * - reemplace espacios por guiones
     * Regla cubierta:
     * - Generación correcta de slug.
     */
    @Test
    void toSlugTextoComplejo() {
        String result = StringUtils.toSlug("  Hola Mundo! Árbol & Java  ");
        assertEquals("hola-mundo-arbol-java", result);
    }

    /**
     * Valida que el metodo toSlug
     * funcione correctamente con
     * texto simple sin símbolos ni acentos.
     * Regla cubierta:
     * - Flujo normal sin transformaciones complejas.
     */
    @Test
    void toSlugTextoSimple() {
        String result = StringUtils.toSlug("Java Util Test");
        assertEquals("java-util-test", result);
    }

    /**
     * Valida el constructor privado de la clase
     * usando reflexión para garantizar cobertura total.
     * Regla cubierta:
     * - Constructor privado de clase utilitaria.
     */
    @Test
    void constructorPrivadoDebeSerInvocablePorReflection() throws Exception {
        Constructor<StringUtils> constructor =
                StringUtils.class.getDeclaredConstructor();

        constructor.setAccessible(true);

        StringUtils instance = constructor.newInstance();
        assertNotNull(instance);
    }
}