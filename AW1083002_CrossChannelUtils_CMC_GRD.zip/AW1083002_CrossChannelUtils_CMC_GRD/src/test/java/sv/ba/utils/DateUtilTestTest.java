package sv.ba.utils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import sv.ba.utils.common.DateUtil;

import static org.junit.jupiter.api.Assertions.*;
import static sv.ba.utils.common.DateUtil.formatFlexible;

class DateUtilTestTest {

    /**
     * ===============================
     * Pruebas de casos exitosos
     * ===============================
     * Este bloque agrupa los escenarios donde la fecha de entrada
     * tiene un formato válido y el metodo debe devolver el resultado
     * correctamente formateado según el patrón indicado.
     */
    @Nested
    @DisplayName("Casos válidos de formateo")
    class ValidCases {

        /**
         * Verifica que el metodo formatFlexible
         * soporte correctamente fechas en formato ISO_DATE_TIME
         * (ejemplo: 2026-04-15T10:30:45Z) y permita formatearlas
         * al patrón solicitado.
         */
        @Test
        @DisplayName("Debe formatear ISO_DATE_TIME correctamente")
        void shouldFormatIsoDateTime() {
            String input = "2026-04-15T10:30:45Z";

            String result = formatFlexible(input, "yyyy-MM-dd");

            assertEquals("2026-04-15", result);
        }

        /**
         * Verifica que el metodo formatee correctamente fechas
         * en formato ISO_ZONED_DATE_TIME, considerando la zona horaria
         * incluida en el valor de entrada.
         */
        @Test
        @DisplayName("Debe formatear ISO_ZONED_DATE_TIME correctamente")
        void shouldFormatIsoZonedDateTime() {
            String input = "2026-04-15T10:30:45-06:00";

            String result = formatFlexible(input, "yyyy-MM-dd HH:mm");

            assertEquals("2026-04-15 10:30", result);
        }

        /**
         * Verifica que el metodo soporte correctamente fechas
         * en formato ISO_LOCAL_DATE_TIME, es decir, sin zona horaria.
         */
        @Test
        @DisplayName("Debe formatear ISO_LOCAL_DATE_TIME correctamente")
        void shouldFormatLocalDateTime() {
            String input = "2026-04-15T10:30:45";

            String result = formatFlexible(input, "yyyy-MM-dd HH:mm");

            assertEquals("2026-04-15 10:30", result);
        }

        /**
         * Verifica que el metodo soporte fechas en formato ISO_LOCAL_DATE
         * (solo fecha, sin información de hora) y las devuelva
         * correctamente formateadas.
         */
        @Test
        @DisplayName("Debe formatear ISO_LOCAL_DATE correctamente")
        void shouldFormatLocalDate() {
            String input = "2026-04-15";

            String result = formatFlexible(input, "yyyy-MM-dd");

            assertEquals("2026-04-15", result);
        }
    }

    /**
     * ===============================
     * Uso de patrón por defecto
     * ===============================
     * Este bloque valida que el metodo utilice un patrón por defecto
     * cuando el patrón recibido es:
     * - null
     * - vacío
     * - solo espacios en blanco
     */
    @Nested
    @DisplayName("Uso de patrón por defecto")
    class DefaultPattern {

        /**
         * Verifica que cuando el patrón es null, vacío o blank,
         * el metodo no falle y utilice un patrón por defecto
         * para devolver una fecha válida.
         */
        @ParameterizedTest
        @NullAndEmptySource
        @ValueSource(strings = {"   "})
        void shouldUseDefaultPatternWhenPatternIsNullEmptyOrBlank(String pattern) {
            String input = "2026-04-15";

            String result = DateUtil.formatFlexible(input, pattern);

            // Se valida indirectamente que el resultado sea correcto
            // verificando que contenga el año esperado
            assertTrue(result.contains("2026"));
        }
    }

    /**
     * ===============================
     * Pruebas de error
     * ===============================
     * Este bloque agrupa los escenarios donde el metodo
     * debe fallar y lanzar excepciones controladas.
     */
    @Nested
    @DisplayName("Casos de error")
    class ErrorCases {

        /**
         * Verifica que cuando el formato de fecha de entrada
         * no es soportado por el metodo, se lance una
         * IllegalArgumentException con un mensaje descriptivo.
         */
        @Test
        @DisplayName("Debe lanzar excepción cuando el formato es inválido")
        void shouldThrowExceptionForInvalidFormat() {
            String input = "15/04/2026";

            IllegalArgumentException exception = assertThrows(
                    IllegalArgumentException.class,
                    () -> formatFlexible(input, "yyyy-MM-dd")
            );

            assertTrue(exception.getMessage().contains("Formato de fecha no soportado"));
        }

        /**
         * Verifica que cuando la fecha de entrada es null,
         * el metodo lance una NullPointerException, indicando
         * que el parámetro es obligatorio.
         */
        @Test
        @DisplayName("Debe lanzar excepción cuando la fecha es null")
        void shouldThrowExceptionWhenInputIsNull() {
            assertThrows(
                    NullPointerException.class,
                    () -> formatFlexible(null, "yyyy-MM-dd")
            );
        }
    }
}