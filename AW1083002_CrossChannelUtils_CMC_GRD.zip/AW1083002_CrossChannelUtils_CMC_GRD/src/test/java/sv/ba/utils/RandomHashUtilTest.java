package sv.ba.utils;

import org.junit.jupiter.api.Test;
import sv.ba.utils.common.RandomHashUtil;

import java.lang.reflect.Constructor;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class RandomHashUtilTest {

    /**
     * Valida que el metodo generate()
     * retorne un valor no nulo y no vacío.
     * Regla cubierta:
     * - Siempre debe generar un hash UUID válido.
     */
    @Test
    void generateRetornaValorNoNuloNiVacio() {
        String result = RandomHashUtil.generate();

        assertNotNull(result, "El hash generado no debe ser null");
        assertFalse(result.isBlank(), "El hash generado no debe estar vacío");
    }

    /**
     * Valida que el valor generado tenga
     * un formato UUID válido.
     * Regla cubierta:
     * - El hash debe cumplir con el estándar UUID.
     */
    @Test
    void generateRetornaFormatoUUIDValido() {
        String result = RandomHashUtil.generate();

        // No debe lanzar excepción si el formato es correcto
        assertDoesNotThrow(() -> UUID.fromString(result));
    }

    /**
     * Valida que cada invocación de generate()
     * produzca un valor diferente.
     * Regla cubierta:
     * - El UUID debe ser aleatorio.
     */
    @Test
    void generateRetornaValoresDiferentes() {
        String hash1 = RandomHashUtil.generate();
        String hash2 = RandomHashUtil.generate();

        assertNotEquals(hash1, hash2, "Dos hashes consecutivos no deben ser iguales");
    }

    /**
     * Valida el constructor privado usando reflexión
     * para asegurar cobertura total de la clase.
     * Regla cubierta:
     * - El constructor privado existe y puede ser invocado internamente.
     */
    @Test
    void constructorPrivadoDebeSerInvocablePorReflection() throws Exception {
        Constructor<RandomHashUtil> constructor =
                RandomHashUtil.class.getDeclaredConstructor();

        constructor.setAccessible(true);

        RandomHashUtil instance = constructor.newInstance();

        assertNotNull(instance);
    }
}