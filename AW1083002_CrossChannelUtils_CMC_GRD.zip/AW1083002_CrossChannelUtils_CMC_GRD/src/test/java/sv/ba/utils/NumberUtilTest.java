package sv.ba.utils;

import org.junit.jupiter.api.Test;
import sv.ba.utils.common.NumberUtil;

import java.lang.reflect.Constructor;
import java.util.Locale;
import static org.junit.jupiter.api.Assertions.*;

class NumberUtilTest {

    @Test
    void round_shouldRoundHalfUpCorrectly() {
        assertEquals(10.12, NumberUtil.round(10.123, 2));
        assertEquals(10.13, NumberUtil.round(10.125, 2));
        assertEquals(10.0, NumberUtil.round(10.0, 2));
    }

    @Test
    void formatCurrency_shouldFormatAccordingToLocale() {
        String resultUS = NumberUtil.formatCurrency(1234.56, Locale.US);
        assertEquals("$1,234.56", resultUS);

        String resultES = NumberUtil.formatCurrency(1234.56, Locale.of("es", "SV"));
        assertTrue(resultES.contains("1,234.56") || resultES.contains("1.234,56"));
    }

    @Test
    void isNumeric_shouldValidateCorrectly() {
        // válidos
        assertTrue(NumberUtil.isNumeric("123"));
        assertTrue(NumberUtil.isNumeric("-123"));
        assertTrue(NumberUtil.isNumeric("123.45"));
        assertTrue(NumberUtil.isNumeric("-123.45"));

        // inválidos
        assertFalse(NumberUtil.isNumeric(null));
        assertFalse(NumberUtil.isNumeric(""));
        assertFalse(NumberUtil.isNumeric("   "));
        assertFalse(NumberUtil.isNumeric("abc"));
        assertFalse(NumberUtil.isNumeric("12a"));
        assertFalse(NumberUtil.isNumeric("12.12.12"));
    }

    @Test
    void privateConstructor_shouldBeInvokedForCoverage() throws Exception {
        Constructor<NumberUtil> constructor = NumberUtil.class.getDeclaredConstructor();
        constructor.setAccessible(true);

        assertNotNull(constructor.newInstance());
    }
}


