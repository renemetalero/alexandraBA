package sv.ba.utils;

import org.junit.jupiter.api.Test;
import sv.ba.utils.common.FileUtil;
import sv.ba.utils.enums.FileType;
import sv.ba.utils.exceptions.FileValidationException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;

class FileUtilTest {

    /**
     * Valida que se lance IllegalArgumentException
     * cuando el InputStream es null.
     * Regla cubierta:
     * - El archivo no puede estar vacío.
     */
    @Test
    void inputStreamNulo() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> FileUtil.validateFile(
                        null,
                        "archivo.pdf",
                        "application/pdf",
                        FileType.PDF)
        );

        assertEquals("El archivo está vacío", ex.getMessage());
    }

    /**
     * Valida que se lance IllegalArgumentException
     * cuando el nombre del archivo es null.
     * Regla cubierta:
     * - El nombre del archivo no puede ser null.
     * - Validación de extensión esperada.
     */
    @Test
    void fileNameNulo() {
        InputStream is = new ByteArrayInputStream(FileType.PDF.getSignature());

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> FileUtil.validateFile(
                        is,
                        null,
                        "application/pdf",
                        FileType.PDF)
        );

        assertTrue(ex.getMessage().contains(".pdf"));
    }

    /**
     * Valida que se lance IllegalArgumentException
     * cuando la extensión del archivo no coincide
     * con el tipo esperado.
     * Regla cubierta:
     * - Extensión incorrecta.
     */
    @Test
    void extensionIncorrecta() {
        InputStream is = new ByteArrayInputStream(FileType.PDF.getSignature());

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> FileUtil.validateFile(
                        is,
                        "archivo.png",
                        "application/pdf",
                        FileType.PDF)
        );

        assertTrue(ex.getMessage().contains(".pdf"));
    }

    /**
     * Valida que se lance IllegalArgumentException
     * cuando el contentType es null.
     * Regla cubierta:
     * - El tipo MIME no puede ser null.
     */
    @Test
    void contentTypeNulo() {
        InputStream is = new ByteArrayInputStream(FileType.PNG.getSignature());

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> FileUtil.validateFile(
                        is,
                        "imagen.png",
                        null,
                        FileType.PNG)
        );

        assertTrue(ex.getMessage().contains("image/png"));
    }

    /**
     * Valida que se lance IllegalArgumentException
     * cuando el tipo MIME no coincide con el esperado.
     * Regla cubierta:
     * - Validación de tipo MIME.
     */
    @Test
    void mimeTypeIncorrecto() {
        InputStream is = new ByteArrayInputStream(FileType.JPG.getSignature());

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> FileUtil.validateFile(
                        is,
                        "imagen.jpg",
                        "image/png",
                        FileType.JPG)
        );

        assertTrue(ex.getMessage().contains("image/jpeg"));
    }

    /**
     * Valida que se lance FileValidationException
     * cuando la firma del archivo no coincide
     * con el tipo esperado.
     * Regla cubierta:
     * - Validación de magic number.
     */
    @Test
    void firmaInvalida() {
        byte[] fakeHeader = new byte[]{0x00, 0x01, 0x02};
        InputStream is = new ByteArrayInputStream(fakeHeader);

        FileValidationException ex = assertThrows(
                FileValidationException.class,
                () -> FileUtil.validateFile(
                        is,
                        "archivo.pdf",
                        "application/pdf",
                        FileType.PDF)
        );

        assertEquals("El archivo no coincide con el tipo esperado", ex.getMessage());
    }

    /**
     * Valida que se lance FileValidationException
     * cuando ocurre una IOException al leer el archivo.
     *
     * Regla cubierta:
     * - Manejo correcto de error de lectura (IOException).
     * - Uso adecuado de try-with-resources.
     */
    @Test
    void errorLecturaArchivo() {

        try (InputStream is = new InputStream() {
            @Override
            public int read() throws IOException {
                throw new IOException("Error forzado");
            }
        }) {

            FileValidationException ex = assertThrows(
                    FileValidationException.class,
                    () -> FileUtil.validateFile(
                            is,
                            "archivo.pdf",
                            "application/pdf",
                            FileType.PDF)
            );

            assertEquals("Error leyendo archivo", ex.getMessage());
            assertNotNull(ex.getCause());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Valida el flujo exitoso cuando el archivo
     * es un PDF válido.
     * Regla cubierta:
     * - Validación correcta (flujo OK).
     * - getExtension(PDF).
     */
    @Test
    void archivoPdfValido() {
        InputStream is = new ByteArrayInputStream(FileType.PDF.getSignature());

        assertDoesNotThrow(() ->
                FileUtil.validateFile(
                        is,
                        "archivo.pdf",
                        "application/pdf",
                        FileType.PDF)
        );
    }

    /**
     * Valida el flujo exitoso para PNG
     * y cubre getExtension(PNG).
     */
    @Test
    void archivoPngValido() {
        InputStream is = new ByteArrayInputStream(FileType.PNG.getSignature());

        assertDoesNotThrow(() ->
                FileUtil.validateFile(
                        is,
                        "imagen.png",
                        "image/png",
                        FileType.PNG)
        );
    }

    /**
     * Valida el flujo exitoso para JPG
     * y cubre getExtension(JPG).
     */
    @Test
    void archivoJpgValido() {
        InputStream is = new ByteArrayInputStream(FileType.JPG.getSignature());

        assertDoesNotThrow(() ->
                FileUtil.validateFile(
                        is,
                        "imagen.jpg",
                        "image/jpeg",
                        FileType.JPG)
        );
    }
}