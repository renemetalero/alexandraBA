package sv.ba.utils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import sv.ba.utils.common.CapitalizeWords;

import static org.junit.jupiter.api.Assertions.*;

class CapitalizeWordsTest {

    /**
     * Verifica que el metodo retorne null
     * cuando el texto de entrada es null.
     * Cubre la condición:
     * if (text == null)
     */
    @Test
    void shouldReturnNullWhenTextIsNull() {
        assertNull(CapitalizeWords.capitalize(null));
    }

    /**
     * Verifica que el metodo retorne el texto original
     * cuando es una cadena vacía.
     * Cubre la condición:
     * text.isBlank()
     */
    @Test
    void shouldReturnEmptyStringWhenTextIsEmpty() {
        assertEquals("", CapitalizeWords.capitalize(""));
    }

    /**
     * Verifica que el metodo retorne el texto original
     * cuando contiene solo espacios en blanco.
     */
    @Test
    void shouldReturnBlankStringWhenTextIsOnlySpaces() {
        assertEquals("   ", CapitalizeWords.capitalize("   "));
    }

    /**
     * Verifica que el metodo capitalice correctamente
     * una sola palabra en minúsculas.
     */
    @Test
    void shouldCapitalizeSingleWord() {
        assertEquals("Hola", CapitalizeWords.capitalize("hola"));
    }


    /**
     * Verifica que el metodo capitalize:
     * - convierta el texto a minúsculas
     * - capitalice la primera letra de cada palabra
     * - ignore espacios extra entre palabras
     * - elimine espacios al inicio y al final
     * Este test parametrizado cubre múltiples escenarios
     * variando únicamente los valores de entrada y salida,
     * cumpliendo con la regla de Sonar sobre tests similares.
     */
    @ParameterizedTest(name = "Input: \"{0}\" => Expected: \"{1}\"")
    @CsvSource({
            "hOlA mUnDo, Hola Mundo",
            "'hola   mundo   java', Hola Mundo Java",
            "'   hola mundo   ', Hola Mundo"
    })
    void shouldCapitalizeTextCorrectly(String input, String expected) {
        String result = CapitalizeWords.capitalize(input);

        assertEquals(expected, result);
    }

}