package sv.ba.utils;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import sv.ba.utils.common.Base64Util;

class Base64UtilTest {

    /**
     * Verifica que el metodo encode(String)
     * devuelva una cadena vacía cuando la entrada es:
     * - null
     * - una cadena vacía
     * Cubre la condición:
     * if (text == null || text.isEmpty())
     */
    @Test
    void encode_ShouldReturnEmpty_WhenStringIsNullOrEmpty() {
        assertEquals("", Base64Util.encode((String) null));
        assertEquals("", Base64Util.encode(""));
    }

    /**
     * Verifica que encode(String) convierta correctamente
     * un texto válido a Base64 usando UTF-8.
     * Cubre el flujo normal (happy path) del metodo.
     */
    @Test
    void encode_ShouldEncodeStringCorrectly() {
        String text = "Hola Mundo";

        // Se ejecuta el metodo a probar
        String encoded = Base64Util.encode(text);

        // Se calcula el valor esperado usando el encoder oficial
        String expected = java.util.Base64.getEncoder()
                .encodeToString(text.getBytes(StandardCharsets.UTF_8));

        // Se valida que el resultado sea el esperado
        assertEquals(expected, encoded);
    }

    /**
     * Verifica que decode(String)
     * retorne una cadena vacía cuando el valor recibido es:
     * - null
     * - una cadena vacía
     * Cubre la validación inicial:
     * if (base64 == null || base64.isEmpty())
     */
    @Test
    void decode_ShouldReturnEmpty_WhenStringIsNullOrEmpty() {
        assertEquals("", Base64Util.decode(null));
        assertEquals("", Base64Util.decode(""));
    }

    /**
     * Verifica que decode(String) decodifique correctamente
     * una cadena Base64 válida y devuelva el texto original.
     */
    @Test
    void decode_ShouldDecodeBase64Correctly() {
        // "Hola Mundo" en Base64
        String base64 = "SG9sYSBNdW5kbw==";

        // Se decodifica el valor Base64
        String decoded = Base64Util.decode(base64);

        // Se valida el texto original
        assertEquals("Hola Mundo", decoded);
    }

    /**
     * Verifica que encode(byte[])
     * devuelva una cadena vacía cuando:
     * - el arreglo es null
     * - el arreglo está vacío
     * Cubre la validación:
     * if (data == null || data.length == 0)
     */
    @Test
    void testEncode_ShouldReturnEmpty_WhenByteArrayIsNullOrEmpty() {
        assertEquals("", Base64Util.encode((byte[]) null));
        assertEquals("", Base64Util.encode(new byte[0]));
    }

    /**
     * Verifica que encode(byte[]) convierta correctamente
     * un arreglo de bytes válido a una cadena Base64.
     */
    @Test
    void testEncode_ShouldEncodeByteArrayCorrectly() {
        byte[] data = "JUnit Test".getBytes(StandardCharsets.UTF_8);

        // Se ejecuta el metodo a probar
        String encoded = Base64Util.encode(data);

        // Valor esperado calculado manualmente
        String expected = java.util.Base64.getEncoder().encodeToString(data);

        assertEquals(expected, encoded);
    }

    /**
     * Verifica que decodeToBytes(String)
     * devuelva un arreglo de bytes vacío cuando:
     * - el String es null
     * - el String es vacío
     * Cubre la validación inicial del metodo.
     */
    @Test
    void decodeToBytes_ShouldReturnEmptyArray_WhenStringIsNullOrEmpty() {
        assertArrayEquals(new byte[0], Base64Util.decodeToBytes(null));
        assertArrayEquals(new byte[0], Base64Util.decodeToBytes(""));
    }

    /**
     * Verifica que decodeToBytes(String)
     * decodifique correctamente una cadena Base64 válida
     * y devuelva el arreglo de bytes original.
     */
    @Test
    void decodeToBytes_ShouldDecodeBase64Correctly() {
        // "JUnit Test" codificado en Base64
        String base64 = "SlVuaXQgVGVzdA==";

        // Se decodifica a bytes
        byte[] decoded = Base64Util.decodeToBytes(base64);

        // Se compara el arreglo de bytes resultante
        assertArrayEquals(
                "JUnit Test".getBytes(StandardCharsets.UTF_8),
                decoded
        );
    }
}