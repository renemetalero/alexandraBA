package sv.ba.utils.documents;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.lang.reflect.Constructor;

import static org.junit.jupiter.api.Assertions.*;

class ValidateDUINITUtilsTest {

    /* =========================
       TESTS PARA VALIDACIÓN DUI
       ========================= */
    /**
     * Valida que el metodo detecte
     * un DUI null o vacío.
     * Regla cubierta:
     * - DUI obligatorio.
     */
    @Test
    void validateDUINullOVacio() {
        ValidationResult result = ValidateDUINITUtils.validateDUI("");

        assertFalse(result.isValid());
        assertEquals(
                "El DUI está vacío. Formato correcto: 12345678-9",
                result.getMessage()
        );
    }


    /**
     * Valida múltiples escenarios inválidos de DUI
     * utilizando un único test parametrizado.
     * Casos cubiertos:
     * - DUI con letras
     * - DUI con menos dígitos
     * - DUI con más dígitos
     * - DUI con formato incorrecto
     * - DUI con dígito verificador incorrecto
     * Cumple regla Sonar:
     * - Eliminación de tests duplicados mediante parametrización.
     */
    @ParameterizedTest
    @CsvSource({
            // Letras en DUI
            "'1234A678-9', 'solo debe contener números'",

            // Menos de 9 dígitos
            "'1234567-8', 'Faltan'",

            // Más de 9 dígitos
            "'123456789-1', 'máximo es 9'",

            // Formato incorrecto
            "'123456789', 'Formato incorrecto'",

            // Dígito verificador incorrecto
            "'12345678-0', 'Dígito verificador incorrecto'"
    })
    void validateDUICasosInvalidos(String dui, String expectedMessageFragment) {

        ValidationResult result =
                ValidateDUINITUtils.validateDUI(dui);

        assertFalse(result.isValid());
        assertTrue(
                result.getMessage().contains(expectedMessageFragment),
                "Mensaje inesperado para DUI: " + dui
        );
    }


    /**
     * Valida un DUI correcto
     * con dígito verificador válido.
     */
    @Test
    void validateDUIValido() {
        ValidationResult result =
                ValidateDUINITUtils.validateDUI("04484836-9");

        assertTrue(result.isValid());
        assertEquals("DUI válido", result.getMessage());
    }

    /* =========================
       TESTS PARA VALIDACIÓN NIT
       ========================= */
    /**
     * Valida que el NIT no
     * sea null o vacío.
     */
    @Test
    void validateNITNullOVacio() {
        ValidationResult result =
                ValidateDUINITUtils.validateNIT(null);

        assertFalse(result.isValid());
        assertEquals(
                "El NIT está vacío. Formato correcto: 1234-123456-123-1",
                result.getMessage()
        );
    }

    /*
     * Valida que el NIT solo
     * contenga números.
     */

    /**
     * Valida múltiples escenarios de error para NIT
     * usando un único test parametrizado.
     * Regla cubierta:
     * - El NIT debe cumplir formato, longitud y contener solo números.
     * Cumple con regla Sonar:
     * - Tests similares refactorizados a ParameterizedTest.
     */
    @ParameterizedTest
    @CsvSource({
            // NIT con letras
            "'123A-123456-123-1', 'solo debe contener números'",

            // NIT con menos dígitos
            "'1234-123456-12-1', 'Faltan'",

            // NIT con más dígitos
            "'1234-123456-1234-1', 'máximo es 14'",

            // NIT con formato incorrecto
            "'12341234561231', 'Formato incorrecto'"
    })
    void validateNITCasosInvalidos(String nit, String expectedMessageFragment) {

        ValidationResult result =
                ValidateDUINITUtils.validateNIT(nit);

        assertFalse(result.isValid());
        assertTrue(
                result.getMessage().contains(expectedMessageFragment),
                "Mensaje inesperado para NIT: " + nit
        );
    }


    /**
     * Valida un NIT correcto.
     */
    @Test
    void validateNITValido() {
        ValidationResult result =
                ValidateDUINITUtils.validateNIT("0614-290590-102-3");

        assertTrue(result.isValid());
        assertEquals("NIT válido", result.getMessage());
    }

    /* =========================
       VALIDATIONRESULT Y CONSTRUCTOR PRIVADO
       ========================= */
    /**
     * Valida los getters
     * de ValidationResult.
     */
    @Test
    void validationResultGetters() {
        ValidationResult result =
                new ValidationResult(true, "OK");

        assertTrue(result.isValid());
        assertEquals("OK", result.getMessage());
    }

    /**
     * Valida el constructor privado
     * de la clase utilitaria.
     */
    @Test
    void constructorPrivadoDebeSerInvocablePorReflection() throws Exception {
        Constructor<ValidateDUINITUtils> constructor =
                ValidateDUINITUtils.class.getDeclaredConstructor();

        constructor.setAccessible(true);

        ValidateDUINITUtils instance = constructor.newInstance();
        assertNotNull(instance);
    }
}