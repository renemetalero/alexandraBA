package sv.ba.utils;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import sv.ba.utils.common.EmailUtil;

class EmailUtilTest {

    /**
     * Valida que el metodo retorne el mensaje de error correcto
     * cuando el correo electrónico es NULL.
     * Regla cubierta:
     * - El correo no puede ser null.
     */
    @Test
    void emailNulo() {
        String result = EmailUtil.isValidEmail(null);
        String expected = "El correo no puede estar vacío. Ejemplo válido: usuario@dominio.com";
        assertEquals(
                expected,
                result
        );
    }

    /**
     * Valida que el metodo retorne el mensaje de error correcto
     * cuando el correo contiene solo espacios en blanco.
     * Regla cubierta:
     * - El correo no puede estar vacío ni contener solo espacios.
     */
    @Test
    void emailVacio() {
        String result = EmailUtil.isValidEmail("   ");
        assertEquals(
                "El correo no puede estar vacío. Ejemplo válido: usuario@dominio.com",
                result
        );
    }

    /**
     * Valida que el metodo detecte la ausencia del símbolo '@'
     * dentro del correo electrónico.
     * Regla cubierta:
     * - El correo debe contener el símbolo '@'.
     */
    @Test
    void emailSinArroba() {
        String result = EmailUtil.isValidEmail("usuario.dominio.com");
        assertEquals(
                "Falta el símbolo '@'. Ejemplo: usuario@dominio.com",
                result
        );
    }

    /**
     * Valida que el metodo detecte múltiples símbolos '@'
     * dentro del correo electrónico.
     * Regla cubierta:
     * - El correo debe contener un solo '@'.
     */
    @Test
    void emailConMasDeUnaArroba() {
        String result = EmailUtil.isValidEmail("user@@dominio.com");
        assertEquals(
                "El correo debe tener un solo '@'. Ejemplo: usuario@dominio.com",
                result
        );
    }

    /**
     * Valida que el metodo detecte cuando la parte local
     * (antes del '@') está vacía.
     * Regla cubierta:
     * - La parte antes del '@' no puede estar vacía.
     */
    @Test
    void parteLocalVacia() {
        String result = EmailUtil.isValidEmail("@dominio.com");
        assertEquals(
                "La parte antes de '@' no puede estar vacía. Ejemplo: usuario@dominio.com",
                result
        );
    }

    /**
     * Valida que el metodo detecte caracteres inválidos
     * en la parte local del correo electrónico.
     * Regla cubierta:
     * - Solo se permiten letras, números y los caracteres + _ . -
     *   antes del símbolo '@'.
     */
    @Test
    void parteLocalConCaracteresInvalidos() {
        String result = EmailUtil.isValidEmail("user*name@dominio.com");
        assertEquals(
                "La parte antes de '@' contiene caracteres inválidos. Solo se permiten letras, números y + _ . -",
                result
        );
    }

    /**
     * Valida que el metodo detecte cuando el dominio
     * (parte posterior al '@') está vacío.
     * Regla cubierta:
     * - El dominio no puede estar vacío.
     */
    @Test
    void dominioVacio() {
        String result = EmailUtil.isValidEmail("usuario@    ");
        assertEquals(
                "El dominio no puede estar vacío. Ejemplo: usuario@dominio.com",
                result
        );
    }

    /**
     * Valida que el metodo detecte cuando el dominio
     * no contiene un punto.
     * Regla cubierta:
     * - El dominio debe contener al menos un punto (.).
     */
    @Test
    void dominioSinPunto() {
        String result = EmailUtil.isValidEmail("usuario@dominio");
        assertEquals(
                "El dominio debe contener un punto. Ejemplo: usuario@dominio.com",
                result
        );
    }

    /**
     * Valida que el metodo detecte un dominio con formato inválido,
     * por ejemplo, una extensión demasiado corta.
     * Regla cubierta:
     * - El dominio debe cumplir con el patrón válido (ej: dominio.com).
     */
    @Test
    void dominioFormatoInvalido() {
        String result = EmailUtil.isValidEmail("usuario@dominio.c");
        assertEquals(
                "El dominio no es válido. Ejemplo correcto: dominio.com",
                result
        );
    }

    /**
     * Valida que el metodo retorne "OK"
     * cuando el correo electrónico cumple con todas
     * las reglas de validación.
     * Regla cubierta:
     * - Flujo exitoso del metodo.
     */
    @Test
    void emailValido() {
        String result = EmailUtil.isValidEmail("usuario@test-dominio.com");
        assertEquals("OK", result);
    }
}
