package sv.ba.api.messagingcore.envelope.validator.date;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

/**
 * Valida que un {@link Integer} represente una fecha real en formato
 * {@code yyyyMMdd}.
 *
 * <p>
 * La validación acepta {@code null} y aplica parseo estricto para rechazar
 * fechas inexistentes, como días fuera de rango o meses inválidos.
 */
public class DateIntegerValidator implements ConstraintValidator<ValidDate, Integer> {

    /**
     * Determina si el valor cumple con el formato {@code yyyyMMdd} y existe
     * como fecha válida en el calendario.
     *
     * @param value   fecha a validar.
     * @param context contexto de validación provisto por Jakarta Validation.
     * @return {@code true} si el valor es {@code null} o si representa una
     *         fecha válida; de lo contrario, {@code false}.
     */
    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
        if (value == null) return true;

        String dateStr = value.toString();

        if (dateStr.length() != 8) return false;

        try {
            DateTimeFormatter formatter = DateTimeFormatter
                    .ofPattern("uuuuMMdd")
                    .withResolverStyle(ResolverStyle.STRICT);

            LocalDate.parse(dateStr, formatter);
            return true;

        } catch (DateTimeParseException e) {
            return false;
        }
    }
}
