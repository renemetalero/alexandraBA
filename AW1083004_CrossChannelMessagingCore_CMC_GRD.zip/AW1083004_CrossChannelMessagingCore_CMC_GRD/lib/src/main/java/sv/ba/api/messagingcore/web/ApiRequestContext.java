package sv.ba.api.messagingcore.web;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import sv.ba.api.messagingcore.envelope.Metadata;
import sv.ba.api.messagingcore.envelope.header.CoreRequestHeader;

/**
 * Contexto del request actual. Almacena el {@link Metadata} y el
 * {@link CoreRequestHeader} extraídos del body por el
 * {@link RequestContextAdvice}, manteniéndolos disponibles durante la
 * totalidad del ciclo de vida del request HTTP.
 *
 * <p>
 * Es un bean de scope request ({@link RequestScope}) — Spring crea una
 * instancia nueva para cada request entrante y la destruye automáticamente
 * al finalizar, sin necesidad de limpieza manual.
 *
 * <p>
 * Es el canal que permite a
 * {@link sv.ba.api.messagingcore.factory.EnvelopeBuilder}
 * acceder al {@code _correlationId} y al header del request para construir
 * las respuestas sin que el desarrollador tenga que pasarlos explícitamente:
 *
 * <pre>
 * // El factory obtiene el correlationId y el header automáticamente
 * return factory.success(body);
 * </pre>
 *
 * <p>
 * Si el request no contiene un {@link RequestEnvelope} en el body — por
 * ejemplo en endpoints GET — el contexto queda vacío y la respuesta no
 * incluirá {@code _correlationId} ni header, lo cual es el comportamiento
 * esperado para esos casos.
 *
 * @author Jose Luis Pereira
 * @see RequestContextAdvice
 * @see sv.ba.api.messagingcore.factory.EnvelopeBuilder
 * @see sv.ba.api.messagingcore.factory.MessageFactory
 */
@Component
@RequestScope
public class ApiRequestContext {

    private Metadata metadata;
    private CoreRequestHeader header;

    /**
     * Retorna el {@link Metadata} del request actual, o {@code null} si el
     * contexto no fue poblado — por ejemplo en endpoints sin {@code @RequestBody}.
     *
     * @return {@link Metadata} del request, o {@code null}.
     */
    public Metadata getTraceability() {
        return metadata;
    }

    /**
     * Almacena el {@link Metadata} extraído del
     * {@link sv.ba.api.messagingcore.envelope.RequestEnvelope}.
     * Es invocado por {@link RequestContextAdvice} después de la deserialización.
     *
     * @param metadata metadata del request a almacenar.
     */
    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    /**
     * Retorna el {@link CoreRequestHeader} del request actual, o {@code null}
     * si el contexto no fue poblado o el request no incluye header.
     *
     * @return {@link CoreRequestHeader} del request, o {@code null}.
     */
    public CoreRequestHeader getHeader() {
        return header;
    }

    /**
     * Almacena el {@link CoreRequestHeader} extraído del
     * {@link sv.ba.api.messagingcore.envelope.RequestEnvelope}. Es invocado
     * por {@link RequestContextAdvice} después de la deserialización.
     *
     * @param header header del request a almacenar.
     */
    public void setHeader(CoreRequestHeader header) {
        this.header = header;
    }

    /**
     * Retorna el {@code _correlationId} del request actual. Es un atajo para
     * obtener el correlativo sin acceder directamente al {@link Metadata}.
     *
     * @return {@code _correlationId} del request, o {@code null} si no hay
     *         metadata disponible o el request no incluye correlación.
     */
    public String getCorrelationId() {
        return metadata != null ? metadata.correlationId() : null;
    }

    public String getMessageId() {
        return metadata != null ? metadata.messageId() : null;
    }

    public LocalDateTime getDatetime() {
        return metadata != null ? metadata.datetime() : null;
    }

    /**
     * Indica si el contexto fue poblado con metadata del request.
     *
     * @return {@code true} si hay metadata disponible, {@code false} si el
     *         contexto está vacío — por ejemplo en endpoints GET sin body.
     */
    public boolean hasMetadata() {
        return metadata != null;
    }
}
