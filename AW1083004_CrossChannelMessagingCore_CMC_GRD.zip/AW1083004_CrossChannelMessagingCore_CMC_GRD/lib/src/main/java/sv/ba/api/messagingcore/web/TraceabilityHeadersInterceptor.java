package sv.ba.api.messagingcore.web;

import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import sv.ba.api.messagingcore.envelope.Metadata;

/**
 * Descripción de la responsabilidad de esta clase...
 *
 * @author Jose Luis Pereira
 */
public class TraceabilityHeadersInterceptor implements HandlerInterceptor {

    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

    private static final String HEADER_MESSAGE_ID = "messageId";
    private static final String HEADER_CORRELATIONID = "correlationId";
    private static final String HEADER_DATETIME = "dateTime";

    private final ApiRequestContext requestContext;

    public TraceabilityHeadersInterceptor(ApiRequestContext requestContext) {
        this.requestContext = requestContext;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String messageId = request.getHeader(HEADER_MESSAGE_ID);
        String correlationId = request.getHeader(HEADER_CORRELATIONID);
        String dateTimeStr = request.getHeader(HEADER_DATETIME);
        requestContext.setMetadata(new Metadata(messageId, correlationId, parseDateTime(dateTimeStr)));
        return true;
    }

    private LocalDateTime parseDateTime(String dateTimeStr) {
        if (dateTimeStr == null || dateTimeStr.isBlank()) {
            return LocalDateTime.now();
        }
        try {
            return LocalDateTime.parse(dateTimeStr, DATETIME_FORMATTER);
        } catch (DateTimeException e) {
            return LocalDateTime.now();
        }
    }

}
