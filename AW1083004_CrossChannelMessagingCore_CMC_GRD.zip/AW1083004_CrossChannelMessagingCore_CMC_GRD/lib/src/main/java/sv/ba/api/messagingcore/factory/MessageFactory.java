package sv.ba.api.messagingcore.factory;

import java.util.Objects;

import sv.ba.api.messagingcore.envelope.ResponseEnvelope;
import sv.ba.api.messagingcore.envelope.pagination.Links;
import sv.ba.api.messagingcore.envelope.pagination.ResponsePagination;
import sv.ba.api.messagingcore.exception.ApiException;
import sv.ba.api.messagingcore.web.ApiRequestContext;

/**
 * Punto de entrada para la construcción de respuestas del estándar.
 *
 * <p>
 * Es el único componente que el desarrollador necesita para construir
 * cualquier respuesta — exitosa o de error. Obtiene automáticamente el
 * {@code _correlationId} y el header del request desde el
 * {@link ApiRequestContext}, poblado previamente por el
 * {@link sv.ba.api.messagingcore.web.RequestContextAdvice}.
 *
 * <p>
 * Se registra automáticamente como bean de Spring a través de
 * {@link sv.ba.api.messagingcore.config.MessagingCoreConfiguration} y
 * se inyecta en los controllers mediante el mecanismo estándar de Spring:
 * 
 * <pre>
 * &#64;RestController
 * public class MiController {
 *
 *     private final MessageFactory factory;
 *
 *     public MiController(MessageFactory factory) {
 *         this.factory = factory;
 *     }
 * }
 * </pre>
 *
 * <p>
 * Ofrece dos caminos para construir respuestas exitosas:
 *
 * <p>
 * <b>Camino corto</b> — el más común, metadata y header se resuelven
 * automáticamente:
 * 
 * <pre>
 * // Sin paginación
 * return factory.success(body);
 *
 * // Con paginación
 * return factory.success(body, new ResponsePagination(false, 100));
 * </pre>
 *
 * <p>
 * <b>Camino extendido</b> — para control granular sobre el header
 * o la paginación:
 * 
 * <pre>
 * return factory.&lt;MiResponse&gt;responseBuilder()
 *         .withHeader(miHeaderPersonalizado)
 *         .withBody(body)
 *         .withPagination(new ResponsePagination(true, 50))
 *         .build();
 * </pre>
 *
 * <p>
 * Las respuestas de error se construyen automáticamente por el
 * {@link sv.ba.api.messagingcore.web.ApiExceptionHandler} — el desarrollador
 * solo necesita lanzar la excepción correspondiente:
 * 
 * <pre>
 * throw new BusinessProviderException(409, "19001", "IBS", "La cuenta está bloqueada");
 * </pre>
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see ResponseEnvelopeBuilder
 * @see ErrorEnvelopeBuilder
 * @see ApiRequestContext
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 * @see sv.ba.api.messagingcore.config.MessagingCoreConfiguration
 */
public final class MessageFactory {

    private final ApiRequestContext requestContext;

    /**
     * Constructor que recibe el contexto del request actual.
     *
     * @param requestContext contexto de scope request que contiene el
     *                       {@code _correlationId} y el header extraídos
     *                       del body del request. No puede ser {@code null}.
     * @throws NullPointerException si {@code requestContext} es {@code null}.
     */
    public MessageFactory(ApiRequestContext requestContext) {
        this.requestContext = Objects.requireNonNull(
                requestContext, "requestContext no puede ser null");
    }

    /**
     * Construye un {@link ResponseEnvelope} exitoso sin paginación.
     * Metadata y header se resuelven automáticamente desde el
     * {@link ApiRequestContext}.
     *
     * @param body resultado de la operación generado por la lógica de negocio.
     *             No puede ser {@code null}.
     * @param <B>  tipo del body específico de la operación.
     * @return {@link ResponseEnvelope} listo para retornar al consumidor.
     * @throws NullPointerException si {@code body} es {@code null}.
     * @see ResponseEnvelopeBuilder
     */
    public <B> ResponseEnvelope<B> success(B body) {
        return this.<B>responseBuilder()
                .withBody(body)
                .build();
    }

    /**
     * Construye un {@link ResponseEnvelope} exitoso con paginación.
     * Metadata y header se resuelven automáticamente desde el
     * {@link ApiRequestContext}.
     *
     * @param body       resultado de la operación generado por la lógica
     *                   de negocio. No puede ser {@code null}.
     * @param pagination información de paginación con el indicador de última
     *                   página y el total de registros.
     * @param <B>        tipo del body específico de la operación.
     * @return {@link ResponseEnvelope} con paginación, listo para retornar
     *         al consumidor.
     * @throws NullPointerException si {@code body} es {@code null}.
     * @see ResponseEnvelopeBuilder
     * @see ResponsePagination
     */
    public <B> ResponseEnvelope<B> success(B body, ResponsePagination pagination) {
        return this.<B>responseBuilder()
                .withBody(body)
                .withPagination(pagination)
                .build();
    }

    public <B> ResponseEnvelope<B> success(B body, ResponsePagination pagination, Links links) {
        return this.<B>responseBuilder()
                .withBody(body)
                .withPagination(pagination)
                .withLinks(links)
                .build();
    }

    /**
     * Retorna un {@link ResponseEnvelopeBuilder} configurado con el contexto
     * del request actual, para construir respuestas exitosas con control
     * granular sobre el header y la paginación.
     *
     * @param <B> tipo del body específico de la operación.
     * @return nuevo {@link ResponseEnvelopeBuilder} listo para configurar.
     * @see ResponseEnvelopeBuilder
     */
    public <B> ResponseEnvelopeBuilder<B> responseBuilder() {
        return new ResponseEnvelopeBuilder<>(requestContext);
    }

    /**
     * Retorna un {@link ErrorEnvelopeBuilder} configurado con el contexto
     * del request actual y la excepción a procesar. Usado internamente por
     * el {@link sv.ba.api.messagingcore.web.ApiExceptionHandler}.
     *
     * @param exception excepción de la jerarquía {@link ApiException} que
     *                  contiene el código, título y detalle del error.
     *                  No puede ser {@code null}.
     * @return nuevo {@link ErrorEnvelopeBuilder} listo para construir el
     *         {@link sv.ba.api.messagingcore.envelope.ErrorEnvelope}.
     * @throws NullPointerException si {@code exception} es {@code null}.
     * @see ErrorEnvelopeBuilder
     * @see ApiException
     */
    public ErrorEnvelopeBuilder errorBuilder(ApiException exception) {
        Objects.requireNonNull(exception, "exception no puede ser null");
        return new ErrorEnvelopeBuilder(requestContext, exception);
    }
}
