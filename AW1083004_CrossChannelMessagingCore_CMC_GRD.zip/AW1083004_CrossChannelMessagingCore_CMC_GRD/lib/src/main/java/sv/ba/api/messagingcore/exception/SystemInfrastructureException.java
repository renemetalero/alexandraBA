package sv.ba.api.messagingcore.exception;

import java.util.List;

import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorPrefix;

/**
 * Excepción que representa un error en la infraestructura de la capa media.
 * Utiliza el prefijo {@link ErrorPrefix#SI}.
 *
 * <p>
 * Se lanza cuando la falla se origina en la plataforma de integración,
 * no en el API ni en el proveedor externo. Ejemplos de uso:
 * <ul>
 * <li>Error en la plataforma de integración empresarial.</li>
 * <li>Falla en el bus de servicios o mensajería interna.</li>
 * <li>Problema en la infraestructura de conectividad entre sistemas.</li>
 * </ul>
 *
 * <p>
 * Uso directo:
 * 
 * <pre>
 * throw new SystemInfrastructureException(503, "19004", "API",
 *         "Error en la plataforma de integración");
 * </pre>
 *
 * <p>
 * Uso recomendado — crear una excepción específica en el microservicio:
 * 
 * <pre>
 * public class PlataformaIntegracionException extends SystemInfrastructureException {
 *     public PlataformaIntegracionException() {
 *         super(503, "19004", "API", "Error en la plataforma de integración");
 *     }
 * }
 * </pre>
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see ApiException
 * @see ErrorPrefix#SI
 * @see SystemApiException
 * @see SystemMiddlewareException
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
public final class SystemInfrastructureException extends ApiException {

    /**
     * Constructor principal.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19004"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "API"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     */
    public SystemInfrastructureException(int httpStatus, String errorCode,
            String title, String detail) {
        super(httpStatus, errorCode, title, detail);
    }

    /**
     * Constructor con causa. Útil para preservar la excepción original.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19004"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "API"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     * @param cause      excepción original que provocó este error.
     */
    public SystemInfrastructureException(int httpStatus, String errorCode,
            String title, String detail,
            Throwable cause) {
        super(httpStatus, errorCode, title, detail, cause);
    }

    /**
     * Constructor con lista de errores. Para casos donde la operación
     * produce múltiples errores simultáneos.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errors     lista de {@link ApiError} ya construidos con sus
     *                   códigos completos. No puede ser {@code null} ni vacía.
     */
    public SystemInfrastructureException(int httpStatus, List<ApiError> errors) {
        super(httpStatus, errors);
    }

    /**
     * {@inheritDoc}
     *
     * @return {@link ErrorPrefix#SI}
     */
    @Override
    public ErrorPrefix prefix() {
        return ErrorPrefix.SI;
    }
}
