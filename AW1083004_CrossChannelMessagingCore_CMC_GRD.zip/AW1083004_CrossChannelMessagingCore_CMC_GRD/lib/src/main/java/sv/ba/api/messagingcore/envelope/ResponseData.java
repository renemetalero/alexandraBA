package sv.ba.api.messagingcore.envelope;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.Valid;
import sv.ba.api.messagingcore.envelope.header.CoreResponseHeader;

/**
 * Representa el objeto {@code data} dentro de una respuesta exitosa del API.
 *
 * <p>
 * Contiene el header del response — derivado del header del request
 * sin los campos restringidos — y el body específico de la operación generado
 * por la lógica de negocio del microservicio.
 *
 * <p>
 * Estructura en JSON:
 * 
 * <pre>
 * {
 *   "data": {
 *     "header": {
 *       "date": "20261201",
 *       "instanceId": "01",
 *       "system": "BM",
 *       "hour": "083000",
 *       "batch": "3711",
 *       "branch": "037",
 *       "channelId": "000003711"
 *     },
 *     "body": { ... }
 *   }
 * }
 * </pre>
 *
 * <p>
 * El header se deriva automáticamente del request a través de
 * {@link CoreResponseHeader#fromRequestHeader(sv.ba.api.messagingcore.envelope.header.CoreRequestHeader)}
 * cuando se usa {@link sv.ba.api.messagingcore.factory.MessageFactory} para
 * construir la respuesta. Los campos con valor {@code null} se omiten
 * automáticamente en la serialización JSON.
 *
 * @param <B>    tipo del body específico de la operación, definido por el
 *               microservicio consumidor.
 * @param header header para la respuesta. Contiene los campos
 *               de trazabilidad permitidos, excluyendo {@code supervisor},
 *               {@code user} y {@code locationUser}.
 * @param body   resultado de la operación. Su estructura es definida por el
 *               microservicio para cada endpoint.
 *
 * @author Jose Luis Pereira
 * @see CoreResponseHeader
 * @see RequestData
 * @see ResponseEnvelope
 * @see sv.ba.api.messagingcore.factory.MessageFactory
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ResponseData<B>(
        @Valid CoreResponseHeader header,
        @Valid B body) {
}
