package sv.ba.api.messagingcore.error;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.NotBlank;

/**
 * Representa un elemento individual dentro del array {@code errors} de un
 * {@link sv.ba.api.messagingcore.envelope.ErrorEnvelope}.
 *
 * <p>
 * Cada instancia describe un error específico ocurrido durante el
 * procesamiento de la solicitud, identificando su código, el sistema que
 * lo reportó y una descripción funcional del problema.
 *
 * <p>
 * Estructura en JSON:
 * 
 * <pre>
 * {
 *   "code": "BP40919001",
 *   "title": "IBS",
 *   "detail": "La cuenta está bloqueada"
 * }
 * </pre>
 *
 * <p>
 * El campo {@code code} se construye automáticamente por
 * {@link ErrorCodeBuilder} al crear una excepción de la jerarquía
 * {@link sv.ba.api.messagingcore.exception.ApiException}:
 * 
 * <pre>
 * throw new BusinessProviderException(409, "19001", "IBS", "La cuenta está bloqueada");
 * </pre>
 *
 * @param code   código de error compuesto en formato
 *               {@code <prefijo><httpStatus><errorCode>}.
 *               Ejemplo: {@code "BP40919001"}.
 * @param title  nombre del sistema o proveedor que reportó el error.
 *               Ejemplo: {@code "IBS"}, {@code "CMC"}, {@code "API"}.
 * @param detail descripción funcional del error en lenguaje natural.
 *               Debe ser clara para el consumidor del API, sin exponer
 *               detalles técnicos internos.
 *               Ejemplo: {@code "La cuenta está bloqueada"}.
 *
 * @author Jose Luis Pereira
 * @see ErrorPrefix
 * @see ErrorCodeBuilder
 * @see sv.ba.api.messagingcore.envelope.ErrorEnvelope
 * @see sv.ba.api.messagingcore.exception.ApiException
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ApiError(
        @NotBlank String code,
        @NotBlank String title,
        @NotBlank String detail) implements Serializable {
}
