package sv.ba.api.messagingcore.error;

import java.util.Objects;

/**
 * Utilidad para construir códigos de error conforme al estándar.
 *
 * <p>
 * El código de error se compone de tres partes concatenadas:
 * 
 * <pre>
 *   código = &lt;prefijo&gt; + &lt;httpStatus&gt; + &lt;errorCode&gt;
 *   ejemplo: BP + 409 + 19001 = BP40919001
 * </pre>
 *
 * <p>
 * Donde:
 * <ul>
 * <li>{@code prefijo} — categoría del error según {@link ErrorPrefix}.</li>
 * <li>{@code httpStatus} — código HTTP de la respuesta (100-599).</li>
 * <li>{@code errorCode} — código EVC de exactamente 5 dígitos asignado al
 * error específico dentro del rango del microservicio. El catálogo de
 * códigos EVC lo define cada equipo.</li>
 * </ul>
 *
 * <p>
 * Esta clase es de uso interno de la librería — el código se construye
 * automáticamente al crear una instancia de cualquier subclase de
 * {@link sv.ba.api.messagingcore.exception.ApiException}. El desarrollador
 * solo necesita indicar el código EVC específico de su catálogo:
 * 
 * <pre>
 * throw new BusinessProviderException(409, "19001", "IBS", "Cuenta bloqueada");
 * </pre>
 *
 * <p>
 * Esta clase no puede ser instanciada — todos sus métodos son estáticos.
 *
 * @author Jose Luis Pereira
 * @see ErrorPrefix
 * @see ApiError
 * @see sv.ba.api.messagingcore.exception.ApiException
 */
public final class ErrorCodeBuilder {

    private static final int ERROR_CODE_LENGTH = 5;

    private ErrorCodeBuilder() {
    }

    /**
     * Construye el código de error concatenando prefijo, código HTTP y código EVC.
     *
     * @param prefix     categoría del error. No puede ser {@code null}.
     * @param httpStatus código HTTP de la respuesta. Debe estar en rango 100-599.
     * @param errorCode  código EVC de exactamente 5 dígitos numéricos asignado
     *                   al error específico. No puede ser {@code null}.
     * @return código de error compuesto. Ejemplo: {@code "BP40919001"}.
     * @throws NullPointerException     si {@code prefix} o {@code errorCode}
     *                                  son {@code null}.
     * @throws IllegalArgumentException si {@code httpStatus} está fuera del
     *                                  rango 100-599, o si {@code errorCode}
     *                                  no tiene exactamente 5 dígitos numéricos.
     * @see ErrorPrefix
     */
    public static String build(ErrorPrefix prefix, int httpStatus, String errorCode) {
        Objects.requireNonNull(prefix, "Prefix no puede ser null");
        Objects.requireNonNull(errorCode, "errorCode no puede ser null");
        validateHttpStatus(httpStatus);
        validateErrorCode(errorCode);
        return prefix.value() + httpStatus + errorCode;
    }

    /**
     * Valida que el código HTTP esté dentro del rango permitido (100-599).
     *
     * @param httpStatus código HTTP a validar.
     * @throws IllegalArgumentException si el valor está fuera del rango.
     */
    private static void validateHttpStatus(int httpStatus) {
        if (httpStatus < 100 || httpStatus > 599) {
            throw new IllegalArgumentException("httpStatus fuera de rango (100 - 599): " + httpStatus);
        }
    }

    /**
     * Valida que el código EVC tenga exactamente 5 dígitos numéricos.
     *
     * @param errorCode código EVC a validar.
     * @throws IllegalArgumentException si el formato no es válido.
     */
    private static void validateErrorCode(String errorCode) {
        if (!errorCode.matches("\\d{" + ERROR_CODE_LENGTH + "}")) {
            throw new IllegalArgumentException(
                    "errorCode debe ser numerico de: " + ERROR_CODE_LENGTH + " digitos, recibido: " + errorCode);
        }
    }
}
