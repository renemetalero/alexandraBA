package sv.ba.api.messagingcore.envelope;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import sv.ba.api.messagingcore.envelope.header.CoreRequestHeader;

/**
 * Representa el objeto {@code data} dentro de una solicitud (request) al API.
 *
 * <p>
 * Contiene el header del request con los datos de trazabilidad y
 * operación, y el body con los campos específicos de la operación que se
 * está realizando.
 *
 * <p>
 * Estructura en JSON:
 * 
 * <pre>
 * {
 *   "data": {
 *     "header": {
 *       "date": "20261201",
 *       "instanceId": "01",
 *       "system": "BM",
 *       "hour": "083000",
 *       "locationUser": "192.168.1.1",
 *       "batch": "3711",
 *       "branch": "037",
 *       "user": "jperez",
 *       "channelId": "000003711",
 *       "supervisor": "0080"
 *     },
 *     "body": { ... }
 *   }
 * }
 * </pre>
 *
 * <p>
 * El {@code header} es condicional según el estándar — se incluye
 * únicamente en operaciones que lo incorporen por especificaciones técnicas y
 * sus campos se completan según aplique para cada operación. El {@code body}
 * es requerido y su estructura la define el microservicio para cada endpoint.
 *
 * @param <B>    tipo del body específico de la operación, definido por el
 *               microservicio consumidor.
 * @param header header del request con los campos de trazabilidad y
 *               operación. Condicional según la operación.
 * @param body   campos específicos de la operación que se está realizando.
 *               Su estructura es definida por el microservicio. Requerido.
 *
 * @author Jose Luis Pereira
 * @see CoreRequestHeader
 * @see ResponseData
 * @see RequestEnvelope
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record RequestData<B>(
        @Valid CoreRequestHeader header,
        @NotNull(message = "body es requerido") @Valid B body) {
}
