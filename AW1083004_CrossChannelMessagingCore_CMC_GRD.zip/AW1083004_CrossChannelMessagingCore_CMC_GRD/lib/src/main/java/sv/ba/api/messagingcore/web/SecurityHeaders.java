package sv.ba.api.messagingcore.web;

import jakarta.servlet.http.HttpServletResponse;

/**
 * Utilidad para aplicar los headers de seguridad requeridos por el estándar
 * en las respuestas HTTP.
 *
 * <p>
 * Los headers de seguridad aplican tanto a respuestas exitosas como a
 * respuestas de error, conforme al estándar que indica que ambas deben
 * incluirlos.
 *
 * <p>
 * Se usa en dos puntos de la librería:
 * <ul>
 * <li>{@link SecurityHeadersFilter} — para respuestas exitosas, aplicando
 * los headers automáticamente en cada request.</li>
 * <li>{@link ApiExceptionHandler} — para respuestas de error, aplicando
 * los headers antes de retornar el
 * {@link sv.ba.api.messagingcore.envelope.ErrorEnvelope}.</li>
 * </ul>
 *
 * <p>
 * El método {@link #setIfAbsent(HttpServletResponse, String, String)} garantiza
 * que si el microservicio ya definió un header con un valor personalizado,
 * esta utilidad no lo sobreescribe — respetando la flexibilidad del
 * desarrollador.
 *
 * <p>
 * Esta clase no puede ser instanciada — su único método es estático.
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see SecurityHeadersFilter
 * @see ApiExceptionHandler
 */
public final class SecurityHeaders {

    private SecurityHeaders() {
    }

    /**
     * Aplica los headers de seguridad requeridos por el estándar en la
     * respuesta HTTP. Solo agrega los headers que aún no han sido definidos
     * — no sobreescribe valores personalizados del microservicio.
     *
     * <p>
     * Headers aplicados con sus valores por defecto:
     * <ul>
     * <li>{@code Strict-Transport-Security: max-age=31536000} — fuerza
     * comunicación solo a través de HTTPS.</li>
     * <li>{@code X-Frame-Options: DENY} — previene carga de contenido
     * en iframes.</li>
     * <li>{@code Content-Security-Policy: self} — restringe el tipo de
     * contenido que puede procesar el navegador.</li>
     * <li>{@code Content-Type: application/json} — indica el tipo de
     * contenido de la respuesta.</li>
     * <li>{@code Expect-CT: max-age=604800,enforce} — aplica política de
     * Transparencia de Certificados.</li>
     * <li>{@code X-XSS-Protection: 1; mode=block} — protege contra
     * ataques XSS.</li>
     * <li>{@code X-Content-Type-Options: nosniff} — previene la
     * autodetección de tipo de contenido.</li>
     * <li>{@code Cache-Control: none} — controla el almacenamiento en
     * caché.</li>
     * <li>{@code Pragma: no-cache} — control de caché para clientes
     * legacy.</li>
     * <li>{@code Expires: 0} — indica que el contenido expira
     * inmediatamente.</li>
     * <li>{@code X-Powered-By: exists-action="delete"} — oculta
     * información sobre las tecnologías utilizadas por el servidor.</li>
     * </ul>
     *
     * @param response respuesta HTTP sobre la que se aplican los headers.
     * @see #setIfAbsent(HttpServletResponse, String, String)
     */
    public static void apply(HttpServletResponse response) {
        setIfAbsent(response, "Strict-Transport-Security", "max-age=31536000");
        setIfAbsent(response, "X-Frame-Options", "DENY");
        setIfAbsent(response, "Content-Security-Policy", "self");
        setIfAbsent(response, "Content-Type", "application/json");
        setIfAbsent(response, "Expect-CT", "max-age=604800,enforce");
        setIfAbsent(response, "X-XSS-Protection", "1; mode=block");
        setIfAbsent(response, "X-Content-Type-Options", "nosniff");
        setIfAbsent(response, "Cache-Control", "none");
        setIfAbsent(response, "Pragma", "no-cache");
        setIfAbsent(response, "Expires", "0");
        setIfAbsent(response, "X-Powered-By", "exists-action=\"delete\"");
    }

    /**
     * Agrega un header a la respuesta solo si no ha sido definido previamente.
     * Esto garantiza que los valores personalizados del microservicio no sean
     * sobreescritos por los valores por defecto de la librería.
     *
     * @param response respuesta HTTP sobre la que se aplica el header.
     * @param header   nombre del header HTTP.
     * @param value    valor del header a aplicar.
     */
    private static void setIfAbsent(HttpServletResponse response, String header, String value) {
        if (!response.containsHeader(header)) {
            response.setHeader(header, value);
        }
    }

}
