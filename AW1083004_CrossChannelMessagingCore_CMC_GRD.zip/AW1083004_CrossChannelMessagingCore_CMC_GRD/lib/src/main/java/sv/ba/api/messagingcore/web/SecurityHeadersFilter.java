package sv.ba.api.messagingcore.web;

import java.io.IOException;

import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Filtro que aplica automáticamente los headers de seguridad requeridos por
 * el estándar en todas las respuestas HTTP exitosas.
 *
 * <p>
 * Extiende {@link OncePerRequestFilter} para garantizar que se ejecute
 * exactamente una vez por request, evitando duplicación de headers en
 * peticiones con múltiples dispatch.
 *
 * <p>
 * El filtro delega la aplicación de los headers a
 * {@link Securityheaders#apply(HttpServletResponse)},
 * que los agrega solo si no han sido definidos previamente — respetando
 * cualquier valor personalizado del microservicio.
 *
 * <p>
 * El orden de ejecución es importante: primero se procesa la cadena de
 * filtros completa ({@code filterChain.doFilter}) y luego se aplican los
 * headers de seguridad, garantizando que la respuesta ya esté construida
 * antes de agregar los headers.
 *
 * <p>
 * Para las respuestas de error, los headers se aplican directamente desde
 * el {@link ApiExceptionHandler} ya que el dispatch de error puede no pasar
 * por este filtro.
 *
 * <p>
 * Se registra automáticamente como bean de Spring a través de
 * {@link sv.ba.api.messagingcore.config.MessagingCoreConfiguration}. Si el
 * microservicio declara su propia implementación, este filtro no se registra
 * gracias al mecanismo {@code @ConditionalOnMissingBean}.
 *
 * @author Jose Luis Pereira
 * @see Securityheaders
 * @see ApiExceptionHandler
 * @see sv.ba.api.messagingcore.config.MessagingCoreConfiguration
 */
public class SecurityHeadersFilter extends OncePerRequestFilter {

    /**
     * Procesa el request, ejecuta la cadena de filtros y aplica los headers
     * de seguridad sobre la respuesta resultante.
     *
     * @param request     request HTTP entrante.
     * @param response    respuesta HTTP sobre la que se aplicarán los headers
     *                    de seguridad.
     * @param filterChain cadena de filtros a ejecutar antes de aplicar los
     *                    headers.
     * @throws ServletException si ocurre un error en el procesamiento del
     *                          servlet.
     * @throws IOException      si ocurre un error de entrada/salida durante
     *                          el procesamiento.
     * @see Securityheaders#apply(HttpServletResponse)
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        filterChain.doFilter(request, response);
        SecurityHeaders.apply(response);
    }

}
