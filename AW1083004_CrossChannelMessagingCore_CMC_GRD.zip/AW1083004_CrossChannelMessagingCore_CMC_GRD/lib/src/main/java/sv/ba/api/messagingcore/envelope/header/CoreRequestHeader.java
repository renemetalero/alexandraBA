package sv.ba.api.messagingcore.envelope.header;

import com.fasterxml.jackson.annotation.JsonInclude;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import sv.ba.api.messagingcore.envelope.validator.date.ValidDate;
import sv.ba.api.messagingcore.envelope.validator.time.ValidHour;

/**
 * Representa el objeto {@code header} dentro de {@code data} para las
 * solicitudes (request).
 *
 * <p>
 * Contiene los campos necesarios para la trazabilidad y operación de cada
 * petición. Todos los campos son condicionales según el estándar — se incluyen
 * únicamente los que aplican a la operación que se está realizando.
 *
 * <p>
 * Formatos especiales de fecha y hora:
 * <ul>
 * <li>{@code date} — se serializa y deserializa en formato
 * {@code YYYYMMDD}.</li>
 * <li>{@code hour} — se serializa y deserializa en formato {@code HHMMSS}.</li>
 * </ul>
 *
 * <p>
 * Al construir la respuesta, los campos {@code supervisor}, {@code user} y
 * {@code locationUser} no deben incluirse. Para obtener el header de respuesta
 * correspondiente usar
 * {@link CoreResponseHeader#fromRequestHeader(CoreRequestHeader)}.
 *
 * @param date         fecha en que se realiza la operación en formato
 *                     {@code YYYYMMDD}.
 *                     Ejemplo: {@code "20261201"}.
 * @param instanceId   número de instancia del canal que genera la transacción.
 *                     Numérico de hasta 2 dígitos. Ejemplo: {@code 21}.
 * @param system       identificador del canal o aplicación que realiza la
 *                     operación.
 *                     Máximo 10 caracteres. Ejemplo: {@code "BM"}.
 * @param hour         hora en que se realiza la operación en formato
 *                     {@code HHMMSS}.
 *                     Ejemplo: {@code "083000"}.
 * @param locationUser dirección IP del usuario o aplicación que realiza la
 *                     operación
 *                     en formato IPv4. Máximo 15 caracteres.
 *                     Ejemplo: {@code "192.168.1.1"}.
 * @param batch        código de cajero, relleno de ceros a la izquierda.
 *                     Máximo 4 caracteres. Ejemplo: {@code "3700"}.
 * @param branch       código de agencia IBS, relleno de ceros a la izquierda.
 *                     Numérico de hasta 3 dígitos. Ejemplo:
 *                     {@code 137}.
 * @param user         identificador del usuario del canal o aplicación que
 *                     realiza
 *                     la operación. Máximo 20 caracteres.
 * @param channelId    identificador del canal, relleno de ceros a la izquierda
 *                     si
 *                     es numérico. Máximo 9 caracteres. Ejemplo:
 *                     {@code "000003711"}.
 * @param supervisor   código del supervisor que autoriza la transacción.
 *                     Numérico
 *                     de hasta 4 dígitos. Ejemplo: {@code 2080}.
 *
 * @author Jose Luis Pereira
 * @see CoreResponseHeader
 * @see CoreResponseHeader#fromRequestHeader(CoreRequestHeader)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CoreRequestHeader(

        @ValidDate Integer date,

        @Min(0) @Max(value = 99, message = "instanceId debe ser numérico de hasta 2 dígitos") Integer instanceId,

        @Size(max = 10) String system,

        @ValidHour Integer hour,

        @Size(max = 15) String locationUser,

        @Size(max = 4) String batch,

        @Min(0) @Max(value = 999, message = "branch debe ser numérico de 3 dígitos") Integer branch,

        @Size(max = 20) String user,

        @Size(max = 9) String channelId,

        @Min(0) @Max(value = 9999, message = "supervisor debe ser numérico de 4 dígitos") Integer supervisor) {
}
