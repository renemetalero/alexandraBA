package sv.ba.api.messagingcore.exception;

import java.util.List;

import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorPrefix;

/**
 * Excepción que representa un error de sistema propio del API.
 * Utiliza el prefijo {@link ErrorPrefix#SA}.
 *
 * <p>
 * Se lanza cuando la falla se origina dentro del propio API, sin
 * involucrar a ningún proveedor externo. Ejemplos de uso:
 * <ul>
 * <li>Error en la validación interna de datos.</li>
 * <li>Problema de configuración del propio servicio.</li>
 * <li>Error inesperado dentro de la lógica del API.</li>
 * </ul>
 *
 * <p>
 * Uso directo:
 * 
 * <pre>
 * throw new SystemApiException(500, "19003", "API",
 *         "Error inesperado en el procesamiento");
 * </pre>
 *
 * <p>
 * Uso recomendado — crear una excepción específica en el microservicio:
 * 
 * <pre>
 * public class ProcesamientoException extends SystemApiException {
 *     public ProcesamientoException() {
 *         super(500, "19003", "API", "Error inesperado en el procesamiento");
 *     }
 * }
 * </pre>
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see ApiException
 * @see ErrorPrefix#SA
 * @see BusinessProviderException
 * @see SystemProviderException
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
public final class SystemApiException extends ApiException {

    /**
     * Constructor principal.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19003"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "API"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     */
    public SystemApiException(int httpStatus, String errorCode,
            String title, String detail) {
        super(httpStatus, errorCode, title, detail);
    }

    /**
     * Constructor con causa. Útil para preservar la excepción original.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19003"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "API"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     * @param cause      excepción original que provocó este error.
     */
    public SystemApiException(int httpStatus, String errorCode,
            String title, String detail, Throwable cause) {
        super(httpStatus, errorCode, title, detail, cause);
    }

    /**
     * Constructor con lista de errores. Para casos donde la operación
     * produce múltiples errores simultáneos.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errors     lista de {@link ApiError} ya construidos con sus
     *                   códigos completos. No puede ser {@code null} ni vacía.
     */
    public SystemApiException(int httpStatus, List<ApiError> errors) {
        super(httpStatus, errors);
    }

    /**
     * {@inheritDoc}
     *
     * @return {@link ErrorPrefix#SA}
     */
    @Override
    public ErrorPrefix prefix() {
        return ErrorPrefix.SA;
    }
}
