package sv.ba.api.messagingcore.exception;

import java.util.List;
import java.util.Objects;

import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorCodeBuilder;
import sv.ba.api.messagingcore.error.ErrorPrefix;

/**
 * Excepción base de la librería para el manejo de errores del estándar.
 *
 * <p>
 * Es {@code sealed} — solo las subclases definidas en este paquete pueden
 * extenderla, lo que permite al compilador garantizar exhaustividad en
 * expresiones {@code switch} sobre la jerarquía:
 * 
 * <pre>
 * String prefijo = switch (ex) {
 *     case BusinessProviderException e -> "BP";
 *     case SystemProviderException e -> "SP";
 *     case SystemApiException e -> "SA";
 *     case SystemInfrastructureException e -> "SI";
 *     case SystemMiddlewareException e -> "SM";
 * };
 * </pre>
 *
 * <p>
 * Cada subclase concreta fija su {@link ErrorPrefix} a través del método
 * abstracto {@link #prefix()} y construye su propio {@link ApiError}
 * internamente. El desarrollador solo necesita indicar el código EVC, el
 * título del sistema que reporta el error y el detalle funcional:
 * 
 * <pre>
 * throw new BusinessProviderException(409, "19001", "IBS", "La cuenta está bloqueada");
 * </pre>
 *
 * <p>
 * El {@link sv.ba.api.messagingcore.web.ApiExceptionHandler} intercepta
 * automáticamente cualquier subclase y construye el
 * {@link sv.ba.api.messagingcore.envelope.ErrorEnvelope} correspondiente
 * sin intervención del desarrollador.
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see BusinessProviderException
 * @see SystemProviderException
 * @see SystemApiException
 * @see SystemInfrastructureException
 * @see SystemMiddlewareException
 * @see ErrorPrefix
 * @see ApiError
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
public abstract sealed class ApiException extends RuntimeException permits
        BusinessProviderException,
        SystemProviderException,
        SystemApiException,
        SystemInfrastructureException,
        SystemMiddlewareException {

    private final int httpStatus;
    private final List<ApiError> errors;

    /**
     * Constructor principal. Construye el código de error internamente
     * combinando el prefijo de la subclase, el código HTTP y el código EVC.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19001"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "IBS"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     * @throws IllegalArgumentException si {@code httpStatus} está fuera del
     *                                  rango 100-599 o {@code errorCode} no
     *                                  tiene exactamente 5 dígitos numéricos.
     */
    protected ApiException(int httpStatus, String errorCode, String title, String detail) {
        super(detail);
        this.httpStatus = httpStatus;
        String code = ErrorCodeBuilder.build(prefix(), httpStatus, errorCode);
        this.errors = List.of(new ApiError(code, title, detail));
    }

    /**
     * Constructor con causa. Útil cuando se quiere preservar la excepción
     * original que provocó el error.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19001"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "IBS"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     * @param cause      excepción original que provocó este error.
     */
    protected ApiException(int httpStatus, String errorCode, String title, String detail,
            Throwable cause) {
        super(detail, cause);
        this.httpStatus = httpStatus;
        String code = ErrorCodeBuilder.build(prefix(), httpStatus, errorCode);
        this.errors = List.of(new ApiError(code, title, detail));
    }

    /**
     * Constructor con lista de errores. Útil cuando una operación produce
     * múltiples errores simultáneos que deben reportarse juntos. Los
     * {@link ApiError} deben venir ya construidos con sus códigos completos.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errors     lista de errores a incluir en la respuesta. No puede
     *                   ser {@code null} ni estar vacía.
     * @throws NullPointerException     si {@code errors} es {@code null}.
     * @throws IllegalArgumentException si {@code errors} está vacío.
     */
    protected ApiException(int httpStatus, List<ApiError> errors) {
        super(extractFirstDetail(errors));
        this.httpStatus = httpStatus;
        this.errors = List.copyOf(Objects.requireNonNull(errors, "errors no puede ser null"));
        if (this.errors.isEmpty()) {
            throw new IllegalArgumentException("errors no puede estar vacío");
        }
    }

    /**
     * Retorna el prefijo de categorización del error. Cada subclase lo
     * implementa retornando su {@link ErrorPrefix} correspondiente.
     *
     * @return prefijo del error. Ejemplo: {@link ErrorPrefix#BP}.
     */
    public abstract ErrorPrefix prefix();

    /**
     * Retorna el código HTTP con el que se responderá al consumidor.
     *
     * @return código HTTP. Ejemplo: {@code 409}.
     */
    public int httpStatus() {
        return httpStatus;
    }

    /**
     * Retorna la lista inmutable de errores que se incluirán en el
     * {@link sv.ba.api.messagingcore.envelope.ErrorEnvelope}.
     *
     * @return lista inmutable de {@link ApiError} con al menos un elemento.
     */
    public List<ApiError> errors() {
        return errors;
    }

    /**
     * Extrae el {@code detail} del primer error de la lista para usarlo como
     * mensaje de la excepción. Retorna {@code null} si la lista es nula o vacía.
     *
     * @param errors lista de errores de la que se extrae el detalle.
     * @return detalle del primer error, o {@code null} si no hay errores.
     */
    private static String extractFirstDetail(List<ApiError> errors) {
        if (errors == null || errors.isEmpty())
            return null;
        return errors.get(0).detail();
    }
}
