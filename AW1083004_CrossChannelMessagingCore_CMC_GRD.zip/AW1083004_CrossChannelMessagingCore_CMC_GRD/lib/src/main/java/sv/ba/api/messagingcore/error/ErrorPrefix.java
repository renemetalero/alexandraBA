package sv.ba.api.messagingcore.error;

/**
 * Define los prefijos de categorización de errores establecidos por el
 * estándar.
 *
 * <p>
 * Cada prefijo identifica el origen y la naturaleza del error ocurrido,
 * permitiendo al consumidor del API determinar rápidamente qué sistema
 * reportó la falla y si es un error de negocio o de sistema.
 *
 * <p>
 * El prefijo forma parte del código de error compuesto junto con el código
 * HTTP y el código EVC asignado al error específico:
 * 
 * <pre>
 *   código = &lt;prefijo&gt; + &lt;httpStatus&gt; + &lt;errorCode&gt;
 *   ejemplo: BP + 409 + 19001 = BP40919001
 * </pre>
 *
 * @author Jose Luis Pereira
 * @see ApiError
 * @see ErrorCodeBuilder
 * @see sv.ba.api.messagingcore.exception.ApiException
 */
public enum ErrorPrefix {

    /**
     * Business Provider — error de negocio en el proveedor o backend
     * con el que interactúa el API.
     * Ejemplo: cuenta bloqueada, saldo insuficiente, cliente no existe.
     */
    BP,

    /**
     * System Provider — error de sistema en el proveedor o backend
     * con el que interactúa el API.
     * Ejemplo: timeout del proveedor, respuesta malformada, servicio no disponible.
     */
    SP,

    /**
     * System API — error de sistema propio del API.
     * Ejemplo: error de validación interna, problema de configuración,
     * error inesperado dentro del propio servicio.
     */
    SA,

    /**
     * System Infrastructure — error en la infraestructura de la capa media.
     * Aplica cuando la falla se origina en la plataforma de integración,
     * no en el API ni en el proveedor.
     */
    SI,

    /**
     * System Middleware API — error propio del API de capa media.
     * Aplica cuando la falla ocurre dentro del API implementada en los
     * componentes de integración empresarial o transaccional.
     */
    SM;

    /**
     * Retorna el nombre del prefijo como {@code String}.
     *
     * @return nombre del prefijo. Ejemplo: {@code "BP"}.
     */
    public String value() {
        return name();
    }
}
