package sv.ba.api.messagingcore.envelope;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import sv.ba.api.messagingcore.envelope.pagination.Links;
import sv.ba.api.messagingcore.envelope.pagination.ResponsePagination;

/**
 * Envelope raíz de una respuesta exitosa del API.
 *
 * <p>
 * Encapsula la estructura estándar de mensajería para todas las respuestas
 * con código HTTP {@code 200}. Es el tipo de retorno esperado en todos los
 * endpoints que implementan el estándar.
 *
 * <p>
 * Estructura en JSON:
 * 
 * <pre>
 * {
 *   "metadata": {
 *     "_messageId": "...",
 *     "_correlationId": "...",
 *     "_datetime": "..."
 *   },
 *   "data": {
 *     "header": { ... },
 *     "body": { ... }
 *   },
 *   "responsePagination": {
 *     "lastPageIndicator": false,
 *     "totalRecords": 50
 *   }
 * }
 * </pre>
 *
 * <p>
 * El campo {@code responsePagination} es opcional — solo se incluye cuando
 * el endpoint retorna resultados paginados. Los campos con valor {@code null}
 * se omiten automáticamente en la serialización JSON gracias a
 * {@link JsonInclude}.
 *
 * <p>
 * La forma recomendada de construir una instancia es a través de
 * {@link sv.ba.api.messagingcore.factory.MessageFactory}:
 * 
 * <pre>
 * // Sin paginación
 * return factory.success(body);
 *
 * // Con paginación
 * return factory.success(body, new ResponsePagination(true, 50));
 * </pre>
 *
 * @param <B>                tipo del body específico de la operación, definido
 *                           por el microservicio consumidor.
 * @param metadata           datos de trazabilidad del mensaje. Requerido.
 * @param data               contenedor del header y el body
 *                           de la respuesta. Requerido.
 * @param responsePagination información de paginación de la respuesta.
 *                           Opcional,
 *                           solo presente en consultas paginadas.
 *
 * @author Jose Luis Pereira
 * @see Metadata
 * @see ResponseData
 * @see ResponsePagination
 * @see sv.ba.api.messagingcore.factory.MessageFactory
 * @see ErrorEnvelope
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ResponseEnvelope<B>(
        @NotNull @Valid Metadata metadata,
        @NotNull @Valid ResponseData<B> data,
        @Valid ResponsePagination responsePagination,
        @Valid Links links) {
}
