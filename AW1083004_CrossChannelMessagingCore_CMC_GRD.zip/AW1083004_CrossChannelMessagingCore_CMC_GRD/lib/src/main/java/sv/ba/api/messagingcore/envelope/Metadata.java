package sv.ba.api.messagingcore.envelope;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

/**
 * Representa el objeto {@code metadata} presente en todas las estructuras de
 * mensajería del estándar — request, respuesta exitosa y respuesta de error.
 *
 * <p>
 * Contiene los campos de trazabilidad que permiten identificar y correlacionar
 * cada mensaje a lo largo de su ciclo de vida. Los campos se serializan con
 * guion bajo ({@code _messageId}, {@code _correlationId}, {@code _datetime})
 * conforme al estándar, mediante {@link JsonProperty}.
 *
 * <p>
 * Estructura en JSON:
 * 
 * <pre>
 * {
 *   "metadata": {
 *     "_messageId": "89d75300-4048-42b0-8907-2192dceb6fbe",
 *     "_correlationId": "e13a7e3e-7a59-40ea-b899-5a0f7f02cdcc",
 *     "_datetime": "2026-04-08T17:33:00"
 *   }
 * }
 * </pre>
 *
 * <p>
 * Comportamiento del {@code _correlationId} en la respuesta:
 * <ul>
 * <li>Si el request incluye {@code _correlationId}, el mismo valor se
 * propaga a la respuesta.</li>
 * <li>Si el request no incluye {@code _correlationId}, la respuesta
 * tampoco lo lleva — no se genera uno nuevo.</li>
 * </ul>
 *
 * <p>
 * La generación de instancias es responsabilidad exclusiva de
 * {@link sv.ba.api.messagingcore.factory.EnvelopeBuilder}, que garantiza
 * que el {@code _messageId} sea siempre un UUID nuevo y el {@code _datetime}
 * el timestamp actual en el momento de construir la respuesta.
 *
 * @param messageId     identificador único del mensaje en formato UUID.
 *                      Se genera automáticamente para cada respuesta.
 *                      Requerido.
 * @param correlationId identificador que relaciona todos los mensajes de una
 *                      misma transacción en formato UUID. Opcional — se propaga
 *                      desde el request si está disponible.
 * @param datetime      timestamp local en que se emite el mensaje, en formato
 *                      {@code YYYY-MM-DDTHH:MM:SS}. Requerido.
 *
 * @author Jose Luis Pereira
 * @see sv.ba.api.messagingcore.factory.EnvelopeBuilder
 * @see sv.ba.api.messagingcore.web.RequestContextAdvice
 * @see RequestEnvelope
 * @see ResponseEnvelope
 * @see ErrorEnvelope
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record Metadata(
        @JsonProperty("_messageId") @NotBlank @Pattern(regexp = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", message = "_messageId debe tener formato UUID") String messageId,
        @JsonProperty("_correlationId") @Pattern(regexp = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", message = "_correlationId debe tener formato UUID") String correlationId,
        @JsonProperty("_datetime") @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss") @NotNull LocalDateTime datetime) {
}
