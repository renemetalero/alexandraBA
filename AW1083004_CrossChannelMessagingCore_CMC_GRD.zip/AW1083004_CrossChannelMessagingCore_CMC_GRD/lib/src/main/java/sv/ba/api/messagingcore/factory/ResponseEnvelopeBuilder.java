package sv.ba.api.messagingcore.factory;

import java.util.Objects;

import sv.ba.api.messagingcore.envelope.ResponseData;
import sv.ba.api.messagingcore.envelope.ResponseEnvelope;
import sv.ba.api.messagingcore.envelope.header.CoreResponseHeader;
import sv.ba.api.messagingcore.envelope.pagination.Links;
import sv.ba.api.messagingcore.envelope.pagination.ResponsePagination;
import sv.ba.api.messagingcore.web.ApiRequestContext;

/**
 * Builder para construir {@link ResponseEnvelope} de respuestas exitosas.
 *
 * <p>
 * Se obtiene a través de {@link MessageFactory#responseBuilder()} — no se
 * instancia directamente. Hereda la generación de
 * {@link sv.ba.api.messagingcore.envelope.Metadata}
 * de {@link EnvelopeBuilder}, que obtiene el {@code _correlationId} y el
 * header automáticamente desde el {@link ApiRequestContext} sin intervención
 * del desarrollador.
 *
 * <p>
 * La forma más común de uso es a través del método corto de
 * {@link MessageFactory}, que internamente usa este builder:
 * 
 * <pre>
 * // Sin paginación
 * return factory.success(body);
 *
 * // Con paginación
 * return factory.success(body, new ResponsePagination(true, 50));
 * </pre>
 *
 * <p>
 * Para casos que requieren control granular sobre el header o la paginación,
 * el builder puede usarse directamente:
 * 
 * <pre>
 * // Con header personalizado
 * return factory.&lt;MiResponse&gt;responseBuilder()
 *         .withHeader(miHeaderPersonalizado)
 *         .withBody(body)
 *         .build();
 *
 * // Con paginación
 * return factory.&lt;MiResponse&gt;responseBuilder()
 *         .withBody(body)
 *         .withPagination(new ResponsePagination(false, 100))
 *         .build();
 * </pre>
 *
 * @param <B> tipo del body específico de la operación, definido por el
 *            microservicio consumidor.
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see EnvelopeBuilder
 * @see MessageFactory
 * @see ErrorEnvelopeBuilder
 * @see ResponseEnvelope
 * @see ApiRequestContext
 */
public final class ResponseEnvelopeBuilder<B>
        extends EnvelopeBuilder<ResponseEnvelope<B>> {

    private CoreResponseHeader header;
    private B body;
    private ResponsePagination pagination;
    private Links links;

    ResponseEnvelopeBuilder(ApiRequestContext requestContext) {
        super(requestContext);
    }

    /**
     * Especifica un header de respuesta personalizado. Si no se llama a este
     * método, el header se deriva automáticamente del header del request
     * disponible en el {@link ApiRequestContext}.
     *
     * @param header header de respuesta personalizado.
     * @return este builder para encadenamiento de llamadas.
     * @see CoreResponseHeader
     * @see CoreResponseHeader#fromRequestHeader(sv.ba.api.messagingcore.envelope.header.CoreRequestHeader)
     */
    public ResponseEnvelopeBuilder<B> withHeader(CoreResponseHeader header) {
        this.header = header;
        return this;
    }

    /**
     * Especifica el body de la respuesta generado por la lógica de negocio
     * del microservicio.
     *
     * @param body resultado de la operación. Requerido para construir
     *             el envelope.
     * @return este builder para encadenamiento de llamadas.
     */
    public ResponseEnvelopeBuilder<B> withBody(B body) {
        this.body = body;
        return this;
    }

    /**
     * Especifica la información de paginación de la respuesta. Opcional —
     * solo se incluye cuando el endpoint retorna resultados paginados.
     *
     * @param pagination información de paginación con el indicador de última
     *                   página y el total de registros.
     * @return este builder para encadenamiento de llamadas.
     * @see ResponsePagination
     */
    public ResponseEnvelopeBuilder<B> withPagination(ResponsePagination pagination) {
        this.pagination = pagination;
        return this;
    }

    public ResponseEnvelopeBuilder<B> withLinks(Links links) {
        this.links = links;
        return this;
    }

    /**
     * Construye el {@link ResponseEnvelope} con la metadata, header y body
     * resueltos. El {@code body} es obligatorio — lanza
     * {@link NullPointerException} si no fue especificado.
     *
     * @return {@link ResponseEnvelope} listo para retornar al consumidor.
     * @throws NullPointerException si {@code body} es {@code null}.
     */
    @Override
    public ResponseEnvelope<B> build() {
        Objects.requireNonNull(body, "body es requerido para construir el ResponseEnvelope");
        return new ResponseEnvelope<>(
                resolveResponseMetadata(),
                new ResponseData<>(resolveHeader(), body),
                pagination,
                links);
    }

    /**
     * Resuelve el header de respuesta. Si se especificó un header personalizado
     * con {@link #withHeader(CoreResponseHeader)}, lo usa directamente. De lo
     * contrario, lo deriva del header del request disponible en el
     * {@link ApiRequestContext}.
     *
     * @return header de respuesta resuelto, o {@code null} si no hay header
     *         disponible en el contexto.
     */
    private CoreResponseHeader resolveHeader() {
        if (header != null)
            return header;
        return CoreResponseHeader.fromRequestHeader(requestContext.getHeader());
    }
}
