package sv.ba.api.messagingcore.envelope.pagination;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/**
 * Representa el objeto {@code pagination} enviado en el request para controlar
 * la paginación de resultados en consultas que retornan múltiples registros.
 *
 * <p>
 * Se ubica al mismo nivel que {@code data} en la estructura del
 * {@link sv.ba.api.messagingcore.envelope.RequestEnvelope} y es opcional —
 * solo se incluye cuando el endpoint soporta paginación.
 *
 * <p>
 * Ejemplo de uso en el request:
 * 
 * <pre>
 * {
 *   "metadata": { ... },
 *   "data": { ... },
 *   "pagination": {
 *     "pageNumber": 1,
 *     "pageSize": 10
 *   }
 * }
 * </pre>
 *
 * <p>
 * La respuesta correspondiente incluirá un objeto
 * {@link ResponsePagination} con el indicador de última página y el
 * total de registros encontrados.
 *
 * @param pageNumber número de página solicitada. Debe ser mayor o igual a 1.
 * @param pageSize   cantidad de registros por página. Debe ser mayor o igual a
 *                   1.
 *
 * @author Jose Luis Pereira
 * @see ResponsePagination
 * @see sv.ba.api.messagingcore.envelope.RequestEnvelope
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record Pagination(
        @NotNull @Min(value = 1, message = "pageNumber debe ser mayor o igual a 1") Integer pageNumber,
        @NotNull @Min(value = 1, message = "pageSize debe ser mayor o igual a 1") Integer pageSize) {
}
