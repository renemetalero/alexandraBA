package sv.ba.api.messagingcore.envelope;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import sv.ba.api.messagingcore.envelope.pagination.Pagination;

/**
 * Envelope raíz de una solicitud (request) al API.
 *
 * <p>
 * Encapsula la estructura estándar de mensajería para todas las peticiones
 * entrantes. Es el tipo esperado como {@code @RequestBody} en todos los
 * endpoints que implementan el estándar.
 *
 * <p>
 * Estructura en JSON:
 * 
 * <pre>
 * {
 *   "metadata": {
 *     "_messageId": "...",
 *     "_correlationId": "...",
 *     "_datetime": "..."
 *   },
 *   "data": {
 *     "header": { ... },
 *     "body": { ... }
 *   },
 *   "pagination": {
 *     "pageNumber": 1,
 *     "pageSize": 10
 *   }
 * }
 * </pre>
 *
 * <p>
 * El campo {@code pagination} es opcional — solo se incluye cuando el
 * endpoint soporta paginación. Los campos con valor {@code null} se omiten
 * automáticamente en la serialización JSON.
 *
 * <p>
 * Ejemplo de uso en un controller:
 * 
 * <pre>
 * &#64;PostMapping("/consulta")
 * public ResponseEnvelope&lt;MiResponse&gt; consultar(
 *         &#64;RequestBody &#64;Valid RequestEnvelope&lt;MiRequest&gt; request) {
 *     return factory.success(service.procesar(request.data().body()));
 * }
 * </pre>
 *
 * <p>
 * Una vez que Spring deserializa el envelope, el
 * {@link sv.ba.api.messagingcore.web.RequestContextAdvice} extrae
 * automáticamente el {@code metadata} y el {@code header} para almacenarlos
 * en el {@link sv.ba.api.messagingcore.web.ApiRequestContext}, disponibles
 * durante la totalidad del ciclo de vida del request.
 *
 * @param <B>        tipo del body específico de la operación, definido por el
 *                   microservicio consumidor.
 * @param metadata   datos de trazabilidad del mensaje. Requerido.
 * @param data       contenedor del header y el body de la
 *                   solicitud. Requerido.
 * @param pagination parámetros de paginación de la consulta. Opcional, solo
 *                   presente en endpoints que retornan múltiples registros.
 *
 * @author Jose Luis Pereira
 * @see Metadata
 * @see RequestData
 * @see Pagination
 * @see ResponseEnvelope
 * @see sv.ba.api.messagingcore.web.RequestContextAdvice
 * @see sv.ba.api.messagingcore.factory.MessageFactory
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record RequestEnvelope<B>(
        @NotNull(message = "data es requerido") @Valid RequestData<B> data,
        @Valid Pagination pagination) {
}
