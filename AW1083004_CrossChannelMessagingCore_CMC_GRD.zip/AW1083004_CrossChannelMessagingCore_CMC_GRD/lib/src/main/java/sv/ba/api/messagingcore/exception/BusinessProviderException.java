package sv.ba.api.messagingcore.exception;

import java.util.List;

import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorPrefix;

/**
 * Excepción que representa un error de negocio en el proveedor o backend
 * con el que interactúa el API. Utiliza el prefijo {@link ErrorPrefix#BP}.
 *
 * <p>
 * Se lanza cuando la falla se origina en el sistema proveedor y es de
 * naturaleza funcional o de negocio — no un error técnico de sistema.
 * Ejemplos de uso:
 * <ul>
 * <li>Cuenta bloqueada o inactiva.</li>
 * <li>Saldo insuficiente para realizar la operación.</li>
 * <li>Cliente o recurso no encontrado en el proveedor.</li>
 * <li>Operación no permitida según las reglas de negocio.</li>
 * </ul>
 *
 * <p>
 * Uso directo:
 * 
 * <pre>
 * throw new BusinessProviderException(409, "19001", "IBS",
 *         "La cuenta está bloqueada");
 * </pre>
 *
 * <p>
 * Uso recomendado — crear una excepción específica en el microservicio:
 * 
 * <pre>
 * public class CuentaBloqueadaException extends BusinessProviderException {
 *     public CuentaBloqueadaException() {
 *         super(409, "19001", "IBS", "La cuenta está bloqueada");
 *     }
 * }
 * </pre>
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see ApiException
 * @see ErrorPrefix#BP
 * @see SystemProviderException
 * @see SystemApiException
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
public final class BusinessProviderException extends ApiException {

    /**
     * Constructor principal.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19001"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "IBS"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     */
    public BusinessProviderException(int httpStatus, String errorCode,
            String title, String detail) {
        super(httpStatus, errorCode, title, detail);
    }

    /**
     * Constructor con causa. Útil para preservar la excepción original.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19001"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "IBS"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     * @param cause      excepción original que provocó este error.
     */
    public BusinessProviderException(int httpStatus, String errorCode,
            String title, String detail, Throwable cause) {
        super(httpStatus, errorCode, title, detail, cause);
    }

    /**
     * Constructor con lista de errores. Para casos donde la operación
     * produce múltiples errores de negocio simultáneos.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errors     lista de {@link ApiError} ya construidos con sus
     *                   códigos completos. No puede ser {@code null} ni vacía.
     */
    public BusinessProviderException(int httpStatus, List<ApiError> errors) {
        super(httpStatus, errors);
    }

    /**
     * {@inheritDoc}
     *
     * @return {@link ErrorPrefix#BP}
     */
    @Override
    public ErrorPrefix prefix() {
        return ErrorPrefix.BP;
    }
}
