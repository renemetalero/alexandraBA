package sv.ba.api.messagingcore.envelope.pagination;

/**
 * DTO inmutable para transferencia de datos...
 *
 * @author Jose Luis Pereira
 */
public record Links(
        String self,
        String first,
        String prev,
        String next,
        String last) {

}
