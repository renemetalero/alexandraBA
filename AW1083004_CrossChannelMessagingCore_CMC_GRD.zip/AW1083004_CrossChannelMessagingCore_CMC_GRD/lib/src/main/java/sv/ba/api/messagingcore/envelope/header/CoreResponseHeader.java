package sv.ba.api.messagingcore.envelope.header;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import sv.ba.api.messagingcore.envelope.validator.date.ValidDate;
import sv.ba.api.messagingcore.envelope.validator.time.ValidHour;


/**
 * Representa el objeto {@code header} dentro de {@code data} para las
 * respuestas exitosas del API.
 *
 * <p>
 * Es un subconjunto de {@link CoreRequestHeader} — según el estándar, los
 * campos {@code supervisor}, {@code user} y {@code locationUser} no deben
 * incluirse en la respuesta. El resto de campos se conservan tal como vienen
 * en el request.
 *
 * <p>
 * Formatos especiales de fecha y hora:
 * <ul>
 * <li>{@code date} — se serializa y deserializa en formato
 * {@code YYYYMMDD}.</li>
 * <li>{@code hour} — se serializa y deserializa en formato {@code HHMMSS}.</li>
 * </ul>
 *
 * <p>
 * La forma recomendada de obtener una instancia es a través del factory method
 * {@link #fromRequestHeader(CoreRequestHeader)}, que construye el header de
 * respuesta descartando automáticamente los campos restringidos.
 *
 * @param date       fecha en que se realizó la operación en formato
 *                   {@code YYYYMMDD}.
 *                   Ejemplo: {@code "20261201"}.
 * @param instanceId número de instancia del canal que generó la transacción.
 *                   Numérico de hasta 2 dígitos. Ejemplo: {@code 21}.
 * @param system     identificador del canal o aplicación que realizó la
 *                   operación.
 *                   Máximo 10 caracteres. Ejemplo: {@code "BM"}.
 * @param hour       hora en que se realizó la operación en formato
 *                   {@code HHMMSS}.
 *                   Ejemplo: {@code "083000"}.
 * @param batch      código de cajero, relleno de ceros a la izquierda.
 *                   Máximo 4 caracteres. Ejemplo: {@code "3700"}.
 * @param branch     código de agencia IBS, relleno de ceros a la izquierda.
 *                   Numérico de hasta 3 dígitos. Ejemplo: {@code 137}.
 * @param channelId  identificador del canal, relleno de ceros a la izquierda si
 *                   es numérico. Máximo 9 caracteres. Ejemplo:
 *                   {@code "000003711"}.
 *
 * @author Jose Luis Pereira
 * @see CoreRequestHeader
 * @see #fromRequestHeader(CoreRequestHeader)
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record CoreResponseHeader(

        @ValidDate Integer date,

        @Min(0) @Max(value = 99, message = "instanceId debe ser numérico de hasta 2 dígitos") Integer instanceId,

        @Size(max = 10) String system,

        @ValidHour Integer hour,

        @Size(max = 4) String batch,

        @Min(0) @Max(value = 999, message = "branch debe ser numérico de 3 dígitos") Integer branch,

        @Size(max = 9) String channelId) {

    /**
     * Construye un {@link CoreResponseHeader} a partir de un
     * {@link CoreRequestHeader}, descartando automáticamente los campos
     * {@code supervisor}, {@code user} y {@code locationUser} que el estándar
     * no permite incluir en la respuesta.
     *
     * @param requestHeader header del request del que se deriva la respuesta.
     *                      Si es {@code null}, retorna {@code null}.
     * @return nuevo {@link CoreResponseHeader} con los campos permitidos del
     *         request, o {@code null} si {@code requestHeader} es {@code null}.
     * @see CoreRequestHeader
     */
    public static CoreResponseHeader fromRequestHeader(CoreRequestHeader requestHeader) {
        if (requestHeader == null)
            return null;
        return new CoreResponseHeader(
                requestHeader.date(),
                requestHeader.instanceId(),
                requestHeader.system(),
                requestHeader.hour(),
                requestHeader.batch(),
                requestHeader.branch(),
                requestHeader.channelId());
    }
}
