package sv.ba.api.messagingcore.exception;

import java.util.List;

import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorPrefix;

/**
 * Excepción que representa un error propio del API de capa media.
 * Utiliza el prefijo {@link ErrorPrefix#SM}.
 *
 * <p>
 * Se lanza cuando la falla ocurre dentro del API implementada en los
 * componentes de integración empresarial o transaccional. Ejemplos de uso:
 * <ul>
 * <li>Error en la transformación de datos dentro del API de capa media.</li>
 * <li>Falla en la orquestación de servicios internos.</li>
 * <li>Error propio del middleware que no corresponde a un proveedor
 * externo.</li>
 * </ul>
 *
 * <p>
 * Uso directo:
 * 
 * <pre>
 * throw new SystemMiddlewareException(500, "19005", "API",
 *         "Error en la transformación de datos");
 * </pre>
 *
 * <p>
 * Uso recomendado — crear una excepción específica en el microservicio:
 * 
 * <pre>
 * public class TransformacionException extends SystemMiddlewareException {
 *     public TransformacionException() {
 *         super(500, "19005", "API", "Error en la transformación de datos");
 *     }
 * }
 * </pre>
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see ApiException
 * @see ErrorPrefix#SM
 * @see SystemApiException
 * @see SystemInfrastructureException
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
public final class SystemMiddlewareException extends ApiException {

    /**
     * Constructor principal.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19005"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "API"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     */
    public SystemMiddlewareException(int httpStatus, String errorCode,
            String title, String detail) {
        super(httpStatus, errorCode, title, detail);
    }

    /**
     * Constructor con causa. Útil para preservar la excepción original.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19005"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "API"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     * @param cause      excepción original que provocó este error.
     */
    public SystemMiddlewareException(int httpStatus, String errorCode,
            String title, String detail, Throwable cause) {
        super(httpStatus, errorCode, title, detail, cause);
    }

    /**
     * Constructor con lista de errores. Para casos donde la operación
     * produce múltiples errores simultáneos.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errors     lista de {@link ApiError} ya construidos con sus
     *                   códigos completos. No puede ser {@code null} ni vacía.
     */
    public SystemMiddlewareException(int httpStatus, List<ApiError> errors) {
        super(httpStatus, errors);
    }

    /**
     * {@inheritDoc}
     *
     * @return {@link ErrorPrefix#SM}
     */
    @Override
    public ErrorPrefix prefix() {
        return ErrorPrefix.SM;
    }
}
