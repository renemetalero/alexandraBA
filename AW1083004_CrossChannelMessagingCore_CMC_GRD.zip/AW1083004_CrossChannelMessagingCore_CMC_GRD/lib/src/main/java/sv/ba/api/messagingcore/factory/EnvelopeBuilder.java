package sv.ba.api.messagingcore.factory;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.function.Supplier;

import sv.ba.api.messagingcore.envelope.Metadata;
import sv.ba.api.messagingcore.web.ApiRequestContext;

/**
 * Clase base abstracta para todos los builders de envelope de la librería.
 *
 * <p>
 * Es {@code sealed} — solo {@link ResponseEnvelopeBuilder} y
 * {@link ErrorEnvelopeBuilder} pueden extenderla, garantizando que toda
 * construcción de envelopes pase por esta jerarquía controlada.
 *
 * <p>
 * Centraliza la responsabilidad de generación de {@link Metadata},
 * encapsulando dos detalles de implementación que el estándar define como
 * automáticos y no configurables:
 * <ul>
 * <li>{@code _messageId} — siempre un UUID nuevo generado en el momento
 * de construir la respuesta.</li>
 * <li>{@code _datetime} — siempre el timestamp actual del sistema en el
 * momento de construir la respuesta.</li>
 * </ul>
 *
 * <p>
 * La propagación del {@code _correlationId} sigue la regla del estándar:
 * <ul>
 * <li>Si el request incluye {@code _correlationId}, el mismo valor se
 * propaga a la respuesta.</li>
 * <li>Si el request no incluye {@code _correlationId}, la respuesta
 * tampoco lo lleva.</li>
 * </ul>
 *
 * <p>
 * El método {@link #resolveResponseMetadata()} determina automáticamente
 * cuál de los métodos de creación de metadata usar según la disponibilidad
 * del contexto del request en el {@link ApiRequestContext}.
 *
 * @param <T> tipo del envelope que produce el builder.
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see ResponseEnvelopeBuilder
 * @see ErrorEnvelopeBuilder
 * @see MessageFactory
 * @see ApiRequestContext
 * @see Metadata
 */
public abstract sealed class EnvelopeBuilder<T> permits ResponseEnvelopeBuilder, ErrorEnvelopeBuilder {

    private final Clock clock = Clock.systemDefaultZone();
    private final Supplier<String> messageIdSupplier = () -> UUID.randomUUID().toString();

    protected final ApiRequestContext requestContext;

    /**
     * Constructor que recibe el contexto del request actual.
     *
     * @param requestContext contexto de scope request que contiene el
     *                       {@link Metadata} y el header extraídos del
     *                       body del request por el
     *                       {@link sv.ba.api.messagingcore.web.RequestContextAdvice}.
     */
    protected EnvelopeBuilder(ApiRequestContext requestContext) {
        this.requestContext = requestContext;
    }

    /**
     * Crea un {@link Metadata} nuevo sin correlación. Se usa cuando no hay
     * contexto de request disponible — por ejemplo, cuando el error ocurre
     * antes de que el body del request sea procesado.
     *
     * @return nuevo {@link Metadata} con {@code _messageId} generado,
     *         {@code _correlationId} {@code null} y {@code _datetime} actual.
     */
    protected Metadata newMetadata() {
        return new Metadata(messageIdSupplier.get(), null, LocalDateTime.now(clock));
    }

    /**
     * Crea un {@link Metadata} nuevo con correlación explícita. Si
     * {@code correlationId} es {@code null} o vacío, produce metadata
     * sin correlación — conforme al estándar que define este campo como
     * opcional.
     *
     * @param correlationId valor del {@code _correlationId} a incluir.
     *                      Si es {@code null} o vacío, no se incluye.
     * @return nuevo {@link Metadata} con {@code _messageId} generado,
     *         {@code _correlationId} resuelto y {@code _datetime} actual.
     */
    protected Metadata newMetadata(String correlationId) {
        String resolved = (correlationId != null && !correlationId.isBlank())
                ? correlationId
                : null;
        return new Metadata(messageIdSupplier.get(), resolved, LocalDateTime.now(clock));
    }

    /**
     * Crea un {@link Metadata} de respuesta derivado del request. Propaga
     * el {@code _correlationId} si viene en el request — si no viene,
     * la respuesta tampoco lo lleva, conforme al estándar.
     *
     * @param requestMeta metadata del request del que se deriva la respuesta.
     * @return nuevo {@link Metadata} con {@code _messageId} generado,
     *         {@code _correlationId} propagado del request y
     *         {@code _datetime} actual.
     */
    protected Metadata responseMetadataFrom(Metadata requestMeta) {
        return new Metadata(
                messageIdSupplier.get(),
                requestMeta.correlationId(),
                LocalDateTime.now(clock));
    }

    /**
     * Resuelve la metadata de respuesta según la disponibilidad del contexto
     * del request en el {@link ApiRequestContext}:
     * <ul>
     * <li>Si hay metadata del request disponible, propaga su
     * {@code _correlationId} mediante
     * {@link #responseMetadataFrom(Metadata)}.</li>
     * <li>Si no hay contexto disponible, genera metadata fresca sin
     * correlación mediante {@link #newMetadata()}.</li>
     * </ul>
     *
     * @return {@link Metadata} de respuesta resuelta según el contexto.
     */
    protected Metadata resolveResponseMetadata() {
        return requestContext.hasMetadata()
                ? responseMetadataFrom(requestContext.getTraceability())
                : newMetadata();
    }

    /**
     * Construye el envelope. Implementado por cada subclase con su propia
     * lógica de construcción.
     *
     * @return envelope construido listo para retornar al consumidor.
     */
    public abstract T build();
}
