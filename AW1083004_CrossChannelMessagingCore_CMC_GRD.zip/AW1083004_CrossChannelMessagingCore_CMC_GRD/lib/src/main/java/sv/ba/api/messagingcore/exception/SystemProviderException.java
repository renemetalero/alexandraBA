package sv.ba.api.messagingcore.exception;

import java.util.List;

import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorPrefix;

/**
 * Excepción que representa un error de sistema en el proveedor o backend
 * con el que interactúa el API. Utiliza el prefijo {@link ErrorPrefix#SP}.
 *
 * <p>Se lanza cuando la falla se origina en el sistema proveedor y es de
 * naturaleza técnica — no de negocio. Ejemplos de uso:
 * <ul>
 *   <li>Timeout al conectar con el proveedor.</li>
 *   <li>Respuesta malformada o inesperada del proveedor.</li>
 *   <li>Servicio del proveedor no disponible.</li>
 * </ul>
 *
 * <p>Uso directo:
 * <pre>
 * throw new SystemProviderException(503, "19002", "IBS",
 *         "El servicio no está disponible");
 * </pre>
 *
 * <p>Uso recomendado — crear una excepción específica en el microservicio:
 * <pre>
 * public class ServicioNoDisponibleException extends SystemProviderException {
 *     public ServicioNoDisponibleException() {
 *         super(503, "19002", "IBS", "El servicio no está disponible");
 *     }
 * }
 * </pre>
 *
 * @author Jose Luis Pereira
 * @since  0.1.0
 * @see    ApiException
 * @see    ErrorPrefix#SP
 * @see    BusinessProviderException
 * @see    SystemApiException
 * @see    sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
public final class SystemProviderException extends ApiException {

    /**
     * Constructor principal.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19002"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "IBS"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     */
    public SystemProviderException(int httpStatus, String errorCode,
                                   String title, String detail) {
        super(httpStatus, errorCode, title, detail);
    }

    /**
     * Constructor con causa. Útil para preservar la excepción original.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errorCode  código EVC de exactamente 5 dígitos del catálogo del
     *                   microservicio. Ejemplo: {@code "19002"}.
     * @param title      sistema que reporta el error. Ejemplo: {@code "IBS"}.
     * @param detail     descripción funcional del error en lenguaje natural.
     * @param cause      excepción original que provocó este error.
     */
    public SystemProviderException(int httpStatus, String errorCode,
                                   String title, String detail, Throwable cause) {
        super(httpStatus, errorCode, title, detail, cause);
    }

    /**
     * Constructor con lista de errores. Para casos donde la operación
     * produce múltiples errores simultáneos.
     *
     * @param httpStatus código HTTP con el que se responderá.
     * @param errors     lista de {@link ApiError} ya construidos con sus
     *                   códigos completos. No puede ser {@code null} ni vacía.
     */
    public SystemProviderException(int httpStatus, List<ApiError> errors) {
        super(httpStatus, errors);
    }

    /**
     * {@inheritDoc}
     *
     * @return {@link ErrorPrefix#SP}
     */
    @Override
    public ErrorPrefix prefix() {
        return ErrorPrefix.SP;
    }
}
