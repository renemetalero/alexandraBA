package sv.ba.api.messagingcore.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import sv.ba.api.messagingcore.factory.MessageFactory;
import sv.ba.api.messagingcore.web.ApiExceptionHandler;
import sv.ba.api.messagingcore.web.ApiRequestContext;
import sv.ba.api.messagingcore.web.RequestContextAdvice;
import sv.ba.api.messagingcore.web.SecurityHeadersFilter;
import sv.ba.api.messagingcore.web.TraceabilityHeadersInterceptor;

/**
 * Configuración base de la librería {@code messaging-core}.
 *
 * <p>
 * Registra automáticamente todos los beans necesarios para que la librería
 * funcione sin configuración adicional por parte del desarrollador. Cada bean
 * está anotado con {@link ConditionalOnMissingBean}, lo que permite al
 * microservicio sobreescribir cualquier comportamiento declarando su propio
 * bean
 * del mismo tipo.
 *
 * <p>
 * Para extender la configuración sin perder los beans base, el microservicio
 * puede heredar de esta clase:
 *
 * <pre>
 * &#64;Configuration
 * public class MiConfiguracion extends MessagingCoreConfiguration {
 *
 *     public MiConfiguracion(ApiRequestContext requestContext) {
 *         super(requestContext);
 *     }
 *
 *     &#64;Bean
 *     public MiServicio miServicio() {
 *         return new MiServicio();
 *     }
 * }
 * </pre>
 *
 * @author Jose Luis Pereira
 * @see MessageFactory
 * @see ApiExceptionHandler
 * @see RequestContextAdvice
 * @see SecurityHeadersFilter
 */
@Configuration
public class MessagingCoreConfiguration implements WebMvcConfigurer {

    private final ApiRequestContext requestContext;

    /**
     * Constructor que recibe el contexto del request actual.
     *
     * @param requestContext contexto de scope request que almacena el
     *                       {@link sv.ba.api.messagingcore.envelope.Metadata}
     *                       y el header de la petición extraídos del body
     *                       por {@link RequestContextAdvice}.
     */
    public MessagingCoreConfiguration(ApiRequestContext requestContext) {
        this.requestContext = requestContext;
    }

    /**
     * Registra la {@link MessageFactory} como bean de Spring.
     *
     * <p>
     * Si el microservicio declara su propio bean de tipo
     * {@link MessageFactory}, este no se registra.
     *
     * @param ninguno — usa el {@link ApiRequestContext} inyectado en el
     *                constructor.
     * @return instancia de {@link MessageFactory} configurada con el contexto
     *         del request actual.
     * @see MessageFactory
     */
    @Bean
    @ConditionalOnMissingBean(MessageFactory.class)
    public MessageFactory messageFactory() {
        return new MessageFactory(requestContext);
    }

    /**
     * Registra el {@link ApiExceptionHandler} como bean de Spring.
     *
     * <p>
     * Maneja automáticamente todas las excepciones de la librería y de
     * Spring MVC, transformándolas en
     * {@link sv.ba.api.messagingcore.envelope.ErrorEnvelope}.
     * Si el microservicio declara su propia implementación extendiendo
     * {@link ApiExceptionHandler}, este bean no se registra.
     *
     * @param factory instancia de {@link MessageFactory} para construir
     *                los envelopes de error.
     * @return instancia de {@link ApiExceptionHandler}.
     * @see ApiExceptionHandler
     */
    @Bean
    @ConditionalOnMissingBean(ApiExceptionHandler.class)
    public ApiExceptionHandler apiExceptionHandler(MessageFactory factory) {
        return new ApiExceptionHandler(factory);
    }

    /**
     * Registra el {@link RequestContextAdvice} como bean de Spring.
     *
     * <p>
     * Intercepta el body del request después de que Spring lo deserializa,
     * extrayendo el {@code _correlationId} y el header de la petición para
     * almacenarlos en el {@link ApiRequestContext}. Si el microservicio declara
     * su propia implementación, este bean no se registra.
     *
     * @return instancia de {@link RequestContextAdvice} configurada con el
     *         contexto del request actual.
     * @see RequestContextAdvice
     * @see ApiRequestContext
     */
    @Bean
    @ConditionalOnMissingBean(RequestContextAdvice.class)
    public RequestContextAdvice requestContextAdvice() {
        return new RequestContextAdvice(requestContext);
    }

    /**
     * Registra el {@link SecurityHeadersFilter} como bean de Spring.
     *
     * <p>
     * Aplica automáticamente los headers de seguridad requeridos por el
     * estándar en todas las respuestas HTTP. Si el microservicio declara su
     * propia implementación, este bean no se registra.
     *
     * @return instancia de {@link SecurityHeadersFilter}.
     * @see SecurityHeadersFilter
     */
    @Bean
    @ConditionalOnMissingBean(SecurityHeadersFilter.class)
    public SecurityHeadersFilter securityHeadersFilter() {
        return new SecurityHeadersFilter();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new TraceabilityHeadersInterceptor(requestContext));
    }
}
