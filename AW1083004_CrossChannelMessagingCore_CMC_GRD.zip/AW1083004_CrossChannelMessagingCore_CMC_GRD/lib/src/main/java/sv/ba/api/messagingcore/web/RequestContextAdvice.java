package sv.ba.api.messagingcore.web;

import java.lang.reflect.Type;

import org.springframework.core.MethodParameter;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdviceAdapter;

import sv.ba.api.messagingcore.envelope.RequestEnvelope;

/**
 * Intercepta el body del request justo después de que Spring lo deserializa,
 * extrayendo el {@link sv.ba.api.messagingcore.envelope.Metadata} y el header
 * del {@link RequestEnvelope} para almacenarlos en el
 * {@link ApiRequestContext}.
 *
 * <p>
 * Al ejecutarse después de la deserialización, trabaja directamente con el
 * objeto Java ya construido — sin necesidad de leer ni parsear el stream del
 * request manualmente. Esto garantiza que el {@code _correlationId} y el header
 * estén disponibles durante la totalidad del ciclo de vida del request para su
 * uso en
 * {@link sv.ba.api.messagingcore.factory.EnvelopeBuilder}.
 *
 * <p>
 * Solo se activa para parámetros de tipo {@link RequestEnvelope} — no
 * interfiere con otros tipos de {@code @RequestBody}. Si el body llega vacío,
 * lo retorna sin modificar y el {@link ApiRequestContext} queda sin datos,
 * por lo que la respuesta no incluirá {@code _correlationId} ni header.
 *
 * <p>
 * Se registra automáticamente como bean de Spring a través de
 * {@link sv.ba.api.messagingcore.config.MessagingCoreConfiguration}. Si el
 * microservicio declara su propia implementación, este advice no se registra
 * gracias al mecanismo {@code @ConditionalOnMissingBean}.
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see ApiRequestContext
 * @see RequestEnvelope
 * @see sv.ba.api.messagingcore.factory.EnvelopeBuilder
 * @see sv.ba.api.messagingcore.config.MessagingCoreConfiguration
 */
@RestControllerAdvice
public class RequestContextAdvice extends RequestBodyAdviceAdapter {

    private final ApiRequestContext requestContext;

    /**
     * Constructor que recibe el contexto del request actual.
     *
     * @param requestContext contexto de scope request donde se almacenan
     *                       el {@link sv.ba.api.messagingcore.envelope.Metadata}
     *                       y el header extraídos del {@link RequestEnvelope}.
     */
    public RequestContextAdvice(ApiRequestContext requestContext) {
        this.requestContext = requestContext;
    }

    /**
     * Indica si este advice aplica para el parámetro del método dado.
     * Solo se activa cuando el tipo del parámetro es {@link RequestEnvelope}
     * o una subclase de este.
     *
     * @param methodParameter parámetro del método del controller.
     * @param targetType      tipo genérico objetivo de la deserialización.
     * @param converterType   tipo del converter HTTP utilizado.
     * @return {@code true} si el tipo del parámetro es {@link RequestEnvelope},
     *         {@code false} en caso contrario.
     */
    @Override
    public boolean supports(MethodParameter methodParameter,
            Type targetType,
            Class<? extends HttpMessageConverter<?>> converterType) {
        return RequestEnvelope.class.isAssignableFrom(
                methodParameter.getParameterType());
    }

    /**
     * Se ejecuta después de que Spring deserializa el body del request.
     * Extrae el {@link sv.ba.api.messagingcore.envelope.Metadata} y el header
     * del {@link RequestEnvelope} y los almacena en el {@link ApiRequestContext}
     * para que estén disponibles durante el resto del ciclo de vida del request.
     *
     * <p>
     * Si el body no es una instancia de {@link RequestEnvelope} o si
     * {@code data} es {@code null}, el contexto queda sin datos y la respuesta
     * no incluirá {@code _correlationId} ni header.
     *
     * @param body          objeto deserializado del body del request.
     * @param inputMessage  mensaje HTTP de entrada.
     * @param parameter     parámetro del método del controller.
     * @param targetType    tipo genérico objetivo de la deserialización.
     * @param converterType tipo del converter HTTP utilizado.
     * @return el mismo {@code body} recibido, sin modificaciones.
     * @see ApiRequestContext#setMetadata(sv.ba.api.messagingcore.envelope.Metadata)
     * @see ApiRequestContext#setHeader(sv.ba.api.messagingcore.envelope.header.CoreRequestHeader)
     */
    @Override
    public Object afterBodyRead(Object body,
            HttpInputMessage inputMessage,
            MethodParameter parameter,
            Type targetType,
            Class<? extends HttpMessageConverter<?>> converterType) {
        if (body instanceof RequestEnvelope<?> envelope && envelope.data() != null) {
            requestContext.setHeader(envelope.data().header());
        }
        return body;

    }

    /**
     * Se ejecuta cuando el body del request llega vacío. Retorna el body
     * sin modificar — el {@link ApiRequestContext} queda sin datos.
     *
     * @param body          objeto recibido, típicamente {@code null}.
     * @param inputMessage  mensaje HTTP de entrada.
     * @param parameter     parámetro del método del controller.
     * @param targetType    tipo genérico objetivo de la deserialización.
     * @param converterType tipo del converter HTTP utilizado.
     * @return el mismo {@code body} recibido sin modificaciones.
     */
    @Override
    public Object handleEmptyBody(Object body,
            HttpInputMessage inputMessage,
            MethodParameter parameter,
            Type targetType,
            Class<? extends HttpMessageConverter<?>> converterType) {
        return body;
    }

}
