package sv.ba.api.messagingcore.envelope.validator.time;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = HourIntegerValidator.class)
@Documented
public @interface ValidHour {

    String message() default "Hora inválida (formato HHmmss)";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
