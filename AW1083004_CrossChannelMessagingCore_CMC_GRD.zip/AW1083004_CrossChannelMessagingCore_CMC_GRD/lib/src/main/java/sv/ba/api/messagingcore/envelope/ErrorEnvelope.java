package sv.ba.api.messagingcore.envelope;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import sv.ba.api.messagingcore.error.ApiError;

/**
 * Envelope raíz de una respuesta de error del API.
 *
 * <p>
 * Encapsula la estructura estándar de mensajería para todas las respuestas
 * que indican una falla, independientemente del código HTTP retornado. Los
 * headers de la respuesta de error son los mismos que en una respuesta exitosa.
 *
 * <p>
 * Estructura en JSON:
 * 
 * <pre>
 * {
 *   "metadata": {
 *     "_messageId": "...",
 *     "_correlationId": "...",
 *     "_datetime": "..."
 *   },
 *   "status": "409",
 *   "message": "CONFLICT",
 *   "errors": [
 *     {
 *       "code": "BP40919001",
 *       "title": "IBS",
 *       "detail": "La cuenta está bloqueada"
 *     }
 *   ]
 * }
 * </pre>
 *
 * <p>
 * El campo {@code errors} siempre es un array conforme al estándar JSON:API,
 * incluso cuando se reporta un único error. El campo {@code status} contiene el
 * código HTTP como {@code String} y {@code message} el título correspondiente
 * a ese código en mayúsculas.
 *
 * <p>
 * Este envelope se construye automáticamente por el
 * {@link sv.ba.api.messagingcore.web.ApiExceptionHandler} cuando se lanza
 * cualquier excepción de la jerarquía
 * {@link sv.ba.api.messagingcore.exception.ApiException} o una excepción
 * propia de Spring MVC. No es necesario construirlo manualmente.
 *
 * @param metadata datos de trazabilidad del mensaje. Propaga el
 *                 {@code _correlationId} del request si estaba disponible.
 *                 Requerido.
 * @param status   código HTTP de la respuesta como {@code String}.
 *                 Ejemplo: {@code "409"}.
 * @param message  título correspondiente al código HTTP en mayúsculas.
 *                 Ejemplo: {@code "CONFLICT"}.
 * @param errors   lista de errores identificados en la solicitud. Siempre
 *                 es un array con al menos un elemento. Requerido.
 *
 * @author Jose Luis Pereira
 * @see ApiError
 * @see Metadata
 * @see ResponseEnvelope
 * @see sv.ba.api.messagingcore.exception.ApiException
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErrorEnvelope(
        @NotNull @Valid Metadata metadata,
        @NotNull String status,
        @NotNull String message,
        @NotEmpty @Valid List<ApiError> errors) {
}
