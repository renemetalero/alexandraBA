package sv.ba.api.messagingcore.web;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import sv.ba.api.messagingcore.envelope.ErrorEnvelope;
import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorCodeBuilder;
import sv.ba.api.messagingcore.error.ErrorPrefix;
import sv.ba.api.messagingcore.exception.ApiException;
import sv.ba.api.messagingcore.exception.SystemApiException;
import sv.ba.api.messagingcore.factory.MessageFactory;

/**
 * Handler global de excepciones del estándar de mensajería.
 *
 * <p>
 * Se registra automáticamente como bean de Spring a través de
 * {@link sv.ba.api.messagingcore.config.MessagingCoreConfiguration} y
 * captura todas las excepciones lanzadas durante el procesamiento de una
 * solicitud, transformándolas en un {@link ErrorEnvelope} conforme al estándar.
 *
 * <p>
 * Además de las excepciones de la librería, maneja automáticamente los
 * errores más comunes generados por Spring MVC:
 * <ul>
 * <li>{@link ApiException} y subclases → usa su {@code httpStatus},
 * prefijo y errores internos.</li>
 * <li>{@link MethodArgumentNotValidException} → {@code 400} con detalle
 * por campo fallido.</li>
 * <li>{@link ConstraintViolationException} → {@code 400}.</li>
 * <li>{@link HttpMessageNotReadableException} → {@code 400} cuando el
 * body es inválido o está malformado.</li>
 * <li>{@link HttpRequestMethodNotSupportedException} → {@code 405}.</li>
 * <li>{@link HttpMediaTypeNotSupportedException} → {@code 415}.</li>
 * <li>{@link NoHandlerFoundException} → {@code 404}.</li>
 * <li>{@link Exception} catch-all → {@code 500}.</li>
 * </ul>
 *
 * <p>
 * Para personalizar el manejo de excepciones, el microservicio puede
 * extender esta clase y agregar sus propios handlers o sobreescribir los
 * existentes. Al declarar la subclase con {@code @RestControllerAdvice},
 * Spring la usará en lugar de la de la librería gracias al mecanismo
 * {@code @ConditionalOnMissingBean} de la configuración:
 * 
 * <pre>
 * &#64;RestControllerAdvice
 * public class MiExceptionHandler extends ApiExceptionHandler {
 *
 *     public MiExceptionHandler(MessageFactory factory) {
 *         super(factory);
 *     }
 *
 *     &#64;Override
 *     protected void beforeHandle(ApiException ex) {
 *         // lógica antes de procesar la excepción
 *     }
 *
 *     &#64;ExceptionHandler(MiExcepcionEspecifica.class)
 *     public ResponseEntity&lt;ErrorEnvelope&gt; handleMiExcepcion(
 *             MiExcepcionEspecifica ex, HttpServletResponse response) {
 *         SecurityHeaders.apply(response);
 *         return ResponseEntity.status(ex.httpStatus())
 *                 .body(messageFactory.errorBuilder(ex).build());
 *     }
 * }
 * </pre>
 *
 * @author Jose Luis Pereira
 * @see ApiException
 * @see MessageFactory
 * @see ErrorEnvelope
 * @see SecurityHeaders
 * @see sv.ba.api.messagingcore.config.MessagingCoreConfiguration
 */
@RestControllerAdvice
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    protected final MessageFactory messageFactory;

    /**
     * Constructor que recibe la factory para construir los envelopes de error.
     *
     * @param messageFactory factory para construir {@link ErrorEnvelope}.
     *                       No puede ser {@code null}.
     * @throws NullPointerException si {@code messageFactory} es {@code null}.
     */
    public ApiExceptionHandler(MessageFactory messageFactory) {
        this.messageFactory = Objects.requireNonNull(messageFactory);
    }

    /**
     * Maneja todas las excepciones de la jerarquía {@link ApiException}.
     * Aplica los headers de seguridad, ejecuta los hooks de extensión y
     * construye el {@link ErrorEnvelope} con el {@code httpStatus}, prefijo
     * y errores de la excepción.
     *
     * @param ex              excepción capturada de la jerarquía
     *                        {@link ApiException}.
     * @param servletResponse respuesta HTTP sobre la que se aplican los
     *                        headers de seguridad.
     * @return {@link ResponseEntity} con el {@link ErrorEnvelope} y el
     *         código HTTP de la excepción.
     * @see SecurityHeaders#apply(HttpServletResponse)
     * @see #beforeHandle(ApiException)
     * @see #afterHandle(ApiException, ErrorEnvelope)
     */
    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ErrorEnvelope> handleApiException(ApiException ex, HttpServletResponse servletResponse) {
        SecurityHeaders.apply(servletResponse);
        beforeHandle(ex);
        ErrorEnvelope envelope = messageFactory.errorBuilder(ex).build();
        ResponseEntity<ErrorEnvelope> response = ResponseEntity.status(ex.httpStatus()).body(envelope);
        afterHandle(ex, envelope);
        return response;
    }

    /**
     * Hook — se ejecuta antes de procesar la excepción. Override para
     * agregar logging, métricas o auditoría previas al procesamiento.
     *
     * @param ex excepción que está siendo procesada.
     */
    protected void beforeHandle(ApiException ex) {
        // Metodo vacio valido para implementacion en hijos
    }

    /**
     * Hook — se ejecuta después de construir la respuesta de error. Override
     * para agregar lógica posterior como notificaciones o auditoría.
     *
     * @param ex       excepción que fue procesada.
     * @param envelope envelope de error construido para la respuesta.
     */
    protected void afterHandle(ApiException ex, ErrorEnvelope envelope) {
        // Metodo vacio valido para implementacion en hijos
    }

    /**
     * Maneja errores de validación de {@code @Valid} en el body del request.
     * Genera un error por cada campo que falle la validación. Si no hay
     * errores de campo, genera un error genérico de solicitud inválida.
     *
     * @param ex excepción de validación capturada por Spring MVC.
     * @return {@link ResponseEntity} con código {@code 400} y detalle de
     *         los campos fallidos.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorEnvelope> handleBodyValidation(
            MethodArgumentNotValidException ex) {
        List<ApiError> errors = ex.getBindingResult().getFieldErrors().stream()
                .map(this::fieldErrorToApiError)
                .toList();
        if (errors.isEmpty()) {
            errors = List.of(buildSaError(HttpStatus.BAD_REQUEST, "Solicitud inválida"));
        }
        return buildErrorResponse(HttpStatus.BAD_REQUEST, errors);
    }

    /**
     * Maneja violaciones de restricciones Jakarta Validation a nivel de
     * método o parámetro. Si no hay violaciones, genera un error genérico
     * de solicitud inválida.
     *
     * @param ex excepción de violación de restricciones capturada.
     * @return {@link ResponseEntity} con código {@code 400}.
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorEnvelope> handleConstraintViolation(
            ConstraintViolationException ex) {
        List<ApiError> errors = ex.getConstraintViolations().stream()
                .map(this::violationToApiError)
                .toList();
        if (errors.isEmpty()) {
            errors = List.of(buildSaError(HttpStatus.BAD_REQUEST, "Solicitud inválida"));
        }
        return buildErrorResponse(HttpStatus.BAD_REQUEST, errors);
    }

    /**
     * Maneja errores de lectura del body del request — JSON malformado,
     * tipos de datos incorrectos o body ausente.
     *
     * @param ex excepción capturada por Spring MVC.
     * @return {@link ResponseEntity} con código {@code 400}.
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorEnvelope> handleUnreadable(
            HttpMessageNotReadableException ex) {
        return buildErrorResponse(HttpStatus.BAD_REQUEST, List.of(
                buildSaError(HttpStatus.BAD_REQUEST,
                        "El cuerpo de la solicitud es inválido o está malformado")));
    }

    /**
     * Maneja peticiones con método HTTP no soportado por el endpoint.
     *
     * @param ex excepción capturada por Spring MVC.
     * @return {@link ResponseEntity} con código {@code 405}.
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErrorEnvelope> handleMethodNotAllowed(
            HttpRequestMethodNotSupportedException ex) {
        return buildErrorResponse(HttpStatus.METHOD_NOT_ALLOWED, List.of(
                buildSaError(HttpStatus.METHOD_NOT_ALLOWED,
                        "Método HTTP no permitido para este recurso")));
    }

    /**
     * Maneja peticiones con {@code Content-Type} no soportado por el endpoint.
     *
     * @param ex excepción capturada por Spring MVC.
     * @return {@link ResponseEntity} con código {@code 415}.
     */
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ErrorEnvelope> handleUnsupportedMedia(
            HttpMediaTypeNotSupportedException ex) {
        return buildErrorResponse(HttpStatus.UNSUPPORTED_MEDIA_TYPE, List.of(
                buildSaError(HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                        "Content-Type no soportado")));
    }

    /**
     * Maneja peticiones hacia rutas o endpoints que no existen.
     *
     * @param ex excepción capturada por Spring MVC.
     * @return {@link ResponseEntity} con código {@code 404}.
     */
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ErrorEnvelope> handleNotFound(NoHandlerFoundException ex) {
        return buildErrorResponse(HttpStatus.NOT_FOUND, List.of(
                buildSaError(HttpStatus.NOT_FOUND, "Recurso no encontrado")));
    }

    /**
     * Catch-all para cualquier excepción no manejada por los handlers
     * anteriores. Registra el error en el log y retorna un error genérico
     * de servidor para no exponer detalles internos al consumidor.
     *
     * @param ex excepción inesperada capturada.
     * @return {@link ResponseEntity} con código {@code 500}.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorEnvelope> handleUnexpected(Exception ex) {
        log.error("Excepción no controlada", ex);
        log.error("Excepcion: {}", ex.getMessage(), ex);
        return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, List.of(
                buildSaError(HttpStatus.INTERNAL_SERVER_ERROR,
                        "Error interno del servidor")));
    }

    /**
     * Construye el {@link ResponseEntity} con el {@link ErrorEnvelope}
     * correspondiente para errores generados por Spring MVC. Usa
     * {@link SystemApiException} internamente para aprovechar la lógica
     * de construcción del builder.
     *
     * @param httpStatus código HTTP de la respuesta.
     * @param errors     lista de errores a incluir en el envelope.
     * @return {@link ResponseEntity} con el {@link ErrorEnvelope} construido.
     */
    protected ResponseEntity<ErrorEnvelope> buildErrorResponse(HttpStatus httpStatus,
            List<ApiError> errors) {
        ErrorEnvelope envelope = messageFactory.errorBuilder(
                new SystemApiException(httpStatus.value(), errors))
                .build();
        return ResponseEntity.status(httpStatus).body(envelope);
    }

    /**
     * Construye un {@link ApiError} con prefijo {@link ErrorPrefix#SA} para
     * errores propios del API. Usa el código EVC {@code "00000"} como valor
     * genérico para los errores generados automáticamente por la librería.
     *
     * @param httpStatus código HTTP del error.
     * @param detail     descripción funcional del error.
     * @return {@link ApiError} con prefijo SA y código EVC genérico.
     */
    protected ApiError buildSaError(HttpStatus httpStatus, String detail) {
        String code = ErrorCodeBuilder.build(
                ErrorPrefix.SA, httpStatus.value(), "00000");
        return new ApiError(code, "API", detail);
    }

    /**
     * Convierte un {@link FieldError} de validación en un {@link ApiError}.
     * El detalle incluye el nombre del campo y el mensaje de validación.
     *
     * @param fe error de campo capturado por la validación de Spring.
     * @return {@link ApiError} con el detalle del campo fallido.
     */
    protected ApiError fieldErrorToApiError(FieldError fe) {
        String detail = fe.getField() + ": "
                + (fe.getDefaultMessage() != null
                        ? fe.getDefaultMessage()
                        : "valor inválido");
        return buildSaError(HttpStatus.BAD_REQUEST, detail);
    }

    /**
     * Convierte una {@link ConstraintViolation} en un {@link ApiError}.
     * El detalle incluye la ruta de la propiedad y el mensaje de la
     * restricción violada.
     *
     * @param v violación de restricción capturada.
     * @return {@link ApiError} con el detalle de la restricción violada.
     */
    protected ApiError violationToApiError(ConstraintViolation<?> v) {
        String path = v.getPropertyPath() != null
                ? v.getPropertyPath().toString()
                : "";
        String detail = (path.isBlank() ? "" : path + ": ") + v.getMessage();
        return buildSaError(HttpStatus.BAD_REQUEST, detail);
    }

}
