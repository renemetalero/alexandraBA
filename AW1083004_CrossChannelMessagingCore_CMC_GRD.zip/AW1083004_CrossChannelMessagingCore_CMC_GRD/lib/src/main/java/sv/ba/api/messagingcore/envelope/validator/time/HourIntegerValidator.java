package sv.ba.api.messagingcore.envelope.validator.time;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

/**
 * Valida que un {@link Integer} represente una hora real en formato
 * {@code HHmmss}.
 *
 * <p>
 * La validación acepta {@code null} y aplica parseo estricto para rechazar
 * horas inexistentes, minutos fuera de rango o segundos inválidos.
 */
public class HourIntegerValidator implements ConstraintValidator<ValidHour, Integer> {

    /**
     * Determina si el valor cumple con el formato {@code HHmmss} y existe
     * como hora válida.
     *
     * @param value   hora a validar.
     * @param context contexto de validación provisto por Jakarta Validation.
     * @return {@code true} si el valor es {@code null} o si representa una
     *         hora válida; de lo contrario, {@code false}.
     */
    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
        if (value == null) return true;

        String timeStr = String.format("%06d", value);

        try {
            DateTimeFormatter formatter = DateTimeFormatter
                    .ofPattern("HHmmss")
                    .withResolverStyle(ResolverStyle.STRICT);

            LocalTime.parse(timeStr, formatter);
            return true;

        } catch (DateTimeParseException e) {
            return false;
        }
    }
}
