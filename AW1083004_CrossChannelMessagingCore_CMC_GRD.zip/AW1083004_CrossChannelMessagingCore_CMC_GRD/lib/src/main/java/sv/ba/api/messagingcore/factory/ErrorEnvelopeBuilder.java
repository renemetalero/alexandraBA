package sv.ba.api.messagingcore.factory;

import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import org.springframework.http.HttpStatus;

import sv.ba.api.messagingcore.envelope.ErrorEnvelope;
import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.exception.ApiException;
import sv.ba.api.messagingcore.web.ApiRequestContext;

/**
 * Builder para construir {@link ErrorEnvelope} a partir de una
 * {@link ApiException}.
 *
 * <p>
 * Se obtiene a través de {@link MessageFactory#errorBuilder(ApiException)}
 * y es usado internamente por el
 * {@link sv.ba.api.messagingcore.web.ApiExceptionHandler} — no se instancia
 * directamente por el desarrollador. Hereda la generación de
 * {@link sv.ba.api.messagingcore.envelope.Metadata} de {@link EnvelopeBuilder},
 * propagando automáticamente el {@code _correlationId} desde el
 * {@link ApiRequestContext}.
 *
 * <p>
 * En la mayoría de los casos el
 * {@link sv.ba.api.messagingcore.web.ApiExceptionHandler}
 * construye el {@link ErrorEnvelope} directamente con un solo error:
 * 
 * <pre>
 * factory.errorBuilder(exception).build();
 * </pre>
 *
 * <p>
 * Para consolidar múltiples errores en una sola respuesta:
 * 
 * <pre>
 * factory.errorBuilder(exception)
 *         .withAdditionalErrors(otrosErrores)
 *         .build();
 * </pre>
 *
 * @author Jose Luis Pereira
 * @since 0.1.0
 * @see EnvelopeBuilder
 * @see MessageFactory
 * @see ResponseEnvelopeBuilder
 * @see ErrorEnvelope
 * @see ApiException
 * @see sv.ba.api.messagingcore.web.ApiExceptionHandler
 */
public final class ErrorEnvelopeBuilder extends EnvelopeBuilder<ErrorEnvelope> {

    private final ApiException exception;
    private List<ApiError> additionalErrors;

    ErrorEnvelopeBuilder(ApiRequestContext requestContext, ApiException exception) {
        super(requestContext);
        this.exception = Objects.requireNonNull(exception, "exception no puede ser null");
    }

    /**
     * Agrega errores adicionales a los que ya trae la excepción. Útil cuando
     * una operación produce múltiples errores simultáneos que deben
     * consolidarse en una sola respuesta.
     *
     * <p>
     * Los errores de la excepción siempre preceden a los adicionales en
     * el array {@code errors} del {@link ErrorEnvelope}.
     *
     * @param additionalErrors lista de errores adicionales. Si es {@code null}
     *                         o vacía, solo se incluyen los errores de la
     *                         excepción.
     * @return este builder para encadenamiento de llamadas.
     * @see ApiError
     */
    public ErrorEnvelopeBuilder withAdditionalErrors(List<ApiError> additionalErrors) {
        this.additionalErrors = additionalErrors;
        return this;
    }

    /**
     * Construye el {@link ErrorEnvelope} con la metadata resuelta, el código
     * HTTP, el mensaje HTTP y la lista de errores consolidada.
     *
     * @return {@link ErrorEnvelope} listo para retornar al consumidor.
     */
    @Override
    public ErrorEnvelope build() {
        return new ErrorEnvelope(
                resolveResponseMetadata(),
                String.valueOf(exception.httpStatus()),
                httpMessageFor(exception.httpStatus()),
                resolveErrors());
    }

    /**
     * Consolida los errores de la excepción con los errores adicionales si
     * los hay. Si no hay errores adicionales, retorna únicamente los errores
     * de la excepción.
     *
     * @return lista consolidada de {@link ApiError} para incluir en el
     *         {@link ErrorEnvelope}.
     */
    private List<ApiError> resolveErrors() {
        if (additionalErrors == null || additionalErrors.isEmpty()) {
            return exception.errors();
        }
        return Stream.concat(
                exception.errors().stream(),
                additionalErrors.stream()).toList();
    }

    /**
     * Traduce un código HTTP numérico a su mensaje estándar en mayúsculas.
     * Si el código no corresponde a ningún status HTTP conocido, retorna
     * {@code "ERROR"}.
     *
     * @param status código HTTP a traducir.
     * @return mensaje HTTP en mayúsculas. Ejemplo: {@code "CONFLICT"},
     *         {@code "NOT FOUND"}, {@code "ERROR"}.
     */
    private String httpMessageFor(int status) {
        try {
            return HttpStatus.valueOf(status).getReasonPhrase().toUpperCase();
        } catch (IllegalArgumentException e) {
            return "ERROR";
        }
    }
}
