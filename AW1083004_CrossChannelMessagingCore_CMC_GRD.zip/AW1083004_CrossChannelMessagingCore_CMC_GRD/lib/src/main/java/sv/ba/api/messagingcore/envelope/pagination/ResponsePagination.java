package sv.ba.api.messagingcore.envelope.pagination;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.Min;

/**
 * Representa el objeto {@code responsePagination} incluido en la respuesta
 * cuando el endpoint retorna resultados paginados.
 *
 * <p>
 * Se ubica al mismo nivel que {@code data} en la estructura del
 * {@link sv.ba.api.messagingcore.envelope.ResponseEnvelope} e indica al
 * consumidor si existen más páginas disponibles y el total de registros
 * encontrados para la consulta realizada.
 *
 * <p>
 * Ejemplo de uso en el response:
 * 
 * <pre>
 * {
 *   "metadata": { ... },
 *   "data": { ... },
 *   "responsePagination": {
 *     "lastPageIndicator": false,
 *     "totalRecords": 50
 *   }
 * }
 * </pre>
 *
 * @param lastPageIndicator indica si la página retornada es la última.
 *                          {@code true} si no hay más páginas disponibles,
 *                          {@code false} si aún existen registros en páginas
 *                          posteriores.
 * @param totalRecords      total de registros encontrados para la consulta,
 *                          independientemente de la página solicitada.
 *                          No puede ser negativo.
 *
 * @author Jose Luis Pereira
 * @see Pagination
 * @see sv.ba.api.messagingcore.envelope.ResponseEnvelope
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ResponsePagination(
        Integer currentPage,
        Integer pageSize,
        Integer totalPages,
        @Min(value = 0, message = "totalRecords no puede ser negativo") Integer totalRecords,
        Boolean hasNextpage,
        Boolean hasPreviousPage) {
}
