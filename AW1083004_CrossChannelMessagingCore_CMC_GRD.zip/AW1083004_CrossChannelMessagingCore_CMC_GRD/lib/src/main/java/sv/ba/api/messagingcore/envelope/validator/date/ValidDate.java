package sv.ba.api.messagingcore.envelope.validator.date;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DateIntegerValidator.class)
@Documented
public @interface ValidDate {

    String message() default "Fecha inválida (formato yyyyMMdd)";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
