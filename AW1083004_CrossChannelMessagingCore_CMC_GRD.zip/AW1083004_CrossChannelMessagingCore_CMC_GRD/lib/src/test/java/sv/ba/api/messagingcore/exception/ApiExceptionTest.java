package sv.ba.api.messagingcore.exception;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.error.ErrorPrefix;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;

@DisplayName("Manejo de Excepciones")
class ApiExceptionTest {

    private static final ApiError ERROR = new ApiError("BP40919001", "IBS", "Cuenta bloqueada");

    private static final RuntimeException CAUSA = new RuntimeException("error original");

    // -----------------------------------------------------------------
    // ApiException — constructores base
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("ApiException — constructor con List<ApiError>")
    class ConstructorLista {

        @Test
        @DisplayName("acepta lista con múltiples errores")
        void constructor_aceptaMultiplesErrores() {
            ApiError error2 = new ApiError("BP40919002", "IBS", "Saldo insuficiente");
            BusinessProviderException ex = new BusinessProviderException(409, List.of(ERROR, error2));

            assertThat(ex.errors()).hasSize(2);
            assertThat(ex.httpStatus()).isEqualTo(409);
        }

        @Test
        @DisplayName("mensaje es el detail del primer error")
        void constructor_mensajeEsPrimerDetail() {
            BusinessProviderException ex = new BusinessProviderException(409, List.of(ERROR));

            assertThat(ex.getMessage()).isEqualTo("Cuenta bloqueada");
        }

        @Test
        @DisplayName("lanza excepción si la lista está vacía")
        void constructor_lanzaExcepcion_siListaVacia() {
            List<ApiError> lista = List.of();
            assertThatThrownBy(() -> new BusinessProviderException(409, lista))
                    .isInstanceOf(IllegalArgumentException.class);
        }

        @Test
        @DisplayName("lanza NullPointerException si la lista es null")
        void constructor_lanzaExcepcion_siListaEsNull() {
            List<ApiError> lista = null;
            assertThatThrownBy(() -> new BusinessProviderException(409, lista))
                    .isInstanceOf(NullPointerException.class);
        }
    }

    @Nested
    @DisplayName("ApiException — constructor con Throwable")
    class ConstructorConCausa {

        @Test
        @DisplayName("preserva la causa original")
        void constructor_preservaCausa() {
            BusinessProviderException ex = new BusinessProviderException(409, "19001", "IBS",
                    "Cuenta bloqueada", CAUSA);

            assertThat(ex.getCause()).isEqualTo(CAUSA);
            assertThat(ex.getMessage()).isEqualTo("Cuenta bloqueada");
            assertThat(ex.httpStatus()).isEqualTo(409);
        }
    }

    // -----------------------------------------------------------------
    // Subclases — prefijos y constructores
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("BusinessProviderException — BP")
    class BusinessProviderTest {

        @Test
        @DisplayName("prefix es BP")
        void prefix_esBP() {
            assertThat(new BusinessProviderException(409, "19001", "IBS", "Error")
                    .prefix()).isEqualTo(ErrorPrefix.BP);
        }

        @Test
        @DisplayName("constructor con causa genera código correcto")
        void constructorConCausa_generaCodigoCorrecto() {
            BusinessProviderException ex = new BusinessProviderException(409, "19001", "IBS", "Error", CAUSA);

            assertThat(ex.errors().get(0).code()).isEqualTo("BP40919001");
            assertThat(ex.getCause()).isEqualTo(CAUSA);
        }

        @Test
        @DisplayName("constructor con lista preserva los errores")
        void constructorConLista_preservaErrores() {
            BusinessProviderException ex = new BusinessProviderException(409, List.of(ERROR));

            assertThat(ex.errors()).containsExactly(ERROR);
        }
    }

    @Nested
    @DisplayName("SystemProviderException — SP")
    class SystemProviderTest {

        @Test
        @DisplayName("prefix es SP")
        void prefix_esSP() {
            assertThat(new SystemProviderException(500, "19001", "IBS", "Error")
                    .prefix()).isEqualTo(ErrorPrefix.SP);
        }

        @Test
        @DisplayName("constructor principal genera código SP correcto")
        void constructor_generaCodigoSP() {
            SystemProviderException ex = new SystemProviderException(500, "19001", "IBS", "Error");

            assertThat(ex.errors().get(0).code()).isEqualTo("SP50019001");
        }

        @Test
        @DisplayName("constructor con causa preserva la causa")
        void constructorConCausa_preservaCausa() {
            SystemProviderException ex = new SystemProviderException(500, "19001", "IBS", "Error", CAUSA);

            assertThat(ex.getCause()).isEqualTo(CAUSA);
        }

        @Test
        @DisplayName("constructor con lista preserva los errores")
        void constructorConLista_preservaErrores() {
            ApiError error = new ApiError("SP50019001", "IBS", "Error");
            SystemProviderException ex = new SystemProviderException(500, List.of(error));

            assertThat(ex.errors()).containsExactly(error);
        }
    }

    @Nested
    @DisplayName("SystemApiException — SA")
    class SystemApiTest {

        @Test
        @DisplayName("prefix es SA")
        void prefix_esSA() {
            assertThat(new SystemApiException(500, "19001", "API", "Error")
                    .prefix()).isEqualTo(ErrorPrefix.SA);
        }

        @Test
        @DisplayName("constructor con causa preserva la causa")
        void constructorConCausa_preservaCausa() {
            SystemApiException ex = new SystemApiException(500, "19001", "API", "Error", CAUSA);

            assertThat(ex.getCause()).isEqualTo(CAUSA);
            assertThat(ex.errors().get(0).code()).isEqualTo("SA50019001");
        }

        @Test
        @DisplayName("constructor con lista preserva los errores")
        void constructorConLista_preservaErrores() {
            ApiError error = new ApiError("SA50019001", "API", "Error");
            SystemApiException ex = new SystemApiException(500, List.of(error));

            assertThat(ex.errors()).containsExactly(error);
        }
    }

    @Nested
    @DisplayName("SystemInfrastructureException — SI")
    class SystemInfrastructureTest {

        @Test
        @DisplayName("prefix es SI")
        void prefix_esSI() {
            assertThat(new SystemInfrastructureException(503, "19001", "API", "Error")
                    .prefix()).isEqualTo(ErrorPrefix.SI);
        }

        @Test
        @DisplayName("constructor principal genera código SI correcto")
        void constructor_generaCodigoSI() {
            SystemInfrastructureException ex = new SystemInfrastructureException(503, "19001", "API", "Error");

            assertThat(ex.errors().get(0).code()).isEqualTo("SI50319001");
        }

        @Test
        @DisplayName("constructor con causa preserva la causa")
        void constructorConCausa_preservaCausa() {
            SystemInfrastructureException ex = new SystemInfrastructureException(503, "19001", "API", "Error", CAUSA);

            assertThat(ex.getCause()).isEqualTo(CAUSA);
        }

        @Test
        @DisplayName("constructor con lista preserva los errores")
        void constructorConLista_preservaErrores() {
            ApiError error = new ApiError("SI50319001", "API", "Error");
            SystemInfrastructureException ex = new SystemInfrastructureException(503, List.of(error));

            assertThat(ex.errors()).containsExactly(error);
        }
    }

    @Nested
    @DisplayName("SystemMiddlewareException — SM")
    class SystemMiddlewareTest {

        @Test
        @DisplayName("prefix es SM")
        void prefix_esSM() {
            assertThat(new SystemMiddlewareException(502, "19001", "API", "Error")
                    .prefix()).isEqualTo(ErrorPrefix.SM);
        }

        @Test
        @DisplayName("constructor principal genera código SM correcto")
        void constructor_generaCodigoSM() {
            SystemMiddlewareException ex = new SystemMiddlewareException(502, "19001", "API", "Error");

            assertThat(ex.errors().get(0).code()).isEqualTo("SM50219001");
        }

        @Test
        @DisplayName("constructor con causa preserva la causa")
        void constructorConCausa_preservaCausa() {
            SystemMiddlewareException ex = new SystemMiddlewareException(502, "19001", "API", "Error", CAUSA);

            assertThat(ex.getCause()).isEqualTo(CAUSA);
        }

        @Test
        @DisplayName("constructor con lista preserva los errores")
        void constructorConLista_preservaErrores() {
            ApiError error = new ApiError("SM50219001", "API", "Error");
            SystemMiddlewareException ex = new SystemMiddlewareException(502, List.of(error));

            assertThat(ex.errors()).containsExactly(error);
        }
    }

    // -----------------------------------------------------------------
    // Switch exhaustivo — garantía sealed
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Switch exhaustivo sobre ApiException")
    class SwitchExhaustivo {

        @Test
        @DisplayName("cubre todas las subclases sealed")
        void switch_cubreTodosLosCasos() {
            List<ApiException> excepciones = List.of(
                    new BusinessProviderException(409, "19001", "IBS", "Error"),
                    new SystemProviderException(500, "19001", "IBS", "Error"),
                    new SystemApiException(500, "19001", "API", "Error"),
                    new SystemInfrastructureException(503, "19001", "API", "Error"),
                    new SystemMiddlewareException(502, "19001", "API", "Error"));

            for (ApiException ex : excepciones) {
                String prefijo = switch (ex) {
                    case BusinessProviderException e -> "BP";
                    case SystemProviderException e -> "SP";
                    case SystemApiException e -> "SA";
                    case SystemInfrastructureException e -> "SI";
                    case SystemMiddlewareException e -> "SM";
                };
                assertThat(prefijo).isEqualTo(ex.prefix().value());
            }
        }
    }

}
