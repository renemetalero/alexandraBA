package sv.ba.api.messagingcore.envelope.validator.time;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Validación de hora en Integer")
class HourIntegerValidatorTest {

	private final HourIntegerValidator validator = new HourIntegerValidator();

	@Test
	@DisplayName("acepta una hora válida en formato HHmmss")
	void isValid_conHoraValida_retornaTrue() {
		assertTrue(validator.isValid(173300, null));
	}

	@Test
	@DisplayName("acepta medianoche")
	void isValid_conMedianoche_retornaTrue() {
		assertTrue(validator.isValid(0, null));
	}

	@Test
	@DisplayName("acepta null")
	void isValid_conNull_retornaTrue() {
		assertTrue(validator.isValid(null, null));
	}

	@Test
	@DisplayName("rechaza una hora inexistente")
	void isValid_conHoraInvalida_retornaFalse() {
		assertFalse(validator.isValid(236060, null));
	}

	@Test
	@DisplayName("rechaza una hora fuera de rango")
	void isValid_conHoraFueraDeRango_retornaFalse() {
		assertFalse(validator.isValid(240000, null));
	}

}