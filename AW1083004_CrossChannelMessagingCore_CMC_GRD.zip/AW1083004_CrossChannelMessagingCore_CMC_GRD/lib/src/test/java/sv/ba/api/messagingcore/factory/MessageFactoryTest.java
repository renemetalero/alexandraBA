package sv.ba.api.messagingcore.factory;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import sv.ba.api.messagingcore.envelope.ErrorEnvelope;
import sv.ba.api.messagingcore.envelope.Metadata;
import sv.ba.api.messagingcore.envelope.ResponseEnvelope;
import sv.ba.api.messagingcore.envelope.header.CoreResponseHeader;
import sv.ba.api.messagingcore.envelope.pagination.ResponsePagination;
import sv.ba.api.messagingcore.error.ApiError;
import sv.ba.api.messagingcore.exception.BusinessProviderException;
import sv.ba.api.messagingcore.web.ApiRequestContext;

@DisplayName("Factory — branches y casos especiales")
class MessageFactoryTest {

    private static final String CORRELATION_ID = "e13a7e3e-7a59-40ea-b899-5a0f7f02cdcc";
    private static final String MESSAGE_ID = "89d75300-4048-42b0-8907-2192dceb6fbe";

    private ApiRequestContext context;
    private MessageFactory factory;

    @BeforeEach
    void setUp() {
        context = new ApiRequestContext();
        factory = new MessageFactory(context);
    }

    // -----------------------------------------------------------------
    // EnvelopeBuilder — newMetadata(String)
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("EnvelopeBuilder — newMetadata con correlationId")
    class NewMetadataConCorrelation {

        @Test
        @DisplayName("correlationId válido se incluye en la metadata")
        void newMetadata_conCorrelationId_seIncluye() {
            context.setMetadata(new Metadata(
                    MESSAGE_ID, CORRELATION_ID, LocalDateTime.now()));

            ErrorEnvelope envelope = factory.errorBuilder(
                    new BusinessProviderException(409, "19001", "IBS", "Error"))
                    .build();

            assertThat(envelope.metadata().correlationId())
                    .isEqualTo(CORRELATION_ID);
        }

        @Test
        @DisplayName("correlationId null produce metadata sin correlación")
        void newMetadata_correlationIdNull_sinCorrelacion() {
            ErrorEnvelope envelope = factory.errorBuilder(
                    new BusinessProviderException(409, "19001", "IBS", "Error"))
                    .build();

            assertThat(envelope.metadata().correlationId()).isNull();
        }

        @Test
        @DisplayName("correlationId vacío produce metadata sin correlación")
        void newMetadata_correlationIdVacio_sinCorrelacion() {
            context.setMetadata(new Metadata(
                    MESSAGE_ID, null, LocalDateTime.now()));

            ErrorEnvelope envelope = factory.errorBuilder(
                    new BusinessProviderException(409, "19001", "IBS", "Error"))
                    .build();

            assertThat(envelope.metadata().correlationId()).isNull();
        }
    }

    // -----------------------------------------------------------------
    // ErrorEnvelopeBuilder — withAdditionalErrors y resolveErrors
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("ErrorEnvelopeBuilder — errores adicionales")
    class ErroresAdicionales {

        @Test
        @DisplayName("withAdditionalErrors consolida errores de la excepción y adicionales")
        void errorBuilder_conErroresAdicionales_consolidaTodos() {
            ApiError errorAdicional = new ApiError("SA40019000", "API", "Campo requerido");

            ErrorEnvelope envelope = factory.errorBuilder(
                    new BusinessProviderException(409, "19001", "IBS", "Cuenta bloqueada"))
                    .withAdditionalErrors(List.of(errorAdicional))
                    .build();

            assertThat(envelope.errors()).hasSize(2);
            assertThat(envelope.errors().get(0).code()).isEqualTo("BP40919001");
            assertThat(envelope.errors().get(1).code()).isEqualTo("SA40019000");
        }

        @Test
        @DisplayName("withAdditionalErrors vacío no afecta los errores base")
        void errorBuilder_conErroresAdicionalesVacios_soloErroresBase() {
            ErrorEnvelope envelope = factory.errorBuilder(
                    new BusinessProviderException(409, "19001", "IBS", "Error"))
                    .withAdditionalErrors(List.of())
                    .build();

            assertThat(envelope.errors()).hasSize(1);
            assertThat(envelope.errors().get(0).code()).isEqualTo("BP40919001");
        }

        @Test
        @DisplayName("sin withAdditionalErrors solo incluye errores de la excepción")
        void errorBuilder_sinErroresAdicionales_soloErroresBase() {
            ErrorEnvelope envelope = factory.errorBuilder(
                    new BusinessProviderException(409, "19001", "IBS", "Error"))
                    .build();

            assertThat(envelope.errors()).hasSize(1);
        }
    }

    // -----------------------------------------------------------------
    // ErrorEnvelopeBuilder — httpMessageFor
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("ErrorEnvelopeBuilder — httpMessageFor")
    class HttpMessageFor {

        @Test
        @DisplayName("status HTTP válido retorna su mensaje estándar")
        void httpMessageFor_statusValido_retornaMensaje() {
            ErrorEnvelope envelope = factory.errorBuilder(
                    new BusinessProviderException(409, "19001", "IBS", "Error"))
                    .build();

            assertThat(envelope.message()).isEqualTo("CONFLICT");
        }
    }

    // -----------------------------------------------------------------
    // ResponseEnvelopeBuilder — withHeader y resolveHeader
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("ResponseEnvelopeBuilder — header")
    class HeaderBuilder {

        @Test
        @DisplayName("withHeader personalizado se usa en lugar del del contexto")
        void responseBuilder_withHeader_usaHeaderPersonalizado() {
            context.setMetadata(new Metadata(
                    MESSAGE_ID, CORRELATION_ID, LocalDateTime.now()));

            CoreResponseHeader customHeader = new CoreResponseHeader(
                    20250408,
                    Integer.valueOf("02"), "MB",
                    100000,
                    null, Integer.valueOf("001"), "000001");

            ResponseEnvelope<String> response = factory.<String>responseBuilder()
                    .withHeader(customHeader)
                    .withBody("body")
                    .build();

            assertThat(response.data().header().instanceId()).isEqualTo(02);
            assertThat(response.data().header().system()).isEqualTo("MB");
        }

        @Test
        @DisplayName("sin withHeader usa el header del contexto cuando existe")
        void responseBuilder_sinWithHeader_usaHeaderDelContexto() {
            context.setMetadata(new Metadata(
                    MESSAGE_ID, CORRELATION_ID, LocalDateTime.now()));

            sv.ba.api.messagingcore.envelope.header.CoreRequestHeader reqHeader = new sv.ba.api.messagingcore.envelope.header.CoreRequestHeader(
                    20250408, Integer.valueOf("01"), "BM",
                    173300, null,
                    "3711", Integer.valueOf("031"), null, "000003711", null);
            context.setHeader(reqHeader);

            ResponseEnvelope<String> response = factory.<String>responseBuilder()
                    .withBody("body")
                    .build();

            assertThat(response.data().header().branch()).isEqualTo(037);
            assertThat(response.data().header().channelId()).isEqualTo("000003711");
        }

        @Test
        @DisplayName("resolveHeader retorna null cuando el contexto no tiene header")
        void responseBuilder_sinHeader_retornaNull() {
            ResponseEnvelope<String> response = factory.<String>responseBuilder()
                    .withBody("body")
                    .build();

            assertThat(response.data().header()).isNull();
        }
    }

    // -----------------------------------------------------------------
    // ResponseEnvelopeBuilder — body requerido
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("ResponseEnvelopeBuilder — validaciones")
    class Validaciones {

        @Test
        @DisplayName("build lanza NullPointerException si body es null")
        void responseBuilder_sinBody_lanzaExcepcion() {
            ResponseEnvelopeBuilder<String> builder = factory.<String>responseBuilder();
            assertThrows(NullPointerException.class, builder::build);
        }

        @Test
        @DisplayName("success con paginacion construye ResponseEnvelope correcto")
        void factory_successConPaginacion_construyeEnvelope() {
            context.setMetadata(new Metadata(
                    MESSAGE_ID, CORRELATION_ID, LocalDateTime.now()));

            ResponsePagination pagination = new ResponsePagination(5, 10, 15, 50, true, true);
            ResponseEnvelope<String> response = factory.success("body", pagination);

            assertThat(response.responsePagination().hasNextpage()).isTrue();
            assertThat(response.responsePagination().totalRecords()).isEqualTo(50);
        }
    }
}
