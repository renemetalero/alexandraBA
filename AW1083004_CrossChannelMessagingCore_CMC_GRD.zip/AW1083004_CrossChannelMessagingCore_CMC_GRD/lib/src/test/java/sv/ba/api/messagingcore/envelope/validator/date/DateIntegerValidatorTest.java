package sv.ba.api.messagingcore.envelope.validator.date;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Validación de fecha en Integer")
class DateIntegerValidatorTest {

	private final DateIntegerValidator validator = new DateIntegerValidator();

	@Test
	@DisplayName("acepta una fecha válida en formato yyyyMMdd")
	void isValid_conFechaValida_retornaTrue() {
		assertTrue(validator.isValid(20250408, null));
	}

	@Test
	@DisplayName("acepta una fecha bisiesta válida")
	void isValid_conFechaBisiestaValida_retornaTrue() {
		assertTrue(validator.isValid(20240229, null));
	}

	@Test
	@DisplayName("acepta null")
	void isValid_conNull_retornaTrue() {
		assertTrue(validator.isValid(null, null));
	}

	@Test
	@DisplayName("rechaza una fecha inexistente")
	void isValid_conFechaInvalida_retornaFalse() {
		assertFalse(validator.isValid(20250230, null));
	}

	@Test
	@DisplayName("rechaza un mes fuera de rango")
	void isValid_conMesFueraDeRango_retornaFalse() {
		assertFalse(validator.isValid(20251301, null));
	}

}