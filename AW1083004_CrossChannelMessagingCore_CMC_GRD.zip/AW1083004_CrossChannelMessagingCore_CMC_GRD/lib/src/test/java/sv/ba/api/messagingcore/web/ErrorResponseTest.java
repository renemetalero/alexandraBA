package sv.ba.api.messagingcore.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.matchesPattern;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import sv.ba.api.messagingcore.envelope.RequestData;
import sv.ba.api.messagingcore.envelope.RequestEnvelope;
import sv.ba.api.messagingcore.envelope.header.CoreRequestHeader;
import sv.ba.api.messagingcore.exception.BusinessProviderException;
import sv.ba.api.messagingcore.exception.SystemApiException;
import sv.ba.api.messagingcore.factory.MessageFactory;

@DisplayName("Respuestas de error")
class ErrorResponseTest<B> {

    private static final String CORRELATION_ID = "e13a7e3e-7a59-40ea-b899-5a0f7f02cdcc";
    private MockMvc mockMvc;
    private ObjectMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        ApiRequestContext requestContext = new ApiRequestContext();
        MessageFactory factory = new MessageFactory(requestContext);
        RequestContextAdvice advice = new RequestContextAdvice(requestContext);
        ApiExceptionHandler handler = new ApiExceptionHandler(factory);
        TraceabilityHeadersInterceptor interceptor = new TraceabilityHeadersInterceptor(requestContext);

        mockMvc = MockMvcBuilders
                .standaloneSetup(new TestController(factory))
                .setControllerAdvice(advice, handler)
                .addInterceptors(interceptor)
                .build();
    }

    // -----------------------------------------------------------------
    // Estructura del ErrorEnvelope
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Estructura del ErrorEnvelope")
    class EstructuraEnvelope {

        @Test
        @DisplayName("contiene metadata, status, message y errors")
        void error_contieneNodosRequeridos() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.metadata").exists())
                    .andExpect(jsonPath("$.status").exists())
                    .andExpect(jsonPath("$.message").exists())
                    .andExpect(jsonPath("$.errors").isArray());
        }

        @Test
        @DisplayName("errors tiene al menos un elemento")
        void error_errorsNoEsVacio() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.errors[0]").exists())
                    .andExpect(jsonPath("$.errors[0].code").exists())
                    .andExpect(jsonPath("$.errors[0].title").exists())
                    .andExpect(jsonPath("$.errors[0].detail").exists());
        }

        @Test
        @DisplayName("_datetime tiene formato YYYY-MM-DDTHH:MM:SS")
        void error_datetimeConFormatoEstandar() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.metadata._datetime")
                            .value(matchesPattern(
                                    "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}")));
        }
    }

    // -----------------------------------------------------------------
    // Metadata y correlación
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Metadata y correlación")
    class MetadataTest {

        @Test
        @DisplayName("propaga _correlationId del request al ErrorEnvelope")
        void error_propagaCorrelationId() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("correlationId", CORRELATION_ID)
                    .content(buildRequest()))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.metadata._correlationId")
                            .value(CORRELATION_ID));
        }

        @Test
        @DisplayName("_correlationId no existe cuando no viene en el request")
        void error_sinCorrelationId_noSeIncluye() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.metadata._correlationId").doesNotExist());
        }
    }

    // -----------------------------------------------------------------
    // Códigos de error
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Códigos de error")
    class CodigosError {

        @Test
        @DisplayName("BP genera código con prefijo BP y formato correcto")
        void error_businessProvider_generaCodigoBP() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.errors[0].code").value("BP40919001"));
        }

        @Test
        @DisplayName("SA genera código con prefijo SA y formato correcto")
        void error_systemApi_generaCodigoSA() throws Exception {
            mockMvc.perform(post("/test/system-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isInternalServerError())
                    .andExpect(jsonPath("$.errors[0].code").value("SA50019500"));
        }
    }

    // -----------------------------------------------------------------
    // Errores de Spring
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Errores generados por Spring")
    class ErroresSpring {

        @Test
        @DisplayName("body malformado genera 400")
        void error_bodyMalformado_genera400() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("esto no es json"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value("400"))
                    .andExpect(jsonPath("$.errors").isArray());
        }

        @Test
        @DisplayName("método HTTP no soportado genera 405")
        void error_metodoNoSoportado_genera405() throws Exception {
            mockMvc.perform(get("/test/business-error"))
                    .andExpect(status().isMethodNotAllowed())
                    .andExpect(jsonPath("$.status").value("405"));
        }

        @Test
        @DisplayName("validación fallida genera 400 con detalle del campo")
        void error_validacionFallida_genera400ConDetalle() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequestSinMetadata()))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value("400"))
                    .andExpect(jsonPath("$.errors").isArray());
        }

        @Test
        @DisplayName("ConstraintViolationException genera 400")
        void error_constraintViolation_genera400() throws Exception {
            mockMvc.perform(post("/test/constraint-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value("400"))
                    .andExpect(jsonPath("$.errors").isArray());
        }

        @Test
        @DisplayName("Content-Type no soportado genera 415")
        void error_mediaTypeNoSoportado_genera415() throws Exception {
            mockMvc.perform(post("/test/business-error")
                    .contentType(MediaType.TEXT_PLAIN)
                    .content("texto"))
                    .andExpect(status().isUnsupportedMediaType())
                    .andExpect(jsonPath("$.status").value("415"));
        }

        @Test
        @DisplayName("excepción inesperada genera 500")
        void error_excepcionInesperada_genera500() throws Exception {
            mockMvc.perform(post("/test/unexpected-error")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isInternalServerError())
                    .andExpect(jsonPath("$.status").value("500"))
                    .andExpect(jsonPath("$.errors[0].detail")
                            .value("Error interno del servidor"));
        }

        @Test
        @DisplayName("validación sin field errors usa mensaje genérico")
        void error_validacionSinFieldErrors_usaMensajeGenerico() throws Exception {
            mockMvc.perform(post("/test/constraint-empty")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.errors[0].detail")
                            .value("Solicitud inválida"));
        }
    }

    @Nested
    @DisplayName("ApiRequestContext y RequestContextAdvice")
    class ContextoYAdvice {

        @Test
        @DisplayName("getCorrelationId retorna null cuando no hay metadata")
        void context_sinMetadata_correlationIdEsNull() {
            ApiRequestContext context = new ApiRequestContext();
            assertThat(context.getCorrelationId()).isNull();
        }

        @Test
        @DisplayName("getCorrelationId retorna el valor cuando hay metadata")
        void context_conMetadata_retornaCorrelationId() {
            ApiRequestContext context = new ApiRequestContext();
            context.setMetadata(new sv.ba.api.messagingcore.envelope.Metadata(
                    "89d75300-4048-42b0-8907-2192dceb6fbe",
                    CORRELATION_ID,
                    java.time.LocalDateTime.now()));

            assertThat(context.getCorrelationId()).isEqualTo(CORRELATION_ID);
        }

        @Test
        @DisplayName("afterBodyRead ignora body que no es RequestEnvelope")
        void advice_afterBodyRead_ignoraBodyNoEnvelope() {
            ApiRequestContext context = new ApiRequestContext();
            RequestContextAdvice advice = new RequestContextAdvice(context);

            Object resultado = advice.afterBodyRead(
                    "string-cualquiera", null, null, null, null);

            assertThat(resultado).isEqualTo("string-cualquiera");
            assertThat(context.hasMetadata()).isFalse();
        }

        @Test
        @DisplayName("handleEmptyBody retorna el body sin modificar")
        void advice_handleEmptyBody_retornaBodySinModificar() {
            ApiRequestContext context = new ApiRequestContext();
            RequestContextAdvice advice = new RequestContextAdvice(context);

            Object resultado = advice.handleEmptyBody(
                    null, null, null, null, null);

            assertThat(resultado).isNull();
        }
    }

    // -----------------------------------------------------------------
    // Controller y helpers
    // -----------------------------------------------------------------

    @RestController
    @RequestMapping("/test")
    static class TestController {

        private final MessageFactory factory;

        TestController(MessageFactory factory) {
            this.factory = factory;
        }

        @PostMapping("/business-error")
        public void businessError(
                @RequestBody @Valid RequestEnvelope<SampleBody> request) {
            throw new BusinessProviderException(409, "19001", "IBS", "Cuenta bloqueada");
        }

        @PostMapping("/system-error")
        public void systemError(
                @RequestBody @Valid RequestEnvelope<SampleBody> request) {
            throw new SystemApiException(500, "19500", "API", "Error interno del sistema");
        }

        @PostMapping("/constraint-error")
        public void constraintError(
                @RequestBody @Valid RequestEnvelope<SampleBody> request) {
            Set<ConstraintViolation<?>> violations = new HashSet<>();
            violations.add(createViolation("campo", "no debe ser nulo"));
            throw new ConstraintViolationException(violations);
        }

        @PostMapping("/constraint-empty")
        public void constraintEmpty(
                @RequestBody @Valid RequestEnvelope<SampleBody> request) {
            throw new ConstraintViolationException(new HashSet<>());
        }

        @PostMapping("/unexpected-error")
        public void unexpectedError(
                @RequestBody @Valid RequestEnvelope<SampleBody> request) {
            throw new RuntimeException("error inesperado");
        }

        private ConstraintViolation<?> createViolation(String path, String message) {
            return new ConstraintViolation<>() {
                public String getMessage() {
                    return message;
                }

                public String getMessageTemplate() {
                    return message;
                }

                public Object getRootBean() {
                    return null;
                }

                public Class<Object> getRootBeanClass() {
                    return null;
                }

                public Object getLeafBean() {
                    return null;
                }

                public Object[] getExecutableParameters() {
                    return new Object[0];
                }

                public Object getExecutableReturnValue() {
                    return null;
                }

                public jakarta.validation.Path getPropertyPath() {
                    return new jakarta.validation.Path() {
                        public Iterator<Node> iterator() {
                            return List.<Node>of().iterator();
                        }

                        public String toString() {
                            return path;
                        }
                    };
                }

                public Object getInvalidValue() {
                    return null;
                }

                public jakarta.validation.metadata.ConstraintDescriptor<?> getConstraintDescriptor() {
                    return null;
                }

                public <U> U unwrap(Class<U> type) {
                    return null;
                }
            };
        }
    }

    record SampleBody(String valor) {
    }

    private String buildRequest() throws Exception {
        CoreRequestHeader header = new CoreRequestHeader(
                20250408, Integer.valueOf("01"), "BM",
                173300, "168.0.0.1",
                "3711", Integer.valueOf("037"), "jperez", "000003711",  Integer.valueOf("0080"));

        return mapper.writeValueAsString(new RequestEnvelope<>(
                new RequestData<>(header, new SampleBody("datos")),
                null));
    }

    private String buildRequestSinMetadata() throws Exception {
        return mapper.writeValueAsString(
                new RequestEnvelope<>(new RequestData<SampleBody>(null, null), null));
    }
}
