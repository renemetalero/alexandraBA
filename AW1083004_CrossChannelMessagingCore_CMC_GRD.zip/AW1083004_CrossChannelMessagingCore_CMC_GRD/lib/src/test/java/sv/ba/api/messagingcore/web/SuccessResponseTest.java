package sv.ba.api.messagingcore.web;

import static org.hamcrest.Matchers.matchesPattern;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import sv.ba.api.messagingcore.envelope.RequestData;
import sv.ba.api.messagingcore.envelope.RequestEnvelope;
import sv.ba.api.messagingcore.envelope.ResponseEnvelope;
import sv.ba.api.messagingcore.envelope.header.CoreRequestHeader;
import sv.ba.api.messagingcore.envelope.pagination.Pagination;
import sv.ba.api.messagingcore.envelope.pagination.ResponsePagination;
import sv.ba.api.messagingcore.factory.MessageFactory;

@DisplayName("Respuestas exitosas")
class SuccessResponseTest {

    private static final String CORRELATION_ID = "e13a7e3e-7a59-40ea-b899-5a0f7f02cdcc";
    private static final String MESSAGE_ID = "89d75300-4048-42b0-8907-2192dceb6fbe";

    private MockMvc mockMvc;
    private ObjectMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        ApiRequestContext requestContext = new ApiRequestContext();
        MessageFactory factory = new MessageFactory(requestContext);
        RequestContextAdvice advice = new RequestContextAdvice(requestContext);
        TraceabilityHeadersInterceptor interceptor = new TraceabilityHeadersInterceptor(requestContext);

        mockMvc = MockMvcBuilders
                .standaloneSetup(new TestController(factory))
                .setControllerAdvice(advice)
                .addInterceptors(interceptor)
                .build();
    }

    // -----------------------------------------------------------------
    // Estructura del envelope
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Estructura del ResponseEnvelope")
    class EstructuraEnvelope {

        @Test
        @DisplayName("contiene metadata, data y body")
        void response_contieneNodosRequeridos() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.metadata").exists())
                    .andExpect(jsonPath("$.data").exists())
                    .andExpect(jsonPath("$.data.body").exists());
        }

        @Test
        @DisplayName("_datetime tiene formato YYYY-MM-DDTHH:MM:SS")
        void response_datetimeConFormatoEstandar() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.metadata._datetime")
                            .value(matchesPattern(
                                    "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}")));
        }
    }

    // -----------------------------------------------------------------
    // Metadata
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Metadata")
    class MetadataTest {

        @Test
        @DisplayName("genera nuevo _messageId diferente al del request")
        void response_generaNuevoMessageId() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.metadata._messageId")
                            .value(not(MESSAGE_ID)));
        }

        @Test
        @DisplayName("propaga _correlationId cuando viene en el request")
        void response_propagaCorrelationId() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("correlationId", CORRELATION_ID)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.metadata._correlationId")
                            .value(CORRELATION_ID));
        }

        @Test
        @DisplayName("_correlationId no existe en response cuando no viene en el request")
        void response_sinCorrelationId_noSeIncluye() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.metadata._correlationId").doesNotExist());
        }
    }

    // -----------------------------------------------------------------
    // Header
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Header del response")
    class HeaderTest {

        @Test
        @DisplayName("no contiene supervisor, user ni locationUser")
        void response_headerSinCamposRestringidos() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.header.supervisor").doesNotExist())
                    .andExpect(jsonPath("$.data.header.user").doesNotExist())
                    .andExpect(jsonPath("$.data.header.locationUser").doesNotExist());
        }

        @Test
        @DisplayName("conserva campos comunes del header del request")
        void response_headerConservaCamposComunes() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.header.branch").value(Integer.valueOf("037")))
                    .andExpect(jsonPath("$.data.header.channelId").value("000003711"))
                    .andExpect(jsonPath("$.data.header.date").value(20250408))
                    .andExpect(jsonPath("$.data.header.hour").value(173300));
        }
    }

    // -----------------------------------------------------------------
    // Paginación
    // -----------------------------------------------------------------

    @Nested
    @DisplayName("Paginación")
    class PaginacionTest {

        @Test
        @DisplayName("incluye responsePagination cuando se especifica")
        void response_conPaginacion_incluyeResponsePagination() throws Exception {
            mockMvc.perform(post("/test/paginated")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequestConPaginacion()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.responsePagination").exists())
                    .andExpect(jsonPath("$.responsePagination.hasPreviousPage")
                            .value(true))
                    .andExpect(jsonPath("$.responsePagination.totalRecords")
                            .value(100));
        }

        @Test
        @DisplayName("no incluye responsePagination cuando no se especifica")
        void response_sinPaginacion_noSeIncluye() throws Exception {
            mockMvc.perform(post("/test/success")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(buildRequest()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.responsePagination").doesNotExist());
        }

        @Test
        @DisplayName("_correlationId se propaga también en response paginado")
        void response_conPaginacion_propagaCorrelationId() throws Exception {
            mockMvc.perform(post("/test/paginated")
                    .contentType(MediaType.APPLICATION_JSON)
                    .header("correlationId", CORRELATION_ID)
                    .content(buildRequestConPaginacion()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.metadata._correlationId")
                            .value(CORRELATION_ID));
        }
    }

    // -----------------------------------------------------------------
    // Controller y helpers
    // -----------------------------------------------------------------

    @RestController
    @RequestMapping("/test")
    static class TestController {

        private final MessageFactory factory;

        TestController(MessageFactory factory) {
            this.factory = factory;
        }

        @PostMapping("/success")
        public ResponseEnvelope<SampleBody> success(
                @RequestBody @Valid RequestEnvelope<SampleBody> request) {
            return factory.success(new SampleBody("respuesta"));
        }

        @PostMapping("/paginated")
        public ResponseEnvelope<SampleBody> paginated(
                @RequestBody @Valid RequestEnvelope<SampleBody> request) {
            return factory.success(
                    new SampleBody("respuesta"),
                    new ResponsePagination(5, 10, 20, 100, true, true));
        }
    }

    record SampleBody(String valor) {
    }

    private String buildRequest() throws Exception {
        CoreRequestHeader header = new CoreRequestHeader(
                20250408, Integer.valueOf("01"), "BM",
                173300, "168.0.0.1",
                "3711", Integer.valueOf("037"), "jperez", "000003711", Integer.valueOf("0080"));

        return mapper.writeValueAsString(new RequestEnvelope<>(
                new RequestData<>(header, new SampleBody("datos")),
                null));
    }

    private String buildRequestConPaginacion() throws Exception {
        CoreRequestHeader header = new CoreRequestHeader(
                20250408, Integer.valueOf("01"), "BM",
                173300, null,
                "3711", Integer.valueOf("037"), null, "000003711", null);

        return mapper.writeValueAsString(new RequestEnvelope<>(
                new RequestData<>(header, new SampleBody("datos")),
                new Pagination(1, 10)));
    }
}
