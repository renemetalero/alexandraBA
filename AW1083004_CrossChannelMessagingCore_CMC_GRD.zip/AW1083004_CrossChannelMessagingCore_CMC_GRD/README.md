# api-messaging-core

Librería Java 21 que abstrae la capa de transformación de datos para request,
response y manejo de errores en APIs REST, conforme al estándar interno de
mensajería basado en JSON:API 1.1.

---

## Índice

| # | Sección |
|---|---|
| 1 | [¿Qué es?](#qué-es) |
| 2 | [Requisitos](#requisitos) |
| 3 | [Instalación](#instalación) |
| 4 | [Configuración inicial](#configuración-inicial) |
| 5 | [Uso básico](#uso-básico) |
| 5.1 | [Respuesta exitosa](#respuesta-exitosa) |
| 5.2 | [Respuesta paginada](#respuesta-paginada) |
| 5.3 | [Manejo de errores](#manejo-de-errores) |
| 5.4 | [Excepciones disponibles](#excepciones-disponibles) |
| 6 | [Personalización](#personalización) |
| 6.1 | [Crear excepciones específicas](#crear-excepciones-específicas-recomendado) |
| 6.2 | [Extender el ExceptionHandler](#extender-el-exceptionhandler) |
| 6.3 | [Extender la configuración](#extender-la-configuración) |
| 6.4 | [Control granular con el builder](#control-granular-con-el-builder) |
| 7 | [Estructura del estándar](#estructura-del-estándar) |
| 7.1 | [Request](#request) |
| 7.2 | [Response exitoso](#response-exitoso) |
| 7.3 | [Response de error](#response-de-error) |
| 8 | [Headers de seguridad](#headers-de-seguridad) |
| 9 | [Tabla de prefijos de error](#tabla-de-prefijos-de-error) |
| 10 | [Componentes de la librería](#componentes-de-la-librería) |
| 11 | [Versión](#versión) |

---

## ¿Qué es?

`api-messaging-core` es una librería diseñada para estandarizar la capa de
transformación de datos en microservicios Spring Boot. Permite a los
desarrolladores enfocarse únicamente en la lógica de negocio, delegando a
la librería la construcción de envelopes de request/response, el manejo de
errores y la intercepcion y aplicación de headers de seguridad conforme al estándar.

**Responsabilidades del desarrollador al usar la librería:**

- Definir los DTOs del negocio (request y response).
- Implementar la lógica de negocio en la capa de servicio.
- Lanzar la excepción correspondiente cuando algo falla.
- Retornar el body al factory cuando la operación es exitosa.

**Lo que resuelve la librería automáticamente:**

- Construcción del `RequestEnvelope` y `ResponseEnvelope`.
- Generación del `_messageId` y propagación del `_correlationId`.
- Derivación del header de respuesta desde el header del request.
- Captura y transformación de excepciones en `ErrorEnvelope`.
- Itercepción y aplicación de headers de seguridad en todas las peticiones y respuestas.

---

## Requisitos

- Java 21
- Spring Boot 3.x / 4.x
- Gradle

---

## Instalación

Agrega la dependencia en el `build.gradle` de tu microservicio:

```groovy
dependencies {
    implementation 'sv.ba:api-messaging-core:1.0.0'
}
```

---

## Configuración inicial

La librería requiere tres configuraciones en la clase principal del
microservicio para funcionar correctamente:

```java
@SpringBootApplication
@Import({ MessagingCoreConfiguration.class, RequestContextAdvice.class })
@ComponentScan(basePackages = {
        "sv.ba.api.messagingcore",
        "com.example.tu_paquete"    // paquete raíz de tu microservicio
})
public class MiApplication {
    public static void main(String[] args) {
        SpringApplication.run(MiApplication.class, args);
    }
}
```

| Anotación | Propósito |
|---|---|
| `@Import(MessagingCoreConfiguration.class)` | Registra los beans de la librería |
| `@Import(RequestContextAdvice.class)` | Registra el interceptor del body |
| `@ComponentScan` | Permite que Spring detecte los beans de la librería y del microservicio |

Con esto quedan registrados automáticamente:

| Bean | Descripción |
|---|---|
| `MessageFactory` | Para construir respuestas exitosas y de error |
| `ApiExceptionHandler` | Para capturar y transformar excepciones |
| `RequestContextAdvice` | Para interceptar el body del request |
| `SecurityHeadersFilter` | Para aplicar headers de seguridad |

> Si necesitas personalizar alguno de estos componentes, puedes declarar
> tu propio bean del mismo tipo y la librería no registrará el suyo gracias
> al mecanismo `@ConditionalOnMissingBean`.

---

## Uso básico

### Respuesta exitosa

**Paso 1 — Define los DTOs del negocio:**

```java
// Request body
public record CuentaRequest(
        @NotBlank String accountNumber
) {}

// Response body
public record CuentaResponse(
        String accountNumber,
        String accountHolder,
        String status,
        BigDecimal balance
) {}
```

**Paso 2 — Crea el controller:**

```java
@RestController
@RequestMapping("/api/cuentas")
public class CuentaController {

    private final CuentaService service;
    private final MessageFactory factory;

    public CuentaController(CuentaService service, MessageFactory factory) {
        this.service = service;
        this.factory = factory;
    }

    @PostMapping("/consulta")
    public ResponseEnvelope<CuentaResponse> consultar(
            @RequestBody @Valid RequestEnvelope<CuentaRequest> request) {
        return factory.success(
                service.consultar(request.data().body()));
    }
}
```

### Respuesta paginada

```java
@PostMapping("/buscar")
public ResponseEnvelope<List<CuentaResponse>> buscar(
        @RequestBody @Valid RequestEnvelope<BusquedaRequest> request) {

    int pageNumber = request.pagination() != null
            ? request.pagination().pageNumber() : 1;
    int pageSize = request.pagination() != null
            ? request.pagination().pageSize() : 10;

    Page<CuentaResponse> page = service.buscar(
            request.data().body(), pageNumber, pageSize);

    return factory.success(
            page.content(),
            new ResponsePagination(page.isLast(), page.totalRecords()));
}
```

### Manejo de errores

Lanza la excepción correspondiente desde la capa de servicio. La librería
la captura automáticamente y construye el `ErrorEnvelope`:

```java
@Service
public class CuentaService {

    public CuentaResponse consultar(CuentaRequest request) {

        // Error de negocio en el proveedor
        if (cuenta.isBloqueada()) {
            throw new BusinessProviderException(
                    409, "19001", "IBS", "La cuenta está bloqueada");
        }

        // Error de sistema en el proveedor
        if (!proveedorDisponible()) {
            throw new SystemProviderException(
                    503, "19002", "IBS", "El servicio no está disponible");
        }
    }
}
```

### Excepciones disponibles

| Excepción | Prefijo | Cuándo usarla |
|---|---|---|
| `BusinessProviderException` | `BP` | Error de negocio en el proveedor o backend |
| `SystemProviderException` | `SP` | Error de sistema en el proveedor o backend |
| `SystemApiException` | `SA` | Error de sistema propio del API |
| `SystemInfrastructureException` | `SI` | Error en infraestructura de capa media |
| `SystemMiddlewareException` | `SM` | Error en el API de capa media |

El código de error se construye automáticamente con el formato:

```
<prefijo> + <httpStatus> + <evc>
ejemplo: BP + 409 + 19001 = BP40919001
```

El código EVC es de 5 dígitos y lo define cada equipo según el rango
asignado a su microservicio.

---

## Personalización

### Crear excepciones específicas (recomendado)

En lugar de lanzar las excepciones base directamente, se recomienda crear
excepciones tipadas en cada microservicio:

```java
public class CuentaBloqueadaException extends BusinessProviderException {
    public CuentaBloqueadaException() {
        super(409, "19001", "IBS", "La cuenta está bloqueada");
    }
}

// Uso en el servicio — claro y sin parámetros
throw new CuentaBloqueadaException();
```

### Extender el ExceptionHandler

Si necesitas agregar handlers propios o personalizar el comportamiento base:

```java
@RestControllerAdvice
public class MiExceptionHandler extends ApiExceptionHandler {

    public MiExceptionHandler(MessageFactory factory) {
        super(factory);
    }

    // Hook antes de procesar la excepción
    @Override
    protected void beforeHandle(ApiException ex) {
        log.warn("Error [{}]: {}", ex.prefix(), ex.getMessage());
    }

    // Hook después de construir la respuesta
    @Override
    protected void afterHandle(ApiException ex, ErrorEnvelope envelope) {
        // auditoría, métricas, notificaciones, etc.
    }

    // Handler propio para una excepción específica
    @ExceptionHandler(MiExcepcionEspecifica.class)
    public ResponseEntity<ErrorEnvelope> handleMiExcepcion(
            MiExcepcionEspecifica ex, HttpServletResponse response) {
        SecurityHeaders.apply(response);
        return ResponseEntity.status(ex.httpStatus())
                .body(messageFactory.errorBuilder(ex).build());
    }
}
```

### Extender la configuración

Si necesitas agregar beans adicionales sin perder los de la librería:

```java
@Configuration
public class MiConfiguracion extends MessagingCoreConfiguration {

    public MiConfiguracion(ApiRequestContext requestContext) {
        super(requestContext);
    }

    @Bean
    public MiServicio miServicio() {
        return new MiServicio();
    }
}
```

### Control granular con el builder

Para casos que requieren mayor control sobre la construcción del response:

```java
// Response con header personalizado
return factory.<MiResponse>responseBuilder()
        .withHeader(miHeaderPersonalizado)
        .withBody(body)
        .withPagination(new ResponsePagination(true, 50))
        .build();

// Error con errores adicionales consolidados
ErrorEnvelope envelope = messageFactory.errorBuilder(exception)
        .withAdditionalErrors(otrosErrores)
        .build();
```

---

## Estructura del estándar

### Request

```json
{
  "metadata": {
    "_messageId": "89d75300-4048-42b0-8907-2192dceb6fbe",
    "_correlationId": "e13a7e3e-7a59-40ea-b899-5a0f7f02cdcc",
    "_datetime": "2025-04-08T17:33:00"
  },
  "data": {
    "header": {
      "date": "20250408",
      "instanceId": "01",
      "system": "BM",
      "hour": "173300",
      "locationUser": "192.168.1.1",
      "batch": "3711",
      "branch": "037",
      "user": "jperez",
      "channelId": "000003711",
      "supervisor": "0080"
    },
    "body": {
      "campo1": "valor1",
      "campo2": "valor2"
    }
  },
  "pagination": {
    "pageNumber": 1,
    "pageSize": 10
  }
}
```

> `_correlationId` es opcional. `pagination` solo se incluye en endpoints
> que retornan resultados paginados. Todos los campos del `header` son
> condicionales según la operación.

### Response exitoso

```json
{
  "metadata": {
    "_messageId": "nuevo-uuid-generado",
    "_correlationId": "e13a7e3e-7a59-40ea-b899-5a0f7f02cdcc",
    "_datetime": "2025-04-08T17:33:01"
  },
  "data": {
    "header": {
      "date": "20250408",
      "instanceId": "01",
      "system": "BM",
      "hour": "173301",
      "batch": "3711",
      "branch": "037",
      "channelId": "000003711"
    },
    "body": {
      "campo1": "valor1",
      "campo2": "valor2"
    }
  },
  "responsePagination": {
    "lastPageIndicator": false,
    "totalRecords": 50
  }
}
```

> El `_messageId` siempre es nuevo en la respuesta. El `_correlationId`
> se propaga desde el request si estaba presente — si no venía, tampoco
> se incluye en la respuesta. Los campos `supervisor`, `user` y
> `locationUser` no se incluyen en el header de la respuesta.

### Response de error

```json
{
  "metadata": {
    "_messageId": "nuevo-uuid-generado",
    "_correlationId": "e13a7e3e-7a59-40ea-b899-5a0f7f02cdcc",
    "_datetime": "2025-04-08T17:33:01"
  },
  "status": "409",
  "message": "CONFLICT",
  "errors": [
    {
      "code": "BP40919001",
      "title": "IBS",
      "detail": "La cuenta está bloqueada"
    }
  ]
}
```

> Los headers de la respuesta de error son los mismos que en la respuesta
> exitosa. El campo `errors` siempre es un array, incluso cuando hay un
> único error.

---

## Headers de seguridad

La librería aplica automáticamente los siguientes headers en todas las
respuestas — exitosas y de error — conforme al estándar:

| Header | Valor por defecto | Propósito |
|---|---|---|
| `Strict-Transport-Security` | `max-age=31536000` | Fuerza comunicación solo por HTTPS |
| `X-Frame-Options` | `DENY` | Previene carga de contenido en iframes |
| `Content-Security-Policy` | `self` | Restringe el tipo de contenido procesable |
| `Content-Type` | `application/json` | Tipo de contenido de la respuesta |
| `Expect-CT` | `max-age=604800,enforce` | Aplica política de Transparencia de Certificados |
| `X-XSS-Protection` | `1; mode=block` | Protege contra ataques XSS |
| `X-Content-Type-Options` | `nosniff` | Previene autodetección de tipo de contenido |
| `Cache-Control` | `none` | Control de almacenamiento en caché |
| `Pragma` | `no-cache` | Control de caché para clientes legacy |
| `Expires` | `0` | El contenido expira inmediatamente |
| `X-Powered-By` | `exists-action="delete"` | Oculta información de tecnologías del servidor |

> Si el microservicio define alguno de estos headers con un valor propio,
> la librería no lo sobreescribe.

---

## Tabla de prefijos de error

| Prefijo | Nombre | Cuándo aplica |
|---|---|---|
| `BP` | Business Provider | Error de negocio en el proveedor o backend |
| `SP` | System Provider | Error de sistema en el proveedor o backend |
| `SA` | System API | Error de sistema propio del API |
| `SI` | System Infrastructure | Error en infraestructura de capa media |
| `SM` | System Middleware API | Error en el API de capa media |

---

## Componentes de la librería

| Componente | Paquete | Descripción |
|---|---|---|
| `MessageFactory` | `factory` | Punto de entrada para construir respuestas |
| `RequestEnvelope<B>` | `envelope` | Envelope del request |
| `ResponseEnvelope<B>` | `envelope` | Envelope del response exitoso |
| `ErrorEnvelope` | `envelope` | Envelope del response de error |
| `Metadata` | `envelope` | Datos de trazabilidad del mensaje |
| `CoreRequestHeader` | `envelope.header` | Header del request |
| `CoreResponseHeader` | `envelope.header` | Header del response |
| `RequestPagination` | `envelope.pagination` | Paginación del request |
| `ResponsePagination` | `envelope.pagination` | Paginación del response |
| `ApiExceptionHandler` | `web` | Handler global de excepciones |
| `RequestContextAdvice` | `web` | Intercepta el body para extraer metadata |
| `SecurityHeadersFilter` | `web` | Aplica headers de seguridad |
| `ApiRequestContext` | `web` | Contexto del request actual |
| `EnvelopeBuilder<T>` | `factory` | Base para construir envelopes |
| `ResponseEnvelopeBuilder<B>` | `factory` | Builder de respuestas exitosas |
| `ErrorEnvelopeBuilder` | `factory` | Builder de respuestas de error |
| `ApiException` | `exception` | Excepción base sealed |
| `ErrorPrefix` | `error` | Prefijos de categorización de errores |
| `ErrorCodeBuilder` | `error` | Constructor de códigos de error |
| `ApiError` | `error` | Elemento del array errors |
| `Securityheaders` | `web` | Utilidad para aplicar headers de seguridad |
| `MessagingCoreConfiguration` | `config` | Configuración base de la librería |

---

## Versión

| Versión | Descripción |
|---|---|
| `1.0.0` | Primera versión estable |

---

*Desarrollado por Jose Luis Pereira*
