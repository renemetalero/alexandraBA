package sv.ba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de la aplicacion.
 * Escanea automaticamente todos los componentes en el paquete sv.ba
 */
@SpringBootApplication(scanBasePackages = "sv.ba")
public class MainApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainApplication.class, args);
	}

}
