package sv.ba.domain.exceptions;

/**
 * Excepción lanzada cuando hay un error de validación de datos.
 * Generalmente se mapea a HTTP 400 (Bad Request).
 */
public class ValidationException extends BusinessException {

    public ValidationException(String message) {
        super(message, "VALIDATION_ERROR");
    }

    public ValidationException(String field, String message) {
        super(String.format("Error de validación en el campo '%s': %s", field, message), 
              "VALIDATION_ERROR");
    }

    public ValidationException(String message, Throwable cause) {
        super(message, "VALIDATION_ERROR", cause);
    }
}
