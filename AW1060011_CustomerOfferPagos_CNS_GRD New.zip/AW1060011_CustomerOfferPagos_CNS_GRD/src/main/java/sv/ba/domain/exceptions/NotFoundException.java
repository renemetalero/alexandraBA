package sv.ba.domain.exceptions;

/**
 * Excepción lanzada cuando un recurso no es encontrado.
 * Generalmente se mapea a HTTP 404 (Not Found).
 */
public class NotFoundException extends BusinessException {

    public NotFoundException(String message) {
        super(message, "RESOURCE_NOT_FOUND");
    }

    public NotFoundException(String resourceName, String identifier) {
        super(String.format("%s no encontrado con identificador: %s", resourceName, identifier), 
              "RESOURCE_NOT_FOUND");
    }

    public NotFoundException(String message, Throwable cause) {
        super(message, "RESOURCE_NOT_FOUND", cause);
    }
}
