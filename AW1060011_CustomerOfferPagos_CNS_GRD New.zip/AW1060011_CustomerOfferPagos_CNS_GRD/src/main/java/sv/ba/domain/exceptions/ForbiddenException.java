package sv.ba.domain.exceptions;

/**
 * Excepción lanzada cuando una operación no está permitida.
 * Por ejemplo: acceso denegado, operación no autorizada.
 * Generalmente se mapea a HTTP 403 (Forbidden).
 */
public class ForbiddenException extends BusinessException {

    public ForbiddenException(String message) {
        super(message, "OPERATION_FORBIDDEN");
    }

    public ForbiddenException(String operation, String reason) {
        super(String.format("Operación '%s' no permitida: %s", operation, reason), 
              "OPERATION_FORBIDDEN");
    }

    public ForbiddenException(String message, Throwable cause) {
        super(message, "OPERATION_FORBIDDEN", cause);
    }
}
