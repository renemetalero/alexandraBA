package sv.ba.domain.exceptions;

/**
 * Excepción lanzada cuando hay un conflicto con el estado actual del recurso.
 * Por ejemplo: intentar crear un recurso que ya existe.
 * Generalmente se mapea a HTTP 409 (Conflict).
 */
public class ConflictException extends BusinessException {

    public ConflictException(String message) {
        super(message, "RESOURCE_CONFLICT");
    }

    public ConflictException(String resourceName, String identifier) {
        super(String.format("%s ya existe con identificador: %s", resourceName, identifier), 
              "RESOURCE_CONFLICT");
    }

    public ConflictException(String message, Throwable cause) {
        super(message, "RESOURCE_CONFLICT", cause);
    }
}
