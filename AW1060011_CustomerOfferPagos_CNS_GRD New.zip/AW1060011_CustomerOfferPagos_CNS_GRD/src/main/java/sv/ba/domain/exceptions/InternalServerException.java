package sv.ba.domain.exceptions;

/**
 * Excepción lanzada cuando hay un error interno del servidor.
 * Errores inesperados o problemas técnicos.
 * Generalmente se mapea a HTTP 500 (Internal Server Error).
 */
public class InternalServerException extends BusinessException {

    public InternalServerException(String message) {
        super(message, "INTERNAL_SERVER_ERROR");
    }

    public InternalServerException(String message, Throwable cause) {
        super(message, "INTERNAL_SERVER_ERROR", cause);
    }

    public InternalServerException(Throwable cause) {
        super("Ha ocurrido un error interno en el servidor", "INTERNAL_SERVER_ERROR", cause);
    }
}
