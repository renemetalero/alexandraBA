package sv.ba.infrastructure.adapters.input.rest;

import sv.ba.domain.exceptions.BusinessException;
import sv.ba.domain.exceptions.ConflictException;
import sv.ba.domain.exceptions.ForbiddenException;
import sv.ba.domain.exceptions.InternalServerException;
import sv.ba.domain.exceptions.NotFoundException;
import sv.ba.domain.exceptions.ValidationException;
import sv.ba.infrastructure.config.AppLogger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controlador de ejemplo que muestra como usar las excepciones y el logger.
 * Este controlador sirve como referencia para implementaciones futuras.
 */
@RestController
@RequestMapping("/api/examples")
public class ExampleController {

    /**
     * Ejemplo de uso de AppLogger con nivel INFO
     * GET /api/examples/log-info
     */
    @GetMapping("/log-info")
    public ResponseEntity<String> logInfoExample() {
        AppLogger.info(ExampleController.class, "Ejemplo de log nivel INFO");
        AppLogger.info(ExampleController.class, "Usuario {} realizo accion {}", "admin", "consulta");
        return ResponseEntity.ok("Log INFO registrado correctamente");
    }

    /**
     * Ejemplo de uso de AppLogger con nivel DEBUG
     * GET /api/examples/log-debug
     */
    @GetMapping("/log-debug")
    public ResponseEntity<String> logDebugExample() {
        AppLogger.debug(ExampleController.class, "Ejemplo de log nivel DEBUG");
        AppLogger.debug(ExampleController.class, "Parametros recibidos: {}, {}", "param1", "param2");
        return ResponseEntity.ok("Log DEBUG registrado correctamente");
    }

    /**
     * Ejemplo de uso de AppLogger con nivel WARN
     * GET /api/examples/log-warn
     */
    @GetMapping("/log-warn")
    public ResponseEntity<String> logWarnExample() {
        AppLogger.warn(ExampleController.class, "Ejemplo de log nivel WARN - Operacion sospechosa detectada");
        AppLogger.warn(ExampleController.class, "Advertencia: El usuario {} intento {} veces", "user123", 5);
        return ResponseEntity.ok("Log WARN registrado correctamente");
    }

    /**
     * Ejemplo de uso de NotFoundException
     * GET /api/examples/not-found
     * Lanza excepcion HTTP 404
     */
    @GetMapping("/not-found")
    public ResponseEntity<String> notFoundExample() {
        AppLogger.warn(ExampleController.class, "Recurso no encontrado - ID: 123");
        throw new NotFoundException("El recurso con ID 123 no fue encontrado", "RESOURCE_NOT_FOUND");
    }

    /**
     * Ejemplo de uso de ValidationException
     * GET /api/examples/validation-error
     * Lanza excepcion HTTP 400
     */
    @GetMapping("/validation-error")
    public ResponseEntity<String> validationExample() {
        AppLogger.error(ExampleController.class, "Error de validacion detectado");
        throw new ValidationException("El campo 'email' no tiene un formato valido", "INVALID_EMAIL");
    }

    /**
     * Ejemplo de uso de ConflictException
     * GET /api/examples/conflict
     * Lanza excepcion HTTP 409
     */
    @GetMapping("/conflict")
    public ResponseEntity<String> conflictExample() {
        AppLogger.warn(ExampleController.class, "Conflicto detectado - Email duplicado");
        throw new ConflictException("El email ya esta registrado en el sistema", "EMAIL_ALREADY_EXISTS");
    }

    /**
     * Ejemplo de uso de ForbiddenException
     * GET /api/examples/forbidden
     * Lanza excepcion HTTP 403
     */
    @GetMapping("/forbidden")
    public ResponseEntity<String> forbiddenExample() {
        AppLogger.warn(ExampleController.class, "Acceso denegado - Usuario sin permisos");
        throw new ForbiddenException("No tiene permisos para acceder a este recurso", "ACCESS_DENIED");
    }

    /**
     * Ejemplo de uso de InternalServerException
     * GET /api/examples/server-error
     * Lanza excepcion HTTP 500
     */
    @GetMapping("/server-error")
    public ResponseEntity<String> serverErrorExample() {
        AppLogger.error(ExampleController.class, "Error interno del servidor");
        throw new InternalServerException("Error al procesar la solicitud en el servidor");
    }

    /**
     * Ejemplo de uso de BusinessException generica
     * GET /api/examples/business-error
     * Lanza excepcion HTTP 400
     */
    @GetMapping("/business-error")
    public ResponseEntity<String> businessErrorExample() {
        AppLogger.error(ExampleController.class, "Error de logica de negocio");
        throw new BusinessException("La operacion no cumple con las reglas de negocio", "BUSINESS_RULE_VIOLATION");
    }

    /**
     * Ejemplo de manejo de excepcion con try-catch y logging
     * GET /api/examples/handled-exception
     */
    @GetMapping("/handled-exception")
    public ResponseEntity<String> handledExceptionExample() {
        try {
            AppLogger.info(ExampleController.class, "Intentando operacion riesgosa");
            // Simular una operacion que puede fallar
            @SuppressWarnings("unused")
            int result = 10 / 0;
            return ResponseEntity.ok("Operacion exitosa");
        } catch (Exception ex) {
            AppLogger.errorWithException(ExampleController.class, "Error capturado en try-catch: " + ex.getMessage(), ex);
            throw new InternalServerException("Error al ejecutar la operacion", ex);
        }
    }

    /**
     * Ejemplo de endpoint exitoso con logging
     * GET /api/examples/success
     */
    @GetMapping("/success")
    public ResponseEntity<String> successExample() {
        AppLogger.info(ExampleController.class, "Iniciando proceso exitoso");
        AppLogger.debug(ExampleController.class, "Procesando datos...");
        
        // Logica de negocio simulada
        String result = "Operacion completada";
        
        AppLogger.info(ExampleController.class, "Proceso finalizado exitosamente");
        return ResponseEntity.ok(result);
    }

    /**
     * Ejemplo con parametros y validacion
     * GET /api/examples/validate/{id}
     */
    @GetMapping("/validate/{id}")
    public ResponseEntity<String> validateExample(@PathVariable Long id) {
        AppLogger.info(ExampleController.class, "Validando recurso con ID: {}", id);
        
        if (id == null || id <= 0) {
            AppLogger.error(ExampleController.class, "ID invalido recibido: {}", id);
            throw new ValidationException("El ID debe ser un numero positivo", "INVALID_ID");
        }
        
        if (id > 1000) {
            AppLogger.warn(ExampleController.class, "Recurso no encontrado - ID: {}", id);
            throw new NotFoundException("No existe recurso con ID: " + id, "RESOURCE_NOT_FOUND");
        }
        
        AppLogger.info(ExampleController.class, "Recurso validado correctamente - ID: {}", id);
        return ResponseEntity.ok("Recurso valido con ID: " + id);
    }
}
