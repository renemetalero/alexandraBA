package sv.ba.infrastructure.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AppLogger {

    public static void info(Class<?> clazz, String message) {
        Logger logger = LogManager.getLogger(clazz);
        logger.info(message);
    }

    public static void info(Class<?> clazz, String message, Object... params) {
        Logger logger = LogManager.getLogger(clazz);
        logger.info(message, params);
    }

    public static void error(Class<?> clazz, String message) {
        Logger logger = LogManager.getLogger(clazz);
        logger.error(message);
    }

    public static void errorWithException(Class<?> clazz, String message, Throwable throwable) {
        Logger logger = LogManager.getLogger(clazz);
        logger.error(message, throwable);
    }

    public static void error(Class<?> clazz, String message, Object... params) {
        Logger logger = LogManager.getLogger(clazz);
        logger.error(message, params);
    }

    public static void warn(Class<?> clazz, String message) {
        Logger logger = LogManager.getLogger(clazz);
        logger.warn(message);
    }

    public static void warn(Class<?> clazz, String message, Object... params) {
        Logger logger = LogManager.getLogger(clazz);
        logger.warn(message, params);
    }

    public static void debug(Class<?> clazz, String message) {
        Logger logger = LogManager.getLogger(clazz);
        logger.debug(message);
    }

    public static void debug(Class<?> clazz, String message, Object... params) {
        Logger logger = LogManager.getLogger(clazz);
        logger.debug(message, params);
    }
}
