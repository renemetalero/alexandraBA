package sv.ba.infrastructure.adapters.input.rest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Controlador para la ruta raíz de la aplicación.
 * Proporciona información básica y health check.
 */
@RestController
@RequestMapping("/")
public class RootController {

    /**
     * Endpoint de bienvenida en la raíz
     * GET /
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> root() {
        Map<String, Object> response = new HashMap<>();
        response.put("application", "Scaffold API REST - Clean Architecture");
        response.put("version", "0.0.1-SNAPSHOT");
        response.put("status", "UP");
        response.put("timestamp", LocalDateTime.now());
        response.put("description", "API de ejemplo con arquitectura limpia");
        response.put("endpoints", Map.of(
            "examples", "/api/examples",
            "health", "/health"
        ));
        
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint de health check
     * GET /health
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("timestamp", LocalDateTime.now().toString());
        
        return ResponseEntity.ok(response);
    }
}
