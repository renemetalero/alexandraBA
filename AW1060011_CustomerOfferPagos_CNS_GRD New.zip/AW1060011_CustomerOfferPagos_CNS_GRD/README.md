# Clean Architecture - Scaffold API REST

## 📋 Descripción

Este proyecto implementa una arquitectura limpia (Clean Architecture) para aplicaciones API REST con Spring Boot. La estructura está diseñada para ser escalable, mantenible y fácil de testear, siguiendo los principios de diseño de software propuestos por Robert C. Martin (Uncle Bob).

## 🏗️ Estructura del Proyecto

```
src/main/java/sv/ba/
├── domain/                          # Capa de Dominio (Core de la aplicación)
│   ├── model/                       # Entidades de dominio
│   ├── exceptions/                  # Excepciones de negocio
│   └── ports/                       # Interfaces (Output Ports)
│
├── application/                     # Capa de Aplicación
│   ├── usecases/                    # Casos de uso (lógica de negocio)
│   └── dto/                         # Data Transfer Objects
│
└── infrastructure/                  # Capa de Infraestructura
    ├── adapters/
    │   ├── input/
    │   │   └── rest/                # Controladores REST (Input Adapters)
    │   └── output/
    │       └── persistence/         # Implementación de repositorios (Output Adapters)
    └── config/                      # Configuración de Spring Boot
```

## 🎯 Principios de Clean Architecture

### 1. **Independencia de Frameworks**
El código de negocio no depende de Spring Boot, JPA u otros frameworks. Estos son solo detalles de implementación.

### 2. **Testeabilidad**
La lógica de negocio puede ser testeada sin UI, base de datos, servidor web u otros elementos externos.

### 3. **Independencia de la UI**
La interfaz de usuario (REST API) puede cambiar sin afectar el resto del sistema.

### 4. **Independencia de la Base de Datos**
Puedes cambiar de H2 a PostgreSQL, MongoDB, etc., sin afectar las reglas de negocio.

### 5. **Regla de Dependencia**
Las dependencias del código fuente solo pueden apuntar hacia adentro (hacia las capas más internas).

```
┌─────────────────────────────────────────┐
│         Infrastructure                  │  ← Frameworks, Drivers
│  (REST Controllers, JPA Repositories)   │
├─────────────────────────────────────────┤
│         Application                     │  ← Use Cases
│  (Business Logic, Orchestration)        │
├─────────────────────────────────────────┤
│         Domain                          │  ← Entities, Business Rules
│  (Core Business Logic)                  │
└─────────────────────────────────────────┘
        ↑           ↑           ↑
        Dependency Flow (Inward Only)
```

## 📦 Descripción de Capas

### 🔵 Domain (Capa de Dominio)
**Propósito**: Contiene la lógica de negocio pura y las entidades de dominio.

**Características**:
- ❌ **NO** tiene dependencias de frameworks externos
- ❌ **NO** conoce Spring, JPA, REST, etc.
- ✅ Solo contiene lógica de negocio pura (Java POJO)
- ✅ Define interfaces (ports) que serán implementadas por capas externas

**Contenido**:
- **model/**: Entidades de dominio con reglas de negocio
- **exceptions/**: Excepciones específicas del dominio
- **ports/**: Interfaces que definen contratos (ej: `UserRepository`, `EmailService`)

**Ejemplo**:
```java
// domain/model/User.java
public class User {
    private Long id;
    private String email;
    private String name;
    
    public void validateEmail() {
        // Lógica de validación de negocio
    }
}

// domain/ports/UserRepositoryPort.java
public interface UserRepositoryPort {
    User findById(Long id);
    User save(User user);
}
```

### 🟢 Application (Capa de Aplicación)
**Propósito**: Contiene los casos de uso y orquesta el flujo de datos.

**Características**:
- ✅ Implementa casos de uso específicos del negocio
- ✅ Coordina el flujo de datos entre capas
- ✅ Puede depender de la capa de dominio
- ❌ **NO** conoce detalles de implementación (BD, REST, etc.)

**Contenido**:
- **usecases/**: Casos de uso (ej: `CreateUserUseCase`, `FindUserUseCase`)
- **dto/**: Objetos de transferencia de datos para comunicación entre capas

**Ejemplo**:
```java
// application/usecases/CreateUserUseCase.java
public class CreateUserUseCase {
    private final UserRepositoryPort userRepository;
    
    public CreateUserUseCase(UserRepositoryPort userRepository) {
        this.userRepository = userRepository;
    }
    
    public User execute(CreateUserDto dto) {
        User user = new User(dto.getEmail(), dto.getName());
        user.validateEmail();
        return userRepository.save(user);
    }
}
```

### 🟡 Infrastructure (Capa de Infraestructura)
**Propósito**: Contiene todos los detalles de implementación y frameworks.

**Características**:
- ✅ Implementa las interfaces definidas en Domain
- ✅ Maneja frameworks externos (Spring, JPA, REST)
- ✅ Contiene configuración de Spring Boot
- ✅ Convierte entre modelos de dominio y modelos de persistencia

**Contenido**:
- **adapters/input/rest/**: Controladores REST (reciben peticiones HTTP)
- **adapters/output/persistence/**: Implementación de repositorios con JPA
- **config/**: Configuración de beans, seguridad, etc.

**Ejemplo**:
```java
// infrastructure/adapters/input/rest/UserController.java
@RestController
@RequestMapping("/api/users")
public class UserController {
    private final CreateUserUseCase createUserUseCase;
    
    @PostMapping
    public ResponseEntity<UserResponse> createUser(@RequestBody UserRequest request) {
        User user = createUserUseCase.execute(new CreateUserDto(request));
        return ResponseEntity.ok(new UserResponse(user));
    }
}

// infrastructure/adapters/output/persistence/UserJpaAdapter.java
@Repository
public class UserJpaAdapter implements UserRepositoryPort {
    private final UserJpaRepository jpaRepository;
    
    @Override
    public User save(User user) {
        UserEntity entity = toEntity(user);
        UserEntity saved = jpaRepository.save(entity);
        return toDomain(saved);
    }
}
```

## 🔄 Flujo de Datos

```
1. HTTP Request
   ↓
2. REST Controller (Infrastructure - Input Adapter)
   ↓
3. Use Case (Application)
   ↓
4. Domain Model + Business Logic (Domain)
   ↓
5. Repository Port (Domain Interface)
   ↓
6. Repository Adapter (Infrastructure - Output Adapter)
   ↓
7. Database (JPA/H2)
```

## 🚀 Ventajas de esta Arquitectura

1. **✅ Mantenibilidad**: Cada capa tiene responsabilidades claras
2. **✅ Testabilidad**: Puedes testear la lógica de negocio sin bases de datos
3. **✅ Flexibilidad**: Fácil cambiar frameworks o bases de datos
4. **✅ Escalabilidad**: Agregar nuevas funcionalidades es sencillo
5. **✅ Independencia**: El core de negocio no depende de tecnologías externas
6. **✅ Documentación implícita**: La estructura misma documenta la arquitectura

## 📚 Tecnologías Utilizadas

- **Java 17**: Lenguaje de programación
- **Spring Boot 3.5.9**: Framework de aplicación
- **Spring Data JPA**: Persistencia de datos
- **Spring Validation**: Validación de datos
- **Lombok**: Reducción de código boilerplate
- **H2 Database**: Base de datos en memoria (desarrollo)
- **JUnit 5**: Testing

## 🧪 Testing

La arquitectura facilita diferentes tipos de tests:

- **Tests Unitarios**: Domain y Application (sin dependencias externas)
- **Tests de Integración**: Infrastructure (con Spring Boot Test)
- **Tests de Aceptación**: End-to-end con REST Assured

## 🎓 Recursos Adicionales

- [The Clean Architecture - Uncle Bob](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [Hexagonal Architecture](https://alistair.cockburn.us/hexagonal-architecture/)
- [Domain-Driven Design](https://martinfowler.com/bliki/DomainDrivenDesign.html)
- [Sonar Gradle Documentation](https://docs.sonarsource.com/sonarqube-community-build/analyzing-source-code/scanners/sonarscanner-for-gradle)

## 📝 Notas

Este scaffold es un punto de partida. Adapta la estructura según las necesidades específicas de tu proyecto, pero mantén siempre los principios de Clean Architecture:

- **Separación de responsabilidades**
- **Dependencias hacia adentro**
- **Independencia de frameworks**
- **Testeabilidad**

## 🔧 Comandos Gradle

### Compilar el Proyecto
```bash
# Windows
.\gradlew clean build

# Linux/Mac
./gradlew clean build
```

### Ejecutar la Aplicación
```bash
# Windows
.\gradlew bootRun

# Linux/Mac
./gradlew bootRun
```

### Refrescar Dependencias
```bash
# Windows - Forzar descarga de dependencias
.\gradlew build --refresh-dependencies

# Linux/Mac
./gradlew build --refresh-dependencies
```

### Ejecutar Tests
```bash
# Windows
.\gradlew test

# Linux/Mac
./gradlew test
```

### Limpiar Build
```bash
# Windows
.\gradlew clean

# Linux/Mac
./gradlew clean
```

### Generar Reporte de Cobertura (Jacoco)
```bash
# Windows
.\gradlew test jacocoTestReport

# Linux/Mac
./gradlew test jacocoTestReport
```
*El reporte se genera en: `build/reports/jacoco/test/html/index.html`*

### Análisis de Código con SonarQube
```bash
# Windows
.\gradlew sonarqube

# Linux/Mac
./gradlew sonarqube
```

### Ver Todas las Tareas Disponibles
```bash
# Windows
.\gradlew tasks

# Linux/Mac
./gradlew tasks
```

### Comandos Útiles Combinados
```bash
# Limpiar, compilar y ejecutar tests
.\gradlew clean build test

# Limpiar, compilar y ejecutar la aplicación
.\gradlew clean build bootRun
```

---
## 🔧 Versiones y Compatibilidad

### Versiones Verificadas

Este proyecto ha sido probado y funciona correctamente con las siguientes versiones locales:

- **JDK**: Java 17.0.17
- **Gradle**: 7.6.6

**Autor**: Scaffold API REST Clean Architecture  
**Versión**: 0.0.1-SNAPSHOT  
**Fecha**: 2026
